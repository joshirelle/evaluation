<?php 
 
// Load the database configuration file 
require "connection.php";
 
// Include PhpSpreadsheet library autoloader 
require 'vendor/autoload.php'; 
use PhpOffice\PhpSpreadsheet\Reader\Xlsx; 
 
if(isset($_POST['importSubmit'])){ 
     
    // Allowed mime types 
    $excelMimes = array('text/xls', 'text/xlsx', 'application/excel', 'application/vnd.msexcel', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); 
     
    // Validate whether selected file is a Excel file 
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $excelMimes)){ 
         
        // If the file is uploaded 
        if(is_uploaded_file($_FILES['file']['tmp_name'])){ 
            $reader = new Xlsx(); 
            $spreadsheet = $reader->load($_FILES['file']['tmp_name']); 
            $worksheet = $spreadsheet->getActiveSheet();  
            $worksheet_arr = $worksheet->toArray(); 
 
            // Remove header row 
            unset($worksheet_arr[0]); 
            foreach($worksheet_arr as $row){ 
                $studnum = $row[0]; 
                $lname = $row[1]; 
                $fname = $row[2]; 
                $mname = $row[3]; 
                $deptID = $row[4]; 
 
                // Check whether member already exists in the database with the same email 
                $prevQuery = "SELECT studnum FROM students WHERE studnum = '".$studnum."'"; 
                //$prevResult = $db->query($prevQuery); 
                $stmt = $pdo->prepare($prevQuery);
                $stmt->execute();

                if($stmt->rowCount() > 0){ 
                    // // Update member data in the database 
                    $sql = "UPDATE students SET studnum = :studnum, lname = :lname, fname = :fname, mi = :mi, deptID = :deptID WHERE studnum = :studnum";
                    if ($stmt = $pdo->prepare($sql)) {
                        // Bind variables to the prepared statement as parameters    
                        $stmt->bindParam(":studnum", $studnum);
                        $stmt->bindParam(":lname", $lname);
                        $stmt->bindParam(":fname", $fname);
                        $stmt->bindParam(":mi", $mname);
                        $stmt->bindParam(":deptID", $deptID);
                        $stmt->bindParam(":studnum", $studnum);
                        // Set parameters
                      
                        $param_studnum = $studnum;
                        $param_lname = $lname;
                        $param_fname = $fname;
                        $param_mname = $mname;
                        $param_deptID = $deptID;
                        $param_studnum = $studnum;
                        $stmt->execute();
                    } 
                }else{ 
                    $sql = "INSERT INTO students (studnum, lname, fname, mi, deptID) VALUES (:studnum, :lname, :fname, :mi, :deptID)";
                    if ($stmt = $pdo->prepare($sql)) {
                      // Bind variables to the prepared statement as parameters    
                      $stmt->bindParam(":studnum", $studnum);
                      $stmt->bindParam(":lname", $lname);
                      $stmt->bindParam(":fname", $fname);
                      $stmt->bindParam(":mi", $mname);
                      $stmt->bindParam(":deptID", $deptID);
                      // Set parameters
                      
                      $param_studnum = $studnum;
                      $param_lname = $lname;
                      $param_fname = $fname;
                      $param_mname = $mname;
                      $param_deptID = $deptID;

                      // Attempt to execute the prepared statement
                      if ($stmt->execute()) {
                        // // Records created successfully. Redirect to landing page
                        //     header("Location: index2.php".$qstring); 
                        // exit();
                      } else {
                        echo "Oops! Something went wrong. Please try again later.";
                      }
                    }
                } 
            } 
             
            $qstring = '?status=success'; 
        }else{ 
            $qstring = '?status=err'; 
        } 


    }else{ 
        $qstring = '?status=invalid_file';
    } 
} 
 
// Redirect to the listing page 
header("Location: activestudents.php".$qstring); 
 
?>