// Call the dataTables jQuery plugin

$(document).ready(function() {
    $('#faculty-table').DataTable();
    $('#students-table').DataTable();
    $('#department-table').DataTable();

    $('#activefaculty-table').DataTable();
    $('#activedepartment-table').DataTable();
    $('#activestudent-table').DataTable();
    $('#activeuser-table').DataTable();

    $('#result-table').DataTable();

    $('#inactivefaculty-table').DataTable();
    $('#inactivedepartment-table').DataTable();
    $('#inactivestudent-table').DataTable();
    $('#inactiveuser-table').DataTable();

    $('#questions-table').DataTable();

});
