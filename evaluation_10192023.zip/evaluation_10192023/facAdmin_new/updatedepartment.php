<?php
// Include config file
require_once "php/core.php";
 
// Define variables and initialize with empty values
$deptcode = $deptname = "";
$deptcode2 = $deptname1 ="";

// Processing form data when form is submitted
if(isset($_POST["department_id"]) && !empty($_POST["department_id"])){
    // Get hidden input value
    $id = $_POST["department_id"];
    
    // Validate name
    $input_deptcode = trim($_POST["deptcode"]);
    $deptcode = $input_deptcode;
  
    // // Validate address address
    $input_deptname = trim($_POST["deptname"]);
    $deptname = $input_deptname;
    
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        // Prepare an update statement
        $sql = "UPDATE department SET deptcode=:deptcode, deptname=:deptname WHERE deptID=:id";
 
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":deptcode", $param_deptcode);
            $stmt->bindParam(":deptname", $param_deptname);
            $stmt->bindParam(":id", $param_id);

            // Set parameters
            $param_deptcode = $deptcode;
            $param_deptname = $deptname;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records updated successfully. Redirect to landing page
                header("location: activedepartment.php");
                exit();
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        unset($stmt);
    }
    
    // Close connection
    unset($pdo);
}
?>
