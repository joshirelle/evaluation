<?php
    require_once "php/core.php";

    $request = $_REQUEST; //a PHP Super Global variable which used to collect data after submitting it from the form
	$userId = $request['user_id'];//define the employee ID


	// Set the INSERT SQL data
    $sql = "SELECT
    user.userid,
    user.lname,
    user.fname,
    user.mname,
    position.positionname
    FROM user
    JOIN position ON user.positionnum=position.positionnum WHERE userid='".$userId."'";

    if ($result = $pdo->query($sql)) {

    if ($result->rowCount() > 0) {
        while ($row = $result->fetch()) {
            echo json_encode($row);
            }
        }
    }
    unset($result);
    unset($pdo);
?>