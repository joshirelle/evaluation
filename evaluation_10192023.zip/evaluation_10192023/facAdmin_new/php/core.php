<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once "connection.php";
require_once "helpers.php";

$authUser = getAuthenticatedUser();
