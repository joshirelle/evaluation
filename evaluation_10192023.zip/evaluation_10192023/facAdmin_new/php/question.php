<?php
// Include config file
require_once "core.php";

// CREATE NEW QUESTION
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create'])) {
    $input_category_id   = trim($_POST['category_id']);
    $input_qe            = trim($_POST['qe']);
    $input_qt            = trim($_POST['qt']);

    $category_id   = htmlspecialchars($input_category_id, ENT_QUOTES, 'UTF-8');
    $qe            = htmlspecialchars($input_qe, ENT_QUOTES, 'UTF-8');
    $qt            = htmlspecialchars($input_qt, ENT_QUOTES, 'UTF-8');

    try {
        $sql = "INSERT INTO questions (ques, quesTagalog, catID) VALUES (:qe, :qt, :category_id)";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":qe", $qe);
        $stmt->bindParam(":qt", $qt);
        $stmt->bindParam(":category_id", $category_id);
        
        $stmt->execute();

        $_SESSION['success'] = 'Successfuly Created New Question!';
        // Redirect after successful update
        header("location: ../questions.php");
    } catch (PDOException $ex) {
        // Handle database errors here
        echo "Error: " . $ex->getMessage();
    }
}

// UPDATE QUESTION
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $input_category_id = trim($_POST['category_id']);
    $input_ques_id     = trim($_POST['ques_id']);
    $input_qe          = trim($_POST['qe']);
    $input_qt          = trim($_POST['qt']);

    $category_id = htmlspecialchars($input_category_id, ENT_QUOTES, 'UTF-8');
    $ques_id     = htmlspecialchars($input_ques_id, ENT_QUOTES, 'UTF-8');
    $qe          = htmlspecialchars($input_qe, ENT_QUOTES, 'UTF-8');
    $qt          = htmlspecialchars($input_qt, ENT_QUOTES, 'UTF-8');

    try {
        $sql = "UPDATE questions SET ques=:qe, quesTagalog=:qt WHERE catID=:category_id AND quesID=:ques_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":qe", $qe);
        $stmt->bindParam(":qt", $qt);
        $stmt->bindParam(":category_id", $category_id);
        $stmt->bindParam(":ques_id", $ques_id);
        
        $stmt->execute();

        $_SESSION['success'] = 'Successfuly Updated Question!';
        // Redirect after successful update
        header("location: ../questions.php");
    } catch (PDOException $ex) {
        // Handle database errors here
        echo "Error: " . $ex->getMessage();
    }
}

// DELETE QUESTION
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $input_ques_id = trim($_POST['ques_id']);

    $ques_id = htmlspecialchars($input_ques_id, ENT_QUOTES, 'UTF-8');

    try {
        $sql = "UPDATE questions SET isdeleted=1 WHERE quesID=:ques_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":ques_id", $ques_id);
        
        $stmt->execute();

        $_SESSION['success'] = 'Successfuly Deactivated Question!';
        // Redirect after successful update
        header("location: ../questions.php");
    } catch (PDOException $ex) {
        // Handle database errors here
        echo "Error: " . $ex->getMessage();
    }
}

// CREATE NEW CATEGORY
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_category'])) {
    $input_category_desc = trim($_POST['category_desc']);
    $input_category_name = trim($_POST['category_name']);

    $category_name = htmlspecialchars($input_category_name, ENT_QUOTES, 'UTF-8');
    $category_desc = htmlspecialchars($input_category_desc, ENT_QUOTES, 'UTF-8');

    try {
        $sql = "INSERT INTO category (catname, catdescE) VALUES (:category_name, :category_desc)";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":category_name", $category_name);
        $stmt->bindParam(":category_desc", $category_desc);
        
        $stmt->execute();

        $_SESSION['success'] = 'Successfuly Created New Category!';
        // Redirect after successful update
        header("location: ../questions.php");

    } catch (PDOException $ex) {
        // Handle database errors here
        echo "Error: " . $ex->getMessage();
    }
}

// UPDATE CATEGORY
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_category'])) {
    $input_category_name = trim($_POST['category_name']);
    $input_category_desc = trim($_POST['category_desc']);
    $input_category_id   = trim($_POST['category_id']);

    $category_name = htmlspecialchars($input_category_name, ENT_QUOTES, 'UTF-8');
    $category_desc = htmlspecialchars($input_category_desc, ENT_QUOTES, 'UTF-8');
    $category_id   = htmlspecialchars($input_category_id, ENT_QUOTES, 'UTF-8');

    try {
        $sql = "UPDATE category SET catname=:category_name, catdescE=:category_desc WHERE catID=:category_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":category_name", $category_name);
        $stmt->bindParam(":category_desc", $category_desc);
        $stmt->bindParam(":category_id", $category_id);
        
        $stmt->execute();

        $_SESSION['success'] = 'Successfuly Updated Category!';
        // Redirect after successful update
        header("location: ../questions.php");

    } catch (PDOException $ex) {
        // Handle database errors here
        echo "Error: " . $ex->getMessage();
    }
}

// DELETE CATEGORY
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_category'])) {
    $input_category_id   = trim($_POST['category_id']);

    $category_id   = htmlspecialchars($input_category_id, ENT_QUOTES, 'UTF-8');
    try {
        $sql = "UPDATE category SET isdeleted=1 WHERE catID=:category_id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":category_id", $category_id);
        
        $stmt->execute();

        $_SESSION['success'] = 'Successfuly Deactivated Category!';
        // Redirect after successful update
        header("location: ../questions.php");

    } catch (PDOException $ex) {
        // Handle database errors here
        echo "Error: " . $ex->getMessage();
    }
}

// FETCH ALL CATEGORY
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['get_category']) && $_POST['get_category'] === "get_all_category") {
    try {
        $sql = "SELECT * FROM category WHERE isdeleted=0"; // Modify this query according to your needs

        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        $result = $stmt->fetchAll();

        // Output the JSON response
        echo json_encode($result);
    } catch (PDOException $ex) {
        error_log("Error: " . $ex->getMessage()); // Log the error message
        http_response_code(500); // Internal Server Error
        echo json_encode(array("error" => "An internal server error occurred."));
    }
}
?>