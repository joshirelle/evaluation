<?php
// Include config file
require_once "php/core.php";

// Define variables and initialize with empty values
$studnum = $lname = $fname = $mname = $deptcode = "";
$studnum2 = $lname2 = $fname2 = $mname2 = $deptcode2 = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate name
  
  // Validate name
  $input_studnum = trim($_POST["studnum"]);
  $studnum = htmlspecialchars($input_studnum);
  
  // Validate name
  $input_lname = trim($_POST["lname"]);
  $lname = htmlspecialchars($input_lname);
  // Validate name
  $input_fname = trim($_POST["fname"]);
  $fname = htmlspecialchars($input_fname);

  // Validate name
  $input_mname = trim($_POST["mname"]);
  $mname = htmlspecialchars($input_mname);

  $input_deptcode = trim($_POST["deptcode"]);
  $deptID = htmlspecialchars($input_deptcode);

  // Check input errors before inserting in database
  if (empty($name_err) && empty($address_err) && empty($salary_err)) {
    // Prepare an insert statement
    $sql = "INSERT INTO students (studnum, lname, fname, mi, deptID) VALUES (:studnum, :lname, :fname, :mi, :deptID)";

    if ($stmt = $pdo->prepare($sql)) {
      // Bind variables to the prepared statement as parameters    
      $stmt->bindParam(":studnum", $studnum);
      $stmt->bindParam(":lname", $lname);
      $stmt->bindParam(":fname", $fname);
      $stmt->bindParam(":mi", $mname);
      $stmt->bindParam(":deptID", $deptID);
      // Set parameters
      
      $param_studnum = $studnum;
      $param_lname = $lname;
      $param_fname = $fname;
      $param_mname = $mname;
      $param_deptID = $deptID;

      // Attempt to execute the prepared statement
      if ($stmt->execute()) {
        // Records created successfully. Redirect to landing page
        header("location: activestudents.php");
        exit();
      } else {
        echo "Oops! Something went wrong. Please try again later.";
      }
    }

    // Close statement
    unset($stmt);
  }

  // Close connection
  unset($pdo);
}
?>