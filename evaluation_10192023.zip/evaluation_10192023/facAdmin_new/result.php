<?php 
require_once "php/core.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="img/csta-logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Results | Faculty Evaluation</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">    <link href="css/sb-admin-2.css" rel="stylesheet"> 
    <link href="css/sb-admin-2.css" rel="stylesheet"> 
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
</head>
<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include_once "includes/sidebar.php" ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include_once "includes/header.php" ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-flex justify-content-between mb-2 align-items-center" >
                        <h1 class="h3 mb-2 text-gray-800">Evaluation Results</h1> 
                    </div>

                    <!-- Display loading message -->
                    <div id="loading-message" style="text-align: center;">
                        Please wait while the data is being fetched...
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4" id="result-table-container" style="display: none;">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="result-table" width="100%" cellspacing="0">
                                    <?php
                                    // Attempt select query execution
                                    $sql = "SELECT a.facNum, CONCAT(a.lname, ' ', a.fname, ' ', IFNULL(a.mi, '')) fullname, a.deptID, a.deptcode
                                            FROM vw_faculties a
                                            JOIN eva b ON
                                            b.fmID = a.facNum
                                            WHERE a.is_deleted = 0
                                            GROUP BY a.facNum, fullname, a.deptID, a.deptcode";

                                    try {
                                        $stmt = $pdo->query($sql);

                                        if ($stmt->rowCount() > 0) {
                                            echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                            echo "<tr>";
                                            echo "<th>Faculty Name</th>";
                                            echo "<th>Department</th>";
                                            echo "<th>Action</th>";
                                            echo "</tr>";
                                            echo "</thead>";
                                            echo "<tbody>";

                                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                echo "<tr>";
                                                echo "<td >{$row['fullname']}</td>";
                                                echo "<td>{$row['deptcode']}</td>";
                                                echo "<td class='col-md-2 text-center'>";
                                                echo "<a href='overallsum.php?faculty={$row['facNum']}&department={$row['deptID']}' class='btn btn-success mr-1' title='View Result' data-toggle='tooltip'><i class='fa fa-eye'></i> View Result</a>";
                                                echo "</td>";
                                                echo "</tr>";
                                            }

                                            echo "</tbody>";

                                            // Show the table and hide the loading message
                                            echo "<script>document.getElementById('loading-message').style.display = 'none';</script>";
                                            echo "<script>document.getElementById('result-table-container').style.display = 'block';</script>";
                                        } else {
                                            // Hide the loading message and show the no records found message
                                            echo "<script>document.getElementById('loading-message').style.display = 'none';</script>";
                                            echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                                        }
                                    } catch (PDOException $e) {
                                        echo "Error: " . $e->getMessage();
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; FACULTY PERFORMANCE EVALUATION SYSTEM 2023</span>                    
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <!-- <script src="js/demo/datatables-demo.js"></script> -->
    <script src="js/function.js"></script>
</body>

</html>