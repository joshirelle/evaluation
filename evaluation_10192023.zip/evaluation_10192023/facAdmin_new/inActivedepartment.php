<?php
// Include config file
require_once "php/core.php";

// Define variables and initialize with empty values
$deptcode = $deptname =  "";
$deptcode = $deptname =  "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate name
  $input_deptcode = trim($_POST["deptcode"]);
  $deptcode = $input_deptcode;
  
  // Validate name
  $input_deptname = trim($_POST["deptname"]);
  $deptname = $input_deptname;
  
  

  // Check input errors before inserting in database
  if (empty($name_err) && empty($address_err) && empty($salary_err)) {
    // Prepare an insert statement
    $sql = "INSERT INTO department (deptcode, deptname) VALUES (:deptcode, :deptname)";

    if ($stmt = $pdo->prepare($sql)) {
      // Bind variables to the prepared statement as parameters    
      $stmt->bindParam(":deptcode", $param_deptcode);
      $stmt->bindParam(":deptname", $param_deptname);
      
      // Set parameters
      
      $param_deptcode = $deptcode;
      $param_deptname = $deptname;
      

      // Attempt to execute the prepared statement
      if ($stmt->execute()) {
        // Records created successfully. Redirect to landing page
        header("location: inactives.php");
        exit();
      } else {
        echo "Oops! Something went wrong. Please try again later.";
      }
    }

    // Close statement
    unset($stmt);
  }

  // Close connection
  unset($pdo);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="img/csta-logo.ico" type="image/x-icon">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Faculty Evaluation</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <li class="nav-item">
                <a class="nav-link" href="./activefaculty.php">
                    <i class="fas fa-light fa-users nav-icon"></i>
                    <span>Faculty</span></a>
            </li>
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item active">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Maintenance</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="./activedepartment.php">Department</a>
                        <a class="collapse-item" href="./questions.php">Questionnaire</a>
                        <a class="collapse-item" href="./user.php">Users</a>
                        <a class="collapse-item" href="./inactives.php">Deactivated Items</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="./result.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Results</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSettings"
                    aria-expanded="true" aria-controls="collapseSettings">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Settings</span>
                </a>
                <div id="collapseSettings" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="./term.php">Term</a>
                        <a class="collapse-item" href="./backimp.php">Backup/Import</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="./activestudents.php">
                <i class="fas fa-light fa-users nav-icon"></i>
                    <span>Students</span></a>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="login.php">Login</a>
                        <a class="collapse-item" href="register.html">Register</a>
                        <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Other Pages:</h6>
                        <a class="collapse-item" href="404.html">404 Page</a>
                        <a class="collapse-item" href="blank.html">Blank Page</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Charts -->       
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include_once "includes/header.php" ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                
                  <!-- Page Heading -->
                <div class="d-flex justify-content-between mb-2 align-items-center" >
                    <h1 class="h3 mb-2 text-gray-800">Inactive Department</h1>
                </div>

                <!-- Restore Modal HTML -->
	        <div id="RestoreDepartmentModal" class="modal">
		        <div class="modal-dialog">
			        <div class="modal-content">
				        <form id="frmDepartmentRestore" action="restoredepartment.php" method="POST">
                  <input type="hidden" id="inputDepartmentID" name="id">
					        <div class="modal-header">						
						        <h4 class="modal-title">Restore Department </h4>
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					        </div>
					        <div class="modal-body">					
						        <p>Are you sure you want to restore this record?</p>
					        </div>
					        <div class="modal-footer">
						        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						        <input type="submit" class="btn btn-primary" value="Restore">
					        </div>
				        </form>
			        </div>
		        </div>
	        </div>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="inactivedepartment-table" width="100%" cellspacing="0">
                                <?php
                                    // Include config file
                                    require_once "php/core.php";
                                    
                                    // Attempt select query execution
                                     $sql = "SELECT
                                    deptID,
                                    deptcode,
                                    deptname
                                    FROM department WHERE is_deleted=1";

                                    if ($result = $pdo->query($sql)) {
                                        if ($result->rowCount() > 0) {
                                        echo "<thead>";
                                        echo "<tr>";
                                        echo "<th>#</th>";
                                        echo "<th>Department Code</th>";
                                        echo "<th>Department Name</th>";
                                        echo "<th>Action</th>";

                                        echo "</tr>";
                                        echo "</thead>";
                                        echo "<tbody>";
                                        while ($row = $result->fetch()) {
                                        echo "<tr>";
                                        echo "<td>" . $row['deptID'] . "</td>";
                                        echo "<td>" . $row['deptcode'] . "</td>";
                                        echo "<td>" . $row['deptname'] . "</td>";
                                        echo "<td>";

                                        echo '<a href="#RestoreDepartmentModal" onclick="passIdToForm('.$row['deptID'].')" data-toggle="modal" class="btn btn-success mr-1" title="Delete Record"  data-toggle="tooltip" data-id=' . $row['deptID'] . '>Restore</a>';
                                        echo "</td>";
                                        echo "</tr>";
                                        }
                                        echo "</tbody>";
                                        echo "</table>";
                                        // Free result set
                                        unset($result);
                                        } else {
                                         echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                                        }
                                        } else {
                                        echo "Oops! Something went wrong. Please try again later.";
                                        }

                                        // Close connection
                                        unset($pdo);
                                ?>
                                    
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



    <!-- ajax -->
  <script>
    $(document).ready(function() {
      $(document).delegate("[href='#updateDepartmentModal']", "click", function() {

        var departmentID = $(this).attr('data-id');

        // Ajax config
        $.ajax({
          type: "GET", //we are using GET method to get data from server side
          url: 'fetchDepartment.php', // get the route value
          data: {
            department_id: departmentID
          }, //set data
          beforeSend: function() { //We add this before send to disable the button once we submit it so that we prevent the multiple click

          },
          success: function(response) { //once the request successfully process to the server side it will return result here
            response = JSON.parse(response);
            $("#edit-form [name=\"department_id\"]").val(response.deptID);
            $("#edit-form [name=\"deptcode\"]").val(response.deptcode);
            $("#edit-form [name=\"deptname\"]").val(response.deptname);
           
            // switch (response.deptcode) {
            //   case "BSIT":
            //     $('#deptcode option[value=1]').attr('selected', 'selected');
            //     break;
            //   case "BSTM":
            //     $('#deptcode option[value=3]').attr('selected', 'selected');

            //     break;
            //   case "BSHM":
            //     $('#deptcode option[value=2]').attr('selected', 'selected');

            //     break;
            //   case "BEED":
            //     $('#deptcode option[value=4]').attr('selected', 'selected');
            //     break;
            //   case "BSED":
            //     $('#deptcode option[value=5]').attr('selected', 'selected');

            //     break;


            //   default:
            //     break;
            // }
          }
        });
      });
    })
  </script>

<script>
    //pass id to frmDelete when delete button clicked
    
    function passIdToForm(id) {
      $("#frmDepartmentRestore").find('#inputDepartmentID').val(id);
    }
  </script>


  <!-- ajax -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- ChartJS -->
  <script src="plugins/chart.js/Chart.min.js"></script>
  <!-- Sparkline -->
  <script src="plugins/sparklines/sparkline.js"></script>
  <!-- JQVMap -->
  <script src="plugins/jqvmap/jquery.vmap.min.js"></script>
  <script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
  <!-- jQuery Knob Chart -->
  <script src="plugins/jquery-knob/jquery.knob.min.js"></script>
  <!-- daterangepicker -->
  <script src="plugins/moment/moment.min.js"></script>
  <script src="plugins/daterangepicker/daterangepicker.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.js"></script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <!-- <script src="js/demo/datatables-demo.js"></script> -->
    <script src="js/function.js"></script>
</body>

</html>