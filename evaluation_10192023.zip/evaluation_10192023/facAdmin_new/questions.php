<?php
    require_once "php/core.php"; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="img/csta-logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Questionnaire Settings</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include_once "includes/sidebar.php" ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include_once "includes/header.php" ?>
                <!-- End of Topbar -->
                <?php
                    $categ_li = "";
                    $categ_tab_content = "";
                    $class_li_active = 'active';
                    $class_tab_active = 'show active';
                    $sql_categ_li = "SELECT * FROM category WHERE isdeleted=0";
                    $query = $pdo->query($sql_categ_li);
                    while($categ_data = $query->fetch()) {
                        $max_name_length = 15;
                        $categ_li_name = strlen($categ_data['catname']) > $max_name_length
                            ? substr($categ_data['catname'], 0, $max_name_length) . '...'
                            : $categ_data['catname'];
                        $categ_li .= "<li class='nav-item' role='presentation'>
                            <button 
                                class='nav-link {$class_li_active} categ-name'
                                id='categ_li_{$categ_data['catID']}'
                                data-bs-target='#categ_{$categ_data['catID']}' data-bs-toggle='pill' type='button' role='tab' aria-controls='pills-categ' aria-selected='true'
                                >
                                {$categ_li_name}
                            </button>
                        </li>";
                        $categ_tab_content .= "
                            <div class='tab-pane fade {$class_tab_active}' id='categ_{$categ_data['catID']}' role='tabpanel' aria-labelledby='pills-categ-tab'>
                                <div class='d-flex justify-content-between my-3 pl-3'>
                                    <h1 class='h3 mt-1 text-gray-800'>{$categ_data['catname']}</h1>
                                    <li style='list-style-type: none;'><a href='#addNewQuestionModal' onclick='addQuestionModal(\"{$categ_data['catID']}\", \"" . htmlspecialchars($categ_data['catname'], ENT_QUOTES) . "\")' class='btn btn-success' data-toggle='modal'><i class='fas fa-plus'></i></a></li>
                                </div>
                                <p class='lead pl-3'>{$categ_data['catdescE']}</p>

                                <!-- DataTales Example -->
                                <div class='card shadow mb-4'>
                                    <div class='card-body'>
                                        <div class='table-responsive'>
                                            <table class='table table-bordered table-striped font-weight-bold text-gray-800' id='categ_{$categ_data['catID']}_questions' width='100%' cellspacing='0'>
                                                <thead style= 'background:#C37C4D; text-align:center; color:white;'>
                                                    <tr>  
                                                        <td class='text-center'>#</td>
                                                        <td>Question - English</td>
                                                        <td>Question - Tagalog</td>
                                                        <td class='text-center'>Action</td>
                                                    </tr>
                                                </thead>
                                                <tbody>";
                                                $sql_categ_question = "SELECT * FROM vwquestions WHERE catID=? AND questionDeactivated=0 AND categoryDeactivated=0";
                                                $pst_categ_question = $pdo->prepare($sql_categ_question);
                                                $pst_categ_question->execute(array($categ_data['catID']));
                                                if($pst_categ_question->rowCount() > 0){
                                                    while($categ_question = $pst_categ_question->fetch()) {
                                                        $categ_tab_content .= "
                                                            <tr>
                                                                <td class='text-center' width='4%'>{$categ_question['quesID']}</td>
                                                                <td width='35%'>{$categ_question['question']}</td>
                                                                <td width='35%'>{$categ_question['questionTagalog']}</td>
                                                                <td class='col-md-2 text-center' style='min-width: 250px;'>
                                                                    <a href='#updateQuestionModal' onclick='passIdToForm(\"updateQuestionModal\",\"" .$categ_data['catID']. "\", \"" . htmlspecialchars($categ_question['quesID'], ENT_QUOTES) . "\", \"" . htmlspecialchars($categ_question['catname'], ENT_QUOTES) . "\", \"" . htmlspecialchars($categ_question['question'], ENT_QUOTES) . "\", \"" . htmlspecialchars($categ_question['questionTagalog'], ENT_QUOTES) . "\")' data-toggle='modal' class='btn btn-success mr-1' title='Update Record' data-toggle='tooltip'><i class='fas fa-edit ml-1'></i>Update</a>
                                                                    <a href='#deleteQuestionModal' onclick='passIdToForm(\"deleteQuestionModal\",\"" .$categ_data['catID']. "\", \"" . htmlspecialchars($categ_question['quesID'], ENT_QUOTES) . "\", \"" . htmlspecialchars($categ_question['catname'], ENT_QUOTES) . "\", \"" . htmlspecialchars($categ_question['question'], ENT_QUOTES) . "\", \"" . htmlspecialchars($categ_question['questionTagalog'], ENT_QUOTES) . "\")' data-toggle='modal' class='btn btn-danger mr-1' title='Delete Record' data-toggle='tooltip' data-id='{$categ_question['quesID']}'><i class='fa fa-thumbs-down'></i> Deactivate</a>
                                                                </td>
                                                            </tr>
                                                        ";
                                                    
                                                    }
                                                }else{
                                                    $categ_tab_content .= "
                                                        <tr>
                                                            <td class='text-center' colspan='4'>NO RECORDS</td>
                                                        </tr>
                                                        ";
                                                }

                                                $categ_tab_content .=
                                                "</tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ";

                        // only first categ should be active after loading page
                        $class_li_active = '';
                        $class_tab_active = '';
                    }
                ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-flex justify-content-between mb-2 align-items-center">
                        
                        <div>
                            <h1 class="h3 text-gray-800">Questionnaire Settings</h1>
                        </div> <!-- Empty column for left side content -->
                        
                        <div> <!-- Right-aligned column -->
                            <a href="#addCategoryModal" class="btn btn-primary" data-toggle="modal"><span><i class='fas fa-plus'></i></span></a>
                            <a href="#updateCategoryModal" onclick="getCategory('updateCategoryModal')" class="btn btn-success" data-toggle="modal"><span><i class='fas fa-edit'></i> </span></a>
                            <a href="#deleteCategoryModal" onclick="getCategory('deleteCategoryModal')" class="btn btn-danger" data-toggle="modal"><span><i class='fa fa-thumbs-down'></i></span></a>
                        </div>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])) : ?>
                        <div class='alert alert-success text-center' role='alert' id='api_response'>
                            <b>
                                <?php
                                    echo $_SESSION['success'];
                                    unset($_SESSION['success']);
                                ?>
                            </b>
                        </div>
                    <?php endif; ?>
                    <!-- Add Modal HTML -->
                    
                    <ul class="nav nav-tabs" id="pills-tab" role="tablist">
                        <?=$categ_li?>       
                    </ul>

                    <div id="addCategoryModal" class="modal fade" data-backdrop="static" data-keyboard="false">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <form action="php/question.php" method="POST">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Add New Category</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>Category Name:</label>
                                            <input type="text" name="category_name" placeholder=" " class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Category Desc:</label>
                                            <input type="text" name="category_desc" placeholder=" " class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <input type="submit" class="btn btn-success" name="create_category" value="Add">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div id="updateCategoryModal" class="modal fade" data-backdrop="static" data-keyboard="false">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <form action="php/question.php" method="POST">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Update Category</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        
                                        <div class="form-group text-center" id="wait_dialogue_update">
                                            <span>PLEASE WAIT</span>
                                        </div>
                                        <div id="category_list">
                                        </div>
                                        <div id="div_update_category" hidden>
                                            <div class="form-group">
                                                <label>Category Name:</label>
                                                <input type="text" name="category_name" placeholder=" " class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Category Desc:</label>
                                                <input type="text" name="category_desc" placeholder=" " class="form-control" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <input type="submit" class="btn btn-success" name="update_category" value="Update">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div id="deleteCategoryModal" class="modal fade" data-backdrop="static" data-keyboard="false">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <form action="php/question.php" method="POST">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Deactivate Category</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        
                                        <div class="form-group text-center" id="wait_dialogue_update">
                                            <span>PLEASE WAIT</span>
                                        </div>
                                        <div id="category_list">
                                        </div>
                                        <div id="div_update_category" hidden>
                                            <div class="form-group">
                                                <label>Category Name:</label>
                                                <input type="text" name="category_name" placeholder=" " class="form-control" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label>Category Desc:</label>
                                                <input type="text" name="category_desc" placeholder=" " class="form-control" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <input type="submit" class="btn btn-danger" name="delete_category" value="Deactivate">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Add Modal HTML -->
                    <div id='addNewQuestionModal' class='modal fade' data-backdrop="static" data-keyboard="false">
                        <div class='modal-dialog modal-dialog-centered modal-lg'>
                            <div class='modal-content'>
                                <form action='php/question.php' method='POST'>
                                    <div class='modal-header'>
                                        <h4 class='modal-title'><span id="category_title"></span> | Add New Question</h4>
                                        <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
                                    </div>
                                    <div class='modal-body'>
                                        <input type="hidden" name="category_id"/>
                                        <div class='form-group'>
                                            <label>Question (English):</label>
                                            <textarea id="questionTextarea" name="qe" class="form-control" required></textarea>
                                        </div>
                                        <div class='form-group'>
                                            <label>Question (Tagalog):</label>
                                            <textarea id="tagalogTextarea" name="qt" class="form-control" required></textarea>
                                        </div>
                                    </div>
                                    <div class='modal-footer'>
                                        <input type='button' class='btn btn-default' data-dismiss='modal' value='Cancel'>
                                        <input type='submit' class='btn btn-success' name='create' value='Add'>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div id="updateQuestionModal" class="modal fade" data-backdrop="static" data-keyboard="false">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <form action="php/question.php" method="POST">
                                    <div class="modal-header">
                                        <h4 class="modal-title"></h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="category_id"/>
                                        <input type="hidden" name="ques_id"/>
                                        <div class="form-group">
                                            <label>Question English</label>
                                            <textarea name="qe" class="form-control" required></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Question Tagalog</label>
                                            <textarea name="qt" class="form-control" required></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <input type="submit" class="btn btn-success" name="update" value="Update">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div id="deleteQuestionModal" class="modal fade" data-backdrop="static" data-keyboard="false">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <form action="php/question.php" method="POST">
                                    <div class="modal-header">
                                        <h4 class="modal-title"></h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div>Are you sure you want to deactivate <b><span id="lbl_category_id"></span></b>?</div>
                                        <input type="hidden" name="category_id"/>
                                        <input type="hidden" name="ques_id"/>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                        <input type="submit" class="btn btn-danger" name="delete" value="Deactivate">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="tab-content" id="pills-tabContent">
                                <?=$categ_tab_content?>

                            </div><!--tabcontent-->
                        </div>
                    </div>           
                </div><!-- /.container-fluid -->
        </div><!-- End of Main Content -->


            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; FACULTY PERFORMANCE EVALUATION SYSTEM 2023</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <script>
        function passIdToForm(modal, catID, quesID, catName, qe, qt) {
            if(modal = "deleteQuestionModal"){
                $(`#${modal}`).find('input[name="category_id"]').val(catID);
                $(`#${modal}`).find('input[name="ques_id"]').val(quesID);
                $(`#${modal}`).find('.modal-title').text(catName+" | #"+quesID);
                $(`#${modal}`).find('#lbl_category_id').text(catName+" Question #"+quesID);
                
            }
            if(modal = "updateQuestionModal"){
                $(`#${modal}`).find('input[name="category_id"]').val(catID);
                $(`#${modal}`).find('input[name="ques_id"]').val(quesID);
                $(`#${modal}`).find('.modal-title').text(catName+" | #"+quesID);
                $(`#${modal}`).find('textarea[name="qe"]').val(qe);
                $(`#${modal}`).find('textarea[name="qt"]').val(qt);
            }
        }

        function addQuestionModal(catID, catName) {
            $('#addNewQuestionModal').find('#category_title').text(catName);
            $('#addNewQuestionModal').find('input[name="category_id"]').val(catID);
            $('#addNewQuestionModal').find('input[name="category_name"]').val(catName);
        }

        var check_exist;
        function getCategory(modal) {
            $.ajax({
                type: "POST",
                url: 'php/question.php',
                data: {
                    get_category: "get_all_category"
                },
                dataType: 'json', // specify data type as JSON
                success: function(response) {
                    
                    $(`#${modal} #wait_dialogue_update`).hide();

                    if (response && response.length > 0) {
                        $(`#${modal} #category_list`).empty(); // clear the dropdown before appending new options
                        $(`#${modal} #category_list`).append(`
                                <div class="form-group">
                                    <label>Choose Category:</label>
                                    <select name="category_id" id="sel_category_list" class="form-control" required>
                                        <option value="" disabled selected>-- SELECT CATEGORY --</option>
                                    </select>
                                </div>
                            `);
                        response.forEach(item => {
                            $(`#${modal} #sel_category_list`).append(`
                                <option value="${item.catID}" data-name="${item.catname}" data-desc="${item.catdescE}">${item.catname}</option>
                            `);
                        });

                        $(`#${modal}`).on('hidden.bs.modal', function () {
                            $(`#${modal} #div_update_category`).hide();
                            // Clear input fields in the div
                            $(`#${modal} #div_update_category`).find('input[name="category_name"]').val('');
                            $(`#${modal} #div_update_category`).find('input[name="category_desc"]').val('');
                        });

                        $(`#${modal}`).on('change', '#sel_category_list', function() {
                            var selectedOption = $(`#${modal} #sel_category_list option:selected`);
                            var name = $(selectedOption).data('name');
                            var desc = $(selectedOption).data('desc');

                            $(`#${modal} #div_update_category`).find('input[name="category_name"]').val('');
                            $(`#${modal} #div_update_category`).find('input[name="category_desc"]').val('');
                            if($(this).val()){
                                if($(`#${modal} #div_update_category`).is(':hidden')){
                                    $(`#${modal} #div_update_category`).removeAttr('hidden').css({
                                        'display': 'none',  // Set initial display property to 'none' for fade-in effect
                                        'opacity': 0,       // Set initial opacity to 0 for fade-in effect
                                    }).show(500).animate({
                                        'opacity': 1       // Animate opacity to 1 for fade-in effect
                                    }, 500);
                                }
                            }else{
                                $(`#${modal} #div_update_category`).hide();
                                // Clear input fields in the div
                                $(`#${modal} #div_update_category`).find('input[name="category_name"]').val('');
                                $(`#${modal} #div_update_category`).find('input[name="category_desc"]').val('');
                            }

                            $(`#${modal}`).find('input[name="category_name"]').val(name);
                            $(`#${modal}`).find('input[name="category_desc"]').val(desc);
                        });
                    } else {
                        console.log('No data received or empty response.'); // handle empty response
                    }
                },
                error: function(result) {
                    console.log(result); // handle errors
                }
            });
        }


        
        $(document).ready(function() {
            $('#addNewQuestionModal').on('hidden.bs.modal', function() {
                // Reset the textarea values when the modal is closed
                $('#addNewQuestionModal').find('#questionTextarea').val('');
                $('#addNewQuestionModal').find('#tagalogTextarea').val('');
            });

            if ($('#api_response').is(':visible')) {
                setTimeout(function(){
                    $('#api_response').fadeOut('slow'); // 'slow' specifies the duration of the fade effect
                }, 5000); // 5000 milliseconds = 5 seconds
            }
            
            
        });
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <script src="js/function.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>