<?php
    require_once "php/core.php";

    $request = $_GET; //a PHP Super Global variable which used to collect data after submitting it from the form
	$facultyId = $request['faculty_id'];//define the employee ID

	// Set the INSERT SQL data
	$sql = "SELECT
    facNum,
    facID,
    lname,
    fname,
    mi,
    deptID,
    deptcode
    FROM vw_faculties
    WHERE facNum='$facultyId'";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $result = [];
    if ($fetch = $stmt->fetch()) {
        $result = [
            "facNum" => $fetch["facNum"],
            "facID" => $fetch["facID"],
            "lname" => $fetch["lname"],
            "fname" => $fetch["fname"],
            "mi" => $fetch["mi"],
            "deptID" => $fetch["deptID"],
            "deptcode" => $fetch["deptcode"]
        ];
    }
    echo json_encode($result);

    // if ($result = $pdo->query($sql)) {
    //     if ($result->rowCount() > 0) {
    //         while ($row = $result->fetch()) {
    //             echo json_encode($row);
    //         }
    //     }
    // }
    unset($result);
    unset($pdo);
?>