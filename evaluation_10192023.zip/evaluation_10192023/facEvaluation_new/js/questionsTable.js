const processURL = baseURL + '/process-questions.php';
const loginURL = baseURL + '/login.php';

const questionsTable = document.querySelector('#questionsTable');
const btnPager = document.querySelectorAll('.btn-pager');
const questionForm = document.querySelector('#question-form');

let categ_rows = document.querySelectorAll('[data-catid]');

let current_url = new URL(window.location);
let current_categID = current_url.searchParams.get('categ');

let questions = document.querySelectorAll('.data-input');

categ_rows.forEach(row => {
    if($(row).data('catid') == current_categID) {
        $(row).show();
    } else {
        $(row).hide();
    }
});

btnPager.forEach(btn => {
    $(btn).on('click', () => {
        // very first next button that loads in questionnaire will have this function
        if(validateRadioButtons() === true) {
            updateCategName($(btn).data('catPage'));
            updateBtn($(btn).data('catPage'));
            updateTable($(btn).data('catPage'));
        }
    });
});

questionForm.addEventListener('submit', (e) => {
    // here happens after clicking submit button
    e.preventDefault();

    let evaluations = {};

    questions.forEach(question => {
        if(question.checked){
            let key = question.getAttribute('name');
            let value = question.getAttribute('value');
            evaluations[key] = value;
        }
    });

    popup(
        'Are you sure you want to submit this evaluation?', // title
        '', // body text
        'question', // icon
        [true, 'Yes'], // confirm button
        [true, 'No'] // deny button
    ).then((result) => {
        if(result.isConfirmed) {
            //this happens when confirm button is clicked.
            //do ajax here
            post(processURL, {
                process: 'submit-evaluation',
                answers: evaluations,
                comment: $('#txtComment').val()
            }).done(response => {
                console.log(response);
                popup('Evaluation has been submitted successfully!', '', 'success');
                popup(
                    'Do you want to evaluate another Faculty?',
                    '',
                    'question',
                    [true, 'Yes, I want to evaluate again.'],
                    [true, 'No']
                ).then((result) => {
                    
                    let dept = $('[data-return-type=department]').data('return-id');
                    let stud = $('[data-return-type=student]').data('return-id');
                    let fac = $('[data-return-type=faculty]').data('return-id');

                    if(result.isConfirmed) {
                        //after clicking yes button...
                        newURL = `${loginURL}?stud=${stud}&dept=${dept}&fac=${fac}`

                        window.location.replace(newURL);
                    } else {
                        //after clicking no button...
                        window.location.replace(loginURL);
                    }
                });
            });
        } else if(result.isDenied) {
            //this happens when deny button is clicked
            window.location.replace(loginURL);
        }
    });
});

function getVisibleRadioButtons() {
    return $('tr[data-catID]:visible');
}

function validateRadioButtons() {
    let valid = true;
    getVisibleRadioButtons().each(function () {
        let name_attr = $(this).find('input.data-input[type=radio]').attr('name');
        let radio = $(this).find(`input.data-input[type=radio][name=${name_attr}]:checked`).val();
        if(typeof(radio) === "undefined") {
            popup('Oops!', 'Please fill all the fields', 'warning');
            valid = false;
            return valid; // break from $.each loop
        }
    });

    return valid;
}

function updateBtn(categID) {
    post(processURL, {
        process: 'get-category-btn',
        categID: categID
    }).done(response => {
         //must receive array from response
         try {
            //refresh div first before generating button
            
            $('#btn-page-holder').html('');

            let result = JSON.parse(response);

            let prevBtn;
            let nextBtn;

            //generate button if value is not undefined
            if(typeof(result.prev) != 'undefined') {
                prevBtn = $('<button>', {
                    text: 'Previous',
                    class: 'd-block btn btn-primary',
                    type: 'button'
                }).on('click', () => {
                    updateCategName(result.prev);
                    updateBtn(result.prev);
                    updateTable(result.prev);
                });

                //add to div
                $('#btn-page-holder').prepend(prevBtn);
            } else {
                $('#btn-page-holder').prepend('<div></div>');
            }

            if(typeof(result.next) != 'undefined') {
                nextBtn = $('<button>', {
                    text: 'Next',
                    class: 'd-block btn btn-primary',
                    type: 'button'
                }).on('click', () => {
                    if(validateRadioButtons() === true) {
                        updateCategName(result.next);
                        updateBtn(result.next);
                        updateTable(result.next);
                    }
                });

                //add to div
                $('#btn-page-holder').append(nextBtn);
            }

            //if buttons has no next means it is last page
            if(typeof(result.next) == 'undefined') {
                // Last page must contain comment/feedback section

                nextBtn = $('<button>', {
                    text: 'Next',
                    class: 'btn btn-primary btnNext',
                    type: 'button'
                }).on('click', () => {
                    if(validateRadioButtons() === true) {
                        $(nextBtn).hide();
                        switchToCommentSection(categID);
                    }
                });

                $('#btn-page-holder').append(nextBtn);
                

            } else {
                $('#btnSubmit').hide();
            }

        } catch (error) {
            // notify in website if error
            // console.log(error);
        }
    })
}

function switchToCommentSection(categID) {
    //refresh div first before generating button
    $('#btn-page-holder').html('');
    prevBtn = $('<button>', {
        text: 'Previous',
        class: 'd-block btn btn-primary',
        type: 'button'
    }).on('click', () => {
        $('#btnSubmit').hide(); // ensure to hide Submit button
        updateCategName(categID);
        updateBtn(categID);
        updateTable(categID);
    });

    //add prevBtn to div
    $('#btn-page-holder').prepend(prevBtn);

    $('#catname-holder').text('Feedback and Suggestions (Optional)'); // Set category name for last page
    $('#questionsTable').addClass('d-none'); // hide table
    $('#txtComment').removeClass('d-none'); // show comment textarea

    $('#btnSubmit').show(); // allow user to finally submit
}

function updateTable(categID) {

    $('#questionsTable').removeClass('d-none');
    $('#txtComment').addClass('d-none');

    categ_rows.forEach(tr => {
        if($(tr).data('catid') == categID) {
            $(tr).show();
        } else {
            $(tr).hide();
        }
    });
}

function updateCategName(categID) {
    post(processURL, {
        process: 'get-category-name',
        categID: categID
    }).done(response => {
        try {
            let res = JSON.parse(response);
            $('#catname-holder').text(res.categ_name + " " + res.categ_num + "/" + res.categ_count);

        } catch (error) {
            //error
            console.log(error);
        }
    });
}