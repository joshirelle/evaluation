const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
      confirmButton: 'px-4 mx-2 btn btn-success',
      denyButton: 'px-4 mx-2 btn btn-danger',
      cancelButton: 'px-4 mx-2 btn btn-secondary'
    },
    buttonsStyling: false
});

function post(url, data) {
    //ajax
    //for post method
    let settings = {
        type: 'POST',
        url: url,
        data: data
    };

    return $.ajax(settings);
}

function popup(title='', body='', icon='success', confirm=[true, 'OK'], deny=[false, 'No']) {
    return swalWithBootstrapButtons.fire({
        title: title,
        text: body,
        icon: icon,
        showConfirmButton: confirm[0],
        confirmButtonText: confirm[1],
        showDenyButton: deny[0],
        denyButtonText: deny[1]
    });
}