<?php
session_start();
require 'connection.php';

//check if the data is from POST method
if($_SERVER['REQUEST_METHOD'] === 'POST')
{
    if($_POST['process'] === 'update-cmbx-fac') {
        $dept_id = htmlspecialchars($_POST['deptID']);
        $stud_num = htmlspecialchars($_POST['studnum']);

        $sql = "SELECT a.facID, a.facNum, CONCAT(a.lname, ' ', a.fname, ' ', IFNULL(a.mi, '')) fullname, a.deptID, a.deptCode, a.deptname, a.is_deleted
                FROM vw_faculties a
                WHERE a.deptID = $dept_id AND a.is_deleted = 0 
                AND facNum NOT IN (SELECT fmID FROM eva WHERE fmID = a.facNum AND studNum = '$stud_num')";
        $pst = $pdo->prepare($sql);
        $pst->execute();
        while($data = $pst->fetch())
        {
            $option = "";
            // if(isset($_SESSION['remove_fac'])) {
            //     if(isset($_SESSION['remove_fac'][$stud_num])) {
            //         if(!in_array($data['facNum'], $_SESSION['remove_fac'][$stud_num])) {
            //             $option = "<option value='{$data['facID']}'>" . $data['fullname'] . "</option>";
            //         }
            //     } else {
            //         $option = "<option value='{$data['facID']}'>" . $data['fullname'] . "</option>";
            //     }

               
            // } else {
            //     $option = "<option value='{$data['facID']}'>" . $data['fullname'] . "</option>";
            // }
            $option = "<option value='{$data['facID']}'>" . $data['fullname'] . "</option>";

            echo $option;
        }
    } elseif ($_POST['process'] === 'login-submit') {
        //need to validate inputs here
        $dept_id_valid = false;
        $fac_id_valid = false;
        $stud_num_valid = false;
        $response = [];

        $studnum = htmlspecialchars($_POST['studnum']);

        if(!empty($_POST['deptID'])) {
            $dept_id_valid = true;
        }
        if(!empty($_POST['facID'])) {
            $fac_id_valid = true;
        }
        if(!empty($_POST['studnum']) && preg_match('/^\d{2}[-]\d{5}$/', $studnum)) {
            $stud_num_valid = true;
        }

        $response = [
            'dept_id_valid' => $dept_id_valid,
            'fac_id_valid' => $fac_id_valid,
            'stud_num_valid' => $stud_num_valid
        ];

        if($dept_id_valid && $fac_id_valid && $stud_num_valid)
        {
            //make sure all is valid
            $facID = htmlspecialchars($_POST['facID']);
            $deptID = htmlspecialchars($_POST['deptID']);
    
            $sql = "SELECT facID, facNum, CONCAT(lname, ' ', fname, ' ', IFNULL(mi, '')) fullname, deptID, deptCode, deptname, is_deleted 
            FROM vw_faculties WHERE facID = :facID AND deptID = :deptID";
            $pst = $pdo->prepare($sql);
            $pst->execute([':facID'=>$facID,
                            ':deptID'=>$deptID]);
            $data = $pst->fetch();

            $_SESSION['faculty_name'] = $data['fullname'];
            $_SESSION['department_name'] = $data['deptname'];

            //keep these until student submits the evaluation
            $_SESSION['facID'] = $facID;
            $_SESSION['deptID'] = $deptID;
            $_SESSION['fmID'] = $data['facNum'];
            $_SESSION['student_number'] = $studnum;
        }

        exit(json_encode($response));

    } elseif ($_POST['process'] === 'get-student-dept') {
        $stud_num = htmlspecialchars($_POST['studnum']);
        
        $sql = "SELECT * FROM vwstud WHERE studnum=:stud_num";
        $pst = $pdo->prepare($sql);
        $pst->execute([':stud_num'=>$stud_num]);
        $data = $pst->fetch();
        $department = array(
            'deptid' => $data['deptID'], 
            'deptname' => $data['deptname']
        );
        exit(json_encode($department));

    }
}