<?php
    require_once "connection.php";

    $request = $_GET; //a PHP Super Global variable which used to collect data after submitting it from the form
	$facultyId = $request['faculty_id'];//define the employee ID

	// Set the INSERT SQL data
	$sql = "SELECT
    facID,
    facNum,
    lname,
    fname,
    mi,
    deptID
    FROM vw_faculties
    WHERE facID=?";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(array($facultyId));

    $result = [];
    if ($fetch = $stmt->fetch()) {
        $result = [
            "facID" => $fetch["facID"],
            "facNum" => $fetch["facNum"],
            "lname" => $fetch["lname"],
            "fname" => $fetch["fname"],
            "mi" => $fetch["mi"],
            "deptID" => $fetch["deptID"]
        ];
    }
    echo json_encode($result);

    // if ($result = $pdo->query($sql)) {
    //     if ($result->rowCount() > 0) {
    //         while ($row = $result->fetch()) {
    //             echo json_encode($row);
    //         }
    //     }
    // }
    unset($result);
    unset($pdo);
?>