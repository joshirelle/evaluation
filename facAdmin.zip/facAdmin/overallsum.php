<?php
    // Include config file
    require_once "connection.php"; 
    $fmID = htmlspecialchars($_GET['faculty']);
    $deptID = htmlspecialchars($_GET['department']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Faculty Evaluation</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15">
                </div>
                <div class="sidebar-brand-text mx-3">Admin</div>
            </a>
            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading"> Interface </div>

            <li class="nav-item">
                <a class="nav-link" href="./activefaculty.php">
                    <i class="fas fa-light fa-users nav-icon"></i>
                    <span>Faculty</span>
                </a>
            </li>
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                <i class="fas fa-fw fa-table"></i>
                    <span>Maintenance</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="./activedepartment.php">Department</a>
                        <a class="collapse-item" href="./questions.php">Questionnaire</a>
                        <a class="collapse-item" href="./user.php">Users</a>
                        <a class="collapse-item" href="./inactives.php">Deactivated Items</a>
                        <a class="collapse-item" href="./inActivefaculty.php">InActive Faculty</a>
                        <a class="collapse-item" href="./inActivestudents.php">InActive Students</a>
                        <a class="collapse-item" href="./inActivedepartment.php">InActive Department</a>
                        <a class="collapse-item" href="./inActiveuser.php">InActive Users</a>
                    </div>
                </div>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="./result.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Results</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSettings"
                    aria-expanded="true" aria-controls="collapseSettings">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Settings</span>
                </a>
                <div id="collapseSettings" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="./term.php">Term</a>
                        <a class="collapse-item" href="./backimp.php">Backup/Import</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="activestudents.php">
                <i class="fas fa-light fa-users nav-icon"></i>
                    <span>Students</span>
                </a>
            </li>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="login.html">Login</a>
                        <a class="collapse-item" href="register.html">Register</a>
                        <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
                            <div class="collapse-divider"></div>
                                <h6 class="collapse-header">Other Pages:</h6>
                                <a class="collapse-item" href="404.html">404 Page</a>
                                <a class="collapse-item" href="blank.html">Blank Page</a>
                    </div>
                </div>
            </li>       
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="button">
                                                    <i class="fas fa-search fa-sm"></i>
                                                </button>
                                            </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">ADMIN</span>
                                <img class="img-profile rounded-circle" src="img/student.jpg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i> Profile </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal"><i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <?php
                    $stmt = "SELECT * FROM vwfacultymembers WHERE fmID=?";
                    $stmt = $pdo->prepare($stmt);
                    $stmt->execute(array($fmID));
                    $fm_result = $stmt->fetch();
                ?>
                <?php // count students that evaluated
                    $sql_s = "SELECT * FROM vweva WHERE fm_fmID=? AND fm_deptID=? AND f_is_deleted=0 GROUP BY studnum";
                    $stmt_s = $pdo->prepare($sql_s);
                    $stmt_s->execute(array($fmID, $deptID));
                    $evaluator_count = $stmt_s->rowCount();
                ?>

                <div class="container-fluid">
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="card shadow">
                                <div class="card-body m-2">
                                    <div class="row mb-3">
                                        <div class="col-6 mt-2">
                                            <p class="pb-2"style="font-weight:bold; text-align: left; font-size:20px;"> FACULTY NAME: <?=$fm_result['fullname']?></p>
                                            <p class="pt-2"style="font-weight:bold;"> DEPARTMENT: <?="{$fm_result['deptname']} ({$fm_result['deptcode']})"?></p>
                                        </div>
                                        <div class="col-6 text-right">
                                            <button class="btn btn-secondary btn-lg mb-2" style="margin-top:25px;" id="printbtn"><i class="fa fa-print"></i> Print Result</button>
                                                <script>
                                                    const printbtn = document.getElementById("printbtn");
                                                    printbtn.addEventListener("click", ()=>{document.print();
                                                    })
                                                </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                                    
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2 py-2 align-items-center">
                                <div class="container-fluid">
                                    <div class="row mb-4">
                                        <h3 class="text-gray-900"> Overall Summary </h3>
                                    </div>

                                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-rating" type="button" role="tab" aria-controls="pills-home" aria-selected="true"> RATINGS </button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-comments" type="button" role="tab" aria-controls="pills-profile" aria-selected="false"> COMMENTS </button>
                                        </li>
                                        
                                    </ul>
                                    <div class="tab-content" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="pills-rating" role="tabpanel" aria-labelledby="pills-home-tab">
                                            <div class="row py-5">
                                                <div class="col-12">
                                                    <?php
                                                        $i=0;
                                                        $eval_summary=[];
                                                        $overall_sum=0;
                                                        $overall_total=0;
                                                        $question_count=0;
                                                        $categ_total=0;
                                                        $date_evaluated = "";
                                                        $sy="";
                                                        $term="";
                                                        $sql_1 = "SELECT * FROM vweva WHERE fm_fmID=? GROUP BY catID";
                                                        $stmt_1 = $pdo->prepare($sql_1);
                                                        $stmt_1->execute(array($fmID));
                                                        while($c_result = $stmt_1->fetch()) :
                                                            $date_evaluated = $c_result['date_evaluated'];
                                                            $sy=$c_result["school_year"];
                                                            $term=$c_result["term"];
                                        
                                                    ?>
                                                        <div class="table-responsive">
                                                            <table class="table table-striped" width="100%" cellspacing="0">
                                                                <thead>
                                                                    <tr>
                                                                        <th colspan=8><p class="text-center m-0"> <?=$c_result['catname']?> </p></th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Question</th>
                                                                        <th>5</th>
                                                                        <th>4</th>
                                                                        <th>3</th>
                                                                        <th>2</th>
                                                                        <th>1</th>
                                                                        <th class="text-right"> Weighted Average </th>
                                                                        <th class="text-right"> Remarks </th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php
                                                                        $sql_2 = "SELECT * FROM vweva WHERE fm_fmID=? AND catID=? GROUP BY quesID";
                                                                        $stmt_2 = $pdo->prepare($sql_2);
                                                                        $stmt_2->execute(array($fmID, $c_result['catID']));
                                                                        $q_count = $stmt_2->rowCount(); // count how many questions are in the category
                                                                                
                                                                                $total5 = 0;
                                                                                $total4 = 0;
                                                                                $total3 = 0;
                                                                                $total2 = 0;
                                                                                $total1 = 0;
                                                                                
                                                                        while($q_result = $stmt_2->fetch()) :
                                                                            $total = $q_count*5; //find total multiply by 5
                                                                    ?>
                                                                        <tr>
                                                                            <td><?=$q_result['question']?></td>
                                                                            <?php // to count number of student that rated the faculty member
                                                                                $sql_3 = "SELECT * FROM vweva WHERE fm_fmID=? AND quesID=?";
                                                                                $stmt_3 = $pdo->prepare($sql_3);
                                                                                $stmt_3->execute(array($fmID, $q_result['quesID']));
                                                                                $student_count = $stmt_3->rowCount();
                                                                            ?>
                                                                            <?php 
                                                                                
                                                                                for ($i=5; $i > 0; $i--) :
                                                                            ?>
                                                                                <?php //(5) to count percentages for each rating
                                                                                    if($i == 5){
                                                                                        $sql_4 = "SELECT * FROM vweva WHERE fm_fmID=? AND quesID=? AND choices=?";
                                                                                        $stmt_4 = $pdo->prepare($sql_4);
                                                                                        $stmt_4->execute(array($fmID, $q_result['quesID'], $i));
                                                                                        $rating_count = $stmt_4->rowCount(); // the number of people that rated 1, 2, 3, 4, or 5
                                                                                        if($rating_count > 0){
                                                                                            
                                                                                            // $percentage = number_format(($rating_count / $student_count) * 100, 2);
                                                                                            // $percentage.="%";

                                                                                            $bilang = $rating_count;
        
                                                                                            if($bilang <= 0) {
                                                                                                $bilang = 0 ; // reset to blank (-) if no value
                                                                                            }

                                                                                            echo "<td>{$bilang}</td>";
                                                                                        } else {
                                                                                            echo "<td> 0 </td>";
                                                                                        }
                                                                                        
                                                                                        $total5+=$rating_count;
                                                                                    }
                                                                                ?>
                                                                                <?php //(4) to count percentages for each rating
                                                                                    if($i == 4){
                                                                                        $sql_4 = "SELECT * FROM vweva WHERE fm_fmID=? AND quesID=? AND choices=?";
                                                                                        $stmt_4 = $pdo->prepare($sql_4);
                                                                                        $stmt_4->execute(array($fmID, $q_result['quesID'], $i));
                                                                                        $rating_count = $stmt_4->rowCount(); // the number of people that rated 1, 2, 3, 4, or 5
                                                                                        if($rating_count > 0){
                                                                                            
                                                                                            // $percentage = number_format(($rating_count / $student_count) * 100, 2);
                                                                                            // $percentage.="%"
                                                                                            $bilang = $rating_count;
        
                                                                                            if($bilang <= 0) {
                                                                                                $bilang = 0; // reset to blank (-) if no value
                                                                                            }

                                                                                            echo "<td>{$bilang}</td>";
                                                                                        } else {
                                                                                            echo "<td> 0 </td>";
                                                                                        }

                                                                                        $total4+=$rating_count;
                                                                                    }
                                                                                ?>
                                                                                <?php //(3) to count percentages for each rating
                                                                                    if($i == 3){
                                                                                        $sql_4 = "SELECT * FROM vweva WHERE fm_fmID=? AND quesID=? AND choices=?";
                                                                                        $stmt_4 = $pdo->prepare($sql_4);
                                                                                        $stmt_4->execute(array($fmID, $q_result['quesID'], $i));
                                                                                        $rating_count = $stmt_4->rowCount(); // the number of people that rated 1, 2, 3, 4, or 5
                                                                                        if($rating_count > 0){
                                                                                            
                                                                                            // $percentage = number_format(($rating_count / $student_count) * 100, 2);
                                                                                            // $percentage.="%";
                                                                                            $bilang = $rating_count;
        
                                                                                            if($bilang <= 0) {
                                                                                                $bilang = 0 ; // reset to blank (-) if no value
                                                                                            }

                                                                                            echo "<td>{$bilang}</td>";
                                                                                        } else {
                                                                                            echo "<td> 0 </td>";
                                                                                        }
                                                                                        
                                                                                        $total3+=$rating_count;
                                                                                    }
                                                                                ?>
                                                                                <?php //(2) to count percentages for each rating
                                                                                    if($i == 2){
                                                                                        $sql_4 = "SELECT * FROM vweva WHERE fm_fmID=? AND quesID=? AND choices=?";
                                                                                        $stmt_4 = $pdo->prepare($sql_4);
                                                                                        $stmt_4->execute(array($fmID, $q_result['quesID'], $i));
                                                                                        $rating_count = $stmt_4->rowCount(); // the number of people that rated 1, 2, 3, 4, or 5
                                                                                        if($rating_count > 0){
                                                                                            
                                                                                            // $percentage = number_format(($rating_count / $student_count) * 100, 2);
                                                                                            // $percentage.="%";
                                                                                            $bilang = $rating_count;
        
                                                                                            if($bilang <= 0) {
                                                                                                $bilang = 0; // reset to blank (-) if no value
                                                                                            }

                                                                                            echo "<td>{$bilang}</td>";
                                                                                        } else {
                                                                                            echo "<td> 0 </td>";
                                                                                        }
                                                                                        
                                                                                        $total2+=$rating_count;
                                                                                    }
                                                                                ?>
                                                                                <?php //(1) to count percentages for each rating
                                                                                    if($i == 1){
                                                                                        $sql_4 = "SELECT * FROM vweva WHERE fm_fmID=? AND quesID=? AND choices=?";
                                                                                        $stmt_4 = $pdo->prepare($sql_4);
                                                                                        $stmt_4->execute(array($fmID, $q_result['quesID'], $i));
                                                                                        $rating_count = $stmt_4->rowCount(); // the number of people that rated 1, 2, 3, 4, or 5
                                                                                        if($rating_count > 0) {
                                                                                            
                                                                                            // $percentage = number_format(($rating_count / $student_count) * 100, 2);
                                                                                            // $percentage.="%";
                                                                                            $bilang = $rating_count;
        
                                                                                            if($bilang <= 0) {
                                                                                                $bilang = 0; // reset to blank (-) if no value
                                                                                            }

                                                                                            echo "<td>{$bilang}</td>";
                                                                                        } else {
                                                                                            echo "<td> 0 </td>";
                                                                                        }

                                                                                        $total1+=$rating_count;
                                                                                    }
                                                                                ?>
                                                                            <?php 
                                                                                endfor;

                                                                                $sql_5 = "SELECT AVG(choices) AS catave FROM vweva WHERE fm_fmID=? AND quesID=?";
                                                                                $stmt_5 = $pdo->prepare($sql_5);
                                                                                $stmt_5->execute(array($fmID, $q_result['quesID']));
                                                                                $ques_ave = $stmt_5->fetch();
                                                                                $ques_round = number_format($ques_ave['catave'], 2);

                                                                                $sql_remark5 = "SELECT * FROM choice WHERE choices=ROUND(?)";
                                                                                $stmt_remark5 = $pdo->prepare($sql_remark5);
                                                                                $stmt_remark5->execute(array($ques_round));
                                                                                $remark_result5 =$stmt_remark5->fetch();

                                                                                echo "<td class='text-right'>{$ques_round} </td>";
                                                                                echo "<td class='text-right'>{$remark_result5['description']} </td>";
                                                                            ?>
                                                                        </tr>
                                                                        
                                                                    <?php 
                                                                        endwhile;
                                                                    ?>
                                                                
                                                                </tbody>
                                                                <tfoot>
                                                                    <tr>
                                                                        <td class="text-right">Average</td>
                                                                        <?php
                                                                            $sql_ave = "SELECT AVG(choices) AS catave FROM vweva WHERE fm_fmID=? AND catID=?";
                                                                            $stmt_ave = $pdo->prepare($sql_ave);
                                                                            $stmt_ave->execute(array($fmID, $c_result['catID']));
                                                                            $choices_ave = $stmt_ave->fetch();

                                                                        ?>
                                                                        <td class="text-right" colspan=7>
                                                                            <?php  
                                                                            $catave = number_format($choices_ave['catave'], 2);
                                                                            $sql_remark = "SELECT * FROM choice WHERE choices=ROUND(?)";
                                                                            $stmt_remark = $pdo->prepare($sql_remark);
                                                                            $stmt_remark->execute(array($catave));
                                                                            $remark_result=$stmt_remark->fetch();
                                                                            echo $catave . " ( ".$remark_result['description']." )"; 
                                                                            ?>
                                                                        </td>
                                                                    </tr>
                                                                </tfoot>
                                                            </table>
                                                        </div>
                                                    <?php
                                                        $overall_sum+=$choices_ave['catave'];
                                                        $overall_total+=$categ_total;
                                                        $question_count+=$q_count;

                                                        $i++;
                                                        endwhile; 
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="row py-2">
                                                <div class="col-12">
                                                    <h4 style="font-weight: bold;"> OVERALL </h4>
                                                </div>
                                            </div>
                                            <div class="row py-2">
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-bordered table-striped" width="100%" cellspacing="0">
                                                            <tr>
                                                                <td style="width: 50%;">Students Evaluated:</td>
                                                                <td style="width: 50%;"><?=$evaluator_count?> student / s</td>
                                                            </tr>
                                                            <?php
                                                                $cat_table = "SELECT * FROM category";
                                                                $stmt_cat = $pdo->prepare($cat_table);
                                                                $stmt_cat-> execute();
                                                                while ($catrow = $stmt_cat->fetch()):
                                                                ?>
                                                                <tr>
                                                                    <td> <?= $catrow['catname']?> </td>
                                                                    <?php
                                                                            //kinuhkuha average per categ
                                                                            $sql_ave1 = "SELECT AVG(choices) AS catave FROM vweva WHERE fm_fmID=? AND catID=?";
                                                                            $stmt_ave1 = $pdo->prepare($sql_ave1);
                                                                            $stmt_ave1 ->execute(array($fmID, $catrow['catID']));
                                                                            $category_average = $stmt_ave1->fetch(); 

                                                                            //kinukuha yung remarks based on the ave
                                                                            $catave2 = number_format($category_average['catave'], 2);
                                                                            $sql_remark = "SELECT * FROM choice WHERE choices=ROUND(?)";
                                                                            $stmt_remark = $pdo->prepare($sql_remark);
                                                                            $stmt_remark->execute(array($catave2));
                                                                            $remark_result=$stmt_remark->fetch();
                                                                    ?>
                                                                    <td><?= $catave2 . " ( ".$remark_result['description']." )"; ?></td>
                                                                </tr>
                                                                <?php
                                                                endwhile;
                                                            ?>
                                                            <tr>
                                                                <td>Total Average</td>
                                                                    <?php
                                                                        $sql_ave = "SELECT AVG(choices) AS overallave FROM vweva WHERE fm_fmID=?";
                                                                        $stmt_ave = $pdo->prepare($sql_ave);
                                                                        $stmt_ave->execute(array($fmID));
                                                                        $choices_ave = $stmt_ave->fetch();
                                                                    ?>
                                                                <td>
                                                                    <?php  
                                                                        $overallave = number_format($choices_ave['overallave'], 2);
                                                                        $sql_remark = "SELECT * FROM choice WHERE choices=ROUND(?)";
                                                                        $stmt_remark = $pdo->prepare($sql_remark);
                                                                        $stmt_remark->execute(array($overallave));
                                                                        $remark_result=$stmt_remark->fetch();
                                                                        echo $overallave . " ( ".$remark_result['description']." )"; 
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 50%;">School Year:</td>
                                                                <td style="width: 50%;"> S.Y. <?=$sy?> </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 50%;">Semester:</td>
                                                                <td style="width: 50%;"><?=$term?> </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!--pill1-->

                                        
                                        <div class="tab-pane fade" id="pills-comments" role="tabpanel" aria-labelledby="pills-profile-tab">
                                            <div class="row py-5">
                                                <div class="col-12">
                                                    <div class="card shadow mb-4">
                                                        <div class="card-body">
                                                            <div class="d-sm-flex align-items-center justify-content-between mb-3">
                                                                <h3 class=" mb-0 text-gray-900">Comments</h3>
                                                            </div>
                                                            <div class="table-responsive">
                                                                <table class="table table-bordered table-striped" width="100%" cellspacing="0">
                                                                    <tbody>
                                                                        <?php
                                                                            $sql_comment = "SELECT * FROM comments WHERE fmID=?";
                                                                            $stmt_comment = $pdo->prepare($sql_comment);
                                                                            $stmt_comment->execute(array($fmID));
                                                                            while ($comm_result = $stmt_comment->fetch()):
                                                                                if(!empty($comm_result["comms"])):
                                                                        ?>
                                                                        <tr style="text-align: center">
                                                                            <td style="padding: 10px;"><?=$comm_result['comms']?></td>
                                                                        </tr>
                                                                        <?php
                                                                            endif;
                                                                            endwhile;
                                                                        ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card shadow mb-4">
                                                <div class="card-body">
                                                    <div class="d-sm-flex align-items-center justify-content-between mt-2">
                                                        <h3 class=" mb-0 text-gray-900">Sentiment</h3>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="card border-secondary m-3 pt-3">
                                                                <div class="card-body">
                                                                 ...
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!--pill2-->

                                    </div><!--tabcontent-->
                                </div>
                            </div>
                        </div><!--card-body-->
                    </div>

                </div>
                <!-- End of Page Content -->
            </div><!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer><!-- End of Footer -->
        </div><!-- End of Content Wrapper -->
    </div><!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script> $.widget.bridge('uibutton', $.ui.button) </script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- ChartJS -->
  <script src="plugins/chart.js/Chart.min.js"></script>
  <!-- Sparkline -->
  <script src="plugins/sparklines/sparkline.js"></script>
  <!-- JQVMap -->
  <script src="plugins/jqvmap/jquery.vmap.min.js"></script>
  <script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
  <!-- jQuery Knob Chart -->
  <script src="plugins/jquery-knob/jquery.knob.min.js"></script>
  <!-- daterangepicker -->
  <script src="plugins/moment/moment.min.js"></script>
  <script src="plugins/daterangepicker/daterangepicker.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.js"></script>
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
</body>
</html>