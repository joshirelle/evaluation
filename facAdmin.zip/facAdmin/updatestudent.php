<?php
// Include config file
require_once "connection.php";


    // Define variables and initialize with empty values
    $studnum = $lname = $fname = $mname = $deptcode = "";
    $studnum2 = $lname2 = $fname2 = $mname2 = $deptcode2 = "";


    // Processing form data when form is submitted
    if (isset($_POST["student_id"]) && !empty($_POST["student_id"])) {
        // Get hidden input value
        $id = $_POST["student_id"];

        // Validate studentnum
        $input_studnum = trim($_POST["studnum"]);
        $studnum = htmlspecialchars($input_studnum);
        
        // Validate lname
        $input_lname = trim($_POST["lname"]);
        $lname = htmlspecialchars($input_lname);
        

        // // Validate fname
        $input_fname = trim($_POST["fname"]);
        $fname = htmlspecialchars($input_fname);
        

        // // Validate mi
        $input_mname = trim($_POST["mname"]);
        $mname = htmlspecialchars($input_mname);
    
        $input_deptID= trim($_POST["deptcode"]);
        $deptID = htmlspecialchars($input_deptID);


        // Check input errors before inserting in database
        if (empty($name_err) && empty($address_err) && empty($salary_err)) {
            // Prepare an update statement
            $sql = "UPDATE students SET studnum=:studnum, lname=:lname, fname=:fname, mi=:mi, deptID=:deptID WHERE studID=:id";

            if ($stmt = $pdo->prepare($sql)) {
                // Bind variables to the prepared statement as parameters
                $stmt->bindParam(":studnum", $studnum);
                $stmt->bindParam(":lname", $lname);
                $stmt->bindParam(":fname", $fname);
                $stmt->bindParam(":mi", $mname);
                $stmt->bindParam(":deptID", $deptID);
                $stmt->bindParam(":id", $id);

                // // Set parameters
                // $param_studnum = $studnum;
                // $param_lname = $lname;
                // $param_fname = $fname;
                // $param_mname = $mname;
                // $param_deptcode = $deptcode;
                // $param_id = $id;

                // Attempt to execute the prepared statement
                if ($stmt->execute()) {
                    // Records updated successfully. Redirect to landing page
                    header("location: activestudents.php");
                    exit();
                } else {
                    echo "Oops! Something went wrong. Please try again later.";
                }
            }

            // Close statement
            unset($stmt);
        }

        // Close connection
        unset($pdo);
    }
?>
