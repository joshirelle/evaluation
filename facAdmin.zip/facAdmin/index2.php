<?php 
// Load the database configuration file 
include_once 'connection.php'; 
 
// Get status message 
if(!empty($_GET['status'])){ 
    switch($_GET['status']){ 
        case 'succ': 
            $statusType = 'alert-success'; 
            $statusMsg = 'Member data has been imported successfully.'; 
            break; 
        case 'err': 
            $statusType = 'alert-danger'; 
            $statusMsg = 'Something went wrong, please try again.'; 
            break; 
        case 'invalid_file': 
            $statusType = 'alert-danger'; 
            $statusMsg = 'Please upload a valid Excel file.'; 
            break; 
        default: 
            $statusType = ''; 
            $statusMsg = ''; 
    } 
} 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Import Excel File Data with PHP</title>

<!-- Bootstrap library -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<!-- Stylesheet file -->
<link rel="stylesheet" href="assets/css/style.css">


<!-- Show/hide Excel file upload form -->
<script>
function formToggle(ID){
    var element = document.getElementById(ID);
    if(element.style.display === "none"){
        element.style.display = "block";
    }else{
        element.style.display = "none";
    }
}
</script>
</head>
<body>

<!-- Display status message -->
<?php if(!empty($statusMsg)){ ?>
<div class="col-xs-12 p-3">
    <div class="alert <?php echo $statusType; ?>"><?php echo $statusMsg; ?></div>
</div>
<?php } ?>

<div class="row p-3">
    <!-- Import link -->
    <div class="col-md-12 head">
        <div class="float-end">
            <a href="javascript:void(0);" class="btn btn-success" onclick="formToggle('importFrm');"><i class="plus"></i> Import Excel</a>
        </div>
    </div>
    <!-- Excel file upload form -->
    <div class="col-md-12" id="importFrm" style="display: none;">
        <form class="row g-3" action="importData.php" method="post" enctype="multipart/form-data">
            <div class="col-auto">
                <label for="fileInput" class="visually-hidden">File</label>
                <input type="file" class="form-control" name="file" id="fileInput" />
            </div>
            <div class="col-auto">
                <input type="submit" class="btn btn-primary mb-3" name="importSubmit" value="Import">
            </div>
        </form>
    </div>

    <!-- Data list table --> 
    <table class="table table-striped table-bordered">
       <?php
// Include config file
        require_once "connection.php";
        
        // Attempt select query execution
         $sql = "SELECT
        students2.studID,
        students2.studnum,
        students2.lname,
        students2.fname,
        students2.mi,
        department.deptcode
        FROM students2
        JOIN department ON students2.deptID=department.deptID where students2.is_deleted=0";

        if ($result = $pdo->query($sql)) {
            if ($result->rowCount() > 0) {
                echo "<thead style='background:#A0B0E4; text-align:center; color:white'>";
                echo "<tr>";
                echo "<th>#</th>";
                echo "<th>Student Number</th>";
                echo "<th>Last Name</th>";
                echo "<th>First Name</th>";
                echo "<th>Middle Initial</th>";
                echo "<th>Department</th>";
                echo "<th>Action</th>";

                echo "</tr>";
                echo "</thead>";
                echo "<tbody>";
                while ($row = $result->fetch()) {
                echo "<tr>";
                echo "<td>" . $row['studID'] . "</td>";
                echo "<td>" . $row['studnum'] . "</td>";
                echo "<td>" . $row['lname'] . "</td>";
                echo "<td>" . $row['fname'] . "</td>";
                echo "<td>" . $row['mi'] . "</td>";
                echo "<td>" . $row['deptcode'] . "</td>";
                echo "<td>";

                echo '<a href="#updateStudentModal" data-toggle="modal" class="btn btn-success mr-1" title="Update Record"  data-toggle="tooltip" data-id=' . $row['studID'] . '><i class="fas fa-edit"></i> Update</a>';
                echo '<a href="#deleteStudentsModal" onclick="passIdToForm('.$row['studID'].')" data-toggle="modal" class="btn btn-danger mr-1" title="Deactivate Record"  data-toggle="tooltip" data-id=' . $row['studID'] . '><i class="fa fa-thumbs-down"></i> Deactivate</a>';
                echo "</td>";
                echo "</tr>";
                }
                echo "</tbody>";
                echo "</table>";
                // Free result set
                unset($result);
                } else {
                 echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                }
            } else {
            echo "Oops! Something went wrong. Please try again later.";
            }

            // Close connection
            unset($pdo);
        ?>
    </table>
</div>

</body>
</html>