<?php
    require_once "connection.php";

    $selected_deptID = "";
    if(isset($_GET["deptID"])) {
        $selected_deptID = htmlspecialchars($_GET["deptID"]);
    }
	// Set the select SQL data
	$sql = "SELECT
    deptID,
    deptcode,
    deptname
    FROM department
    WHERE is_deleted = 0";

    $stmt = $pdo->query($sql);
    while($fetch = $stmt->fetch()) {
        $deptID = $fetch['deptID'];
        $deptcode = $fetch['deptcode'];
        $deptname = $fetch['deptname'];
        $is_selected = "";

        if($selected_deptID == $deptID) {
            $is_selected = "selected";
        }

        echo "<option value='{$deptID}' {$is_selected}>{$deptcode} - {$deptname}</option>";
    }
    unset($result);
    unset($pdo);
?>