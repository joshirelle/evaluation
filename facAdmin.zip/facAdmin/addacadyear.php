<?php
// Include config file
require_once "connection.php";


    // Define variables and initialize with empty values
    $sy = $_POST['sy'];
    $term = $_POST['termID'];


    $sql = "INSERT INTO school_year (sy, termID) VALUES (:sy, :term)";

        if ($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":sy", $sy);
            $stmt->bindParam(":term", $term);

            if ($stmt->execute()) {
                header("location: term.php");
                exit();
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        unset($pdo);
?>
