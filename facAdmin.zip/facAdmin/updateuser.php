<?php
// Include config file
require_once "connection.php";


    // Define variables and initialize with empty values
    $lname = $fname = $mname = $positionname = "";
    $lname2 = $fname2 = $mname2 = $positionname2 = "";


    // Processing form data when form is submitted
    if (isset($_POST["user_id"]) && !empty($_POST["user_id"])) {
        // Get hidden input value
        $id = $_POST["user_id"];
        
        // Validate name
        $input_lname = trim($_POST["lname"]);
        $lname = $input_lname;

        // // Validate address address
        $input_fname = trim($_POST["fname"]);
        $fname = $input_fname;
        

        // // Validate salary
        $input_mname = trim($_POST["mname"]);
        $mname = $input_mname;
    
        $input_positionname = trim($_POST["positionname"]);
        $positionname = $input_positionname;


        // Check input errors before inserting in database
        if (empty($name_err) && empty($address_err) && empty($salary_err)) {
            // Prepare an update statement
            $sql = "UPDATE user SET lname=:lname, fname=:fname, mname=:mname, positionnum=:positionnum WHERE userid=:id";

            if ($stmt = $pdo->prepare($sql)) {
                // Bind variables to the prepared statement as parameters
                $stmt->bindParam(":lname", $param_lname);
                $stmt->bindParam(":fname", $param_fname);
                $stmt->bindParam(":mname", $param_mname);
                $stmt->bindParam(":positionnum", $param_positionname);
                $stmt->bindParam(":id", $param_id);

                // Set parameters
                $param_lname = $lname;
                $param_fname = $fname;
                $param_mname = $mname;
                $param_positionname = $positionname;
                $param_id = $id;

                // Attempt to execute the prepared statement
                if ($stmt->execute()) {
                    // Records updated successfully. Redirect to landing page
                    header("location: user.php");
                    exit();
                } else {
                    echo "Oops! Something went wrong. Please try again later.";
                }
            }

            // Close statement
            unset($stmt);
        }

        // Close connection
        unset($pdo);
    }
?>
