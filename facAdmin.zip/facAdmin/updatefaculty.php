<?php
// Include config file
require_once "connection.php";
 
// Define variables and initialize with empty values
$lname = $fname = $mname = $deptcode = "";
$lname2 = $fname2 = $mname2 = $deptcode2 = "";

// Processing form data when form is submitted
if(isset($_POST["facNum"]) && !empty($_POST["facNum"])) {
    // Get hidden input value
    $facNum = trim($_POST["facNum"]);
echo $facNum;

    $facNum2 = trim($_POST["fac-Num"]);
    echo $facNum2;
     
    $input_lname = trim($_POST["lname"]);
    $lname = htmlspecialchars($input_lname);
    
    // // Validate address address
    $input_fname = trim($_POST["fname"]);
    $fname = htmlspecialchars($input_fname);
    
    $input_mi= trim($_POST["mname"]);
    $mi = htmlspecialchars($input_mi);
    
    $input_deptID= trim($_POST["deptcode"]);
    $deptID = htmlspecialchars($input_deptID);

    // Prepare an update statement
    $sql_fac = "UPDATE faculty SET facNum=:facNum2, lname=:lname, fname=:fname, mi=:mi, deptID=:deptID WHERE facNum=:facNum";
    // $sql_fm = "UPDATE faculty_member SET deptID=:deptID WHERE fmID=:fmID";

    //Begin SQL transaction
    $pdo->beginTransaction();
    try {
        //faculty table
        $stmt_fac = $pdo->prepare($sql_fac);
        $stmt_fac->bindParam(":facNum2", $facNum2);
        $stmt_fac->bindParam(":lname", $lname);
        $stmt_fac->bindParam(":fname", $fname);
        $stmt_fac->bindParam(":mi", $mi);
        $stmt_fac->bindParam(":deptID", $deptID);
        $stmt_fac->bindParam(":facNum", $facNum);
        $stmt_fac->execute();

        // //faculty_member table
        // $stmt_fm = $pdo->prepare($sql_fm);
        // $stmt_fm->bindParam(":deptID", $deptID);
        // $stmt_fm->bindParam(":fmID", $id);
        // $stmt_fm->execute();

        //Save when no error
        $pdo->commit();

        //redirect after save
        header("location: activefaculty.php");

    } catch(PDOException $ex) {
        //revert changes when error occurs
        $pdo->rollBack();
        exit($ex->getMessage());//print error message [for debugging]

    }

    // if($stmt = $pdo->prepare($sql)){
    //     // Bind variables to the prepared statement as parameters
    //     $stmt->bindParam(":lname", $param_lname);
    //     $stmt->bindParam(":fname", $param_fname);
    //     $stmt->bindParam(":mi", $param_mname);
    //     $stmt->bindParam(":deptID", $param_deptID);
    //     $stmt->bindParam(":id", $param_id);

    //     // Set parameters
    //     $param_lname = $lname;
    //     $param_fname = $fname;
    //     $param_mname = $mname;
    //     $param_deptcode = $deptcode;
    //     $param_id = $id;
        
    //     // Attempt to execute the prepared statement
    //     if($stmt->execute()){
    //         // Records updated successfully. Redirect to landing page
    //         header("location: activefaculty.php");
    //         exit();
    //     } else{
    //         echo "Oops! Something went wrong. Please try again later.";
    //     }
    // }
     
    // Close statement
    unset($stmt);
    
    // Close connection
    unset($pdo);
}
?>
