const processLoginURL = baseURL + "/process-login.php";
const evaluationURL = baseURL + "/index1.php";

const txtdept = document.querySelector("#deptID");
const cmbxfac = document.querySelector("#faculty");
const txtStudentNum = document.querySelector('#studentnum');
const loginForm = document.querySelector("#login-form");
const txtdeptname = document.querySelector("#deptname");
const current_url = new URL(window.location);

$().ready(function() {
    if(document.referrer != 'https://localhost:8181/'){ 
        history.pushState(null, null, 'login.php');
        window.addEventListener('popstate', function () {
            history.pushState(null, null, 'login.php');
        });
    }
});

window.addEventListener('load', () => {

    let studnum = current_url.searchParams.get('stud');
    let deptID = current_url.searchParams.get('dept');

    if (studnum != null || deptID != null) {
        //if student agreed to evaluate again...
        $(txtStudentNum).val(studnum);
        $(txtdept).val(deptID);
        $(txtdept).prop("disabled", true);
        $(txtStudentNum).prop("disabled", true);
        changeFaculty(deptID);
        changeDepartment(studnum);
    } else {
        //do nothing
    }
});

txtStudentNum.addEventListener('keyup', (e) => {
    changeDepartment($(txtStudentNum).val());
});

txtdept.addEventListener('change', () => {
    changeFaculty($(txtdept).val())
});

loginForm.addEventListener('submit', (e) => {
    e.preventDefault();

    post(processLoginURL, {
        process: 'login-submit',
        deptID: $(txtdept).val(),
        facID: $(cmbxfac).val(),
        studnum: $(txtStudentNum).val()
    }).done(response => {
        // console.log(response);
        try {
            let result = JSON.parse(response);
            if(!result.dept_id_valid || !result.fac_id_valid || !result.stud_num_valid)
            {  
                //console.log('bawal')
                window.alert("Please enter the correct format of your student number.");
                
            } else {
                console.log('ok na')
                let evalURL = new URL(evaluationURL);
                evalURL.searchParams.set('categ', '1');
                window.location.replace(evalURL);
            }
        } catch (error) {
            console.log(error); //error notification
        }
    });
});

function changeDepartment(studnum) {
    post(processLoginURL, {
        process: 'get-student-dept',
        studnum: studnum
    }).done(response => {
        try {
            let department = JSON.parse(response);
            console.log(department.deptname);
            
            if(department.deptid != '') {
                $(txtdept).val(department.deptid);
                $(txtdeptname).val(department.deptname);
                changeFaculty(department.deptid);
            } else {
                $(txtdept).val(0);
                $(cmbxfac).prop("disabled", true);
                $(cmbxfac).val(0);
            }
            
        } catch (error) {
            console.log(error); //error notification
        }
    });
}

function changeFaculty(deptID) {
    $(cmbxfac).prop("disabled", false);

    post(processLoginURL, {
        process: 'update-cmbx-fac',
        deptID: deptID,
        studnum: $(txtStudentNum).val()
    }).done(response => {
        $(cmbxfac).html(response);
        $(cmbxfac).prepend("<option value='0'>-- SELECT FACULTY --</option>");
        $(cmbxfac).val(0); //ibalik sa unahan yung select
        //console.log(response);
    });
}