<?php

session_start();

require_once('./config/path.php');
require_once('connection.php');

$current_date = date('Y-m-d H:i:s');

try{
    //begin transaction so there are no errors in the middle of the loop
    $pdo->beginTransaction();
    foreach ($_POST as $key => $value) {
        //remove the word questions to get the raw IDs
        $key = str_replace('questions', '', $key);
        
        $sql = "INSERT INTO eva (studNum, fmID, quesID, choicesID, evadate) VALUES(?,?,?,?,?)";
        $pst = $pdo->prepare($sql);
        $pst->execute(array($_SESSION['student_number'], $_SESSION['fmID'], $key, $value, $current_date));
    }

    //commit when no errors occurred
    $pdo->commit();

    //evaluation submitted so ask a question below to student if they want to evaluate one more time.
    echo "Evaluation successfully submitted";

    //if student agrees to evaluate again...
    //header("Location: " . BASE_URL . "/login1.php?studnum={$_SESSION['student_number']}&deptID={$_SESSION['dept_id']}");

} catch( PDOException $ex) {
    //error occurred here so use rollBack() to revert insert statements
    $pdo->rollBack();
    $ex->getMessage();
}
?>

