<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.0-alpha1-dist/css/bootstrap.min.css">
    <title> EVALUATION FORM </title>
</head>
<body>
    <div class="container-fluid">
        <!-- header -->
        <div class="row py-2 text-white" style="height:70px; background-color:  rgb(100, 59, 5);">
            <div class="col col-3" style="padding-left:270px;">
                <img src="img/CSTALOGO.jpg" style="width:70px; height:50px; border-radius:50%" alt="CSTA"> 
            </div>
            <div class="col col-9">
                <div class="my-1" style="padding-left: 5px; text-align:left ; font-size:35px; font-family: Oswald;"> CSTA FACULTY PERFORMANCE EVALUATION </div>
            </div>
        </div>

        <!-- -->
        <div class="row my-1">
            <!-- faculty display -->
            <div class="col-6 border">

            </div>
            <!-- rating display -->
            <div class="col-6" style="font-size:13px;">
                <div class="row mx-1 text-white">
                    <div class="col-6 border" style="text-align:center; background-color:  rgb(100, 59, 5);"> Scale </div>
                    <div class="col-6 border" style="text-align:center;  background-color:  rgb(100, 59, 5);"> Rating </div>
                </div>
                <div class="row mx-1" style="text-align:center;">
                    <div class="col-6 border"> 5 </div>
                    <div class="col-6 border"> Excellent </div>
                </div>
                <div class="row mx-1" style="text-align:center;">
                    <div class="col-6 border"> 4 </div>
                    <div class="col-6 border"> Very Satisfactory </div>
                </div>
                <div class="row mx-1" style="text-align:center;">
                    <div class="col-6 border"> 3 </div>
                    <div class="col-6 border"> Satisfactory </div>
                </div>
                <div class="row mx-1" style="text-align:center;">
                    <div class="col-6 border"> 2 </div>
                    <div class="col-6 border"> Fair </div>
                </div>
                <div class="row mx-1" style="text-align:center;">
                    <div class="col-6 border"> 1 </div>
                    <div class="col-6 border"> Needs Improvement </div>
                </div>
            </div>
        </div>

        <!-- line -->
        <div class = "row px-2">
            <div class = "col" style="height:5px; background-color:  rgb(100, 59, 5);"></div>
        </div>

        <!-- -->
        <div class = "row p-1">
            <div class = "col">
                <h4 style="color: rgb(124, 71, 1)"> Mastery of the Subject Matter </h4>
            </div>
        </div>

        <!-- table -->
        <div class="row m-1">
            <div class="card shadow mb-1">
                <div class="table-responsive" style="font-size:13px;">
                    <table class="table" width="100%" cellspacing="0">
                        <?php
                            require_once('connection.php')
                        ?>

                        <form action="save.php" method="post">
                            <?php
                                // Query the questions table
                                try {
                                    $stmt1 = $pdo->prepare('SELECT * FROM questions');
                                    $stmt1->execute();
                                    $questions = $stmt1->fetchAll();
                                } catch (PDOException $e) {
                                        echo 'Query failed: ' . $e->getMessage();
                                        exit;
                                    }
                                        echo '<thead class="border">';
                                            echo '<tr style="text-align: center">';
                                                echo '<th class="border">Questions</th>';
                                                echo '<th class="border" colspan="5">Ratings</th>';
                                            echo '</tr>';
                                        echo '</thead>';

                                        echo '<tbody class="border">';
                                            echo '<tr style="text-align: center">';
                                                echo '<td class="border"> &nbsp; </td>';
                                                echo '<td class="border"> 5 </td>';
                                                echo '<td class="border"> 4 </td>';
                                                echo '<td class="border"> 3 </td>';
                                                echo '<td class="border"> 2</td>';
                                                echo '<td class="border"> 1 </td>';
                                            echo '</tr>';

                                        echo '<tbody>';
                                            foreach ($questions as $question) {
                                            // Query the choices for this question
                                            try {
                                                $stmt2 = $pdo->prepare('SELECT * FROM choice ORDER BY choices desc');
                                                $stmt2->execute();
                                                $choices = $stmt2->fetchAll();
                                            } catch (PDOException $e) {
                                                echo 'Query failed: ' . $e->getMessage();
                                                exit;
                                            }
                                
                                            echo '<tr>';
                                                echo '<td class="border">' . $question['ques'] . '</td>';
                                                    foreach ($choices as $choice) {
                            ?>
                                                        <td class="border">
                                                            <input type="radio" name=<?= "questions{$question['quesID']}"; ?> value=<?= $choice['choices']; ?>>
                                                                <label for="">
                                                                    <?= $choice['choices']; ?>
                                                                </label>
                                                        </td>
                                                        <?php
                                                    }
                                            echo '</tr>';
                                            }
                                
                                        echo '</tbody>';
                                                        ?>
                        </form>
                        <input class ="my-3" type="submit" value="Submit">
                    </table>
                </div>
            </div>
        </div>
    
    
        <!-- footer -->

<!-- / END TAGS / -->
    </div>
    <script src="bootstrap-5.3.0-alpha1-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>