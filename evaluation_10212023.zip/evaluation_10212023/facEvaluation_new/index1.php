<?php
    session_start();

    if(!isset($_SESSION['student_number'])) {
        header("Location: /");
        exit;
    }
    
    require_once('./config/path.php');
    require_once('connection.php');

    //received names
    //for display
    $faculty_name = $_SESSION['faculty_name'];
    $department_name = $_SESSION['department_name'];

    //received ids
    //to be used when student agrees to evaluate again
    $deptID = $_SESSION['deptID'];
    $facID = $_SESSION['facID'];
    $student_number = $_SESSION['student_number'];

    // unset($_SESSION['faculty_name']);
    // unset($_SESSION['department_name']);

    //category searching in database here
    $categ_id = htmlspecialchars($_GET['categ']);
    $sql = "SELECT * FROM category WHERE catID=?";
    $pst = $pdo->prepare($sql);
    $pst->execute(array($categ_id));
    $categ_data = $pst->fetch();
    $categ_name = $categ_data['catname'];

    //find number of categories
    $sql = "SELECT COUNT(*) AS count FROM category";
    $stmt = $pdo->query($sql);
    $categ_count_data = $stmt->fetch();
    $categ_count = $categ_count_data['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.0-alpha1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css"href="css/style.css">
    <title> EVALUATION FORM </title>
</head>
<body>
    <div class="container-fluid">
        <!-- header -->
        <div class="row py-2 text-white" style="height:50px; background-color: #960019;">
            
        </div>

        <!-- -->
        <div class="row my-2" style="font-weight: bold;">
            <!-- faculty display -->
            <div class="col-12 border">
                <div class='fs-1' style="color: #5E1914;">
                    <div data-return-type='faculty' data-return-id='<?=$facID?>'><?=$faculty_name?></div>
                </div>
                <div data-return-type='department' data-return-id='<?=$deptID?>' class="small" style="font-family: 'Old Standard TT'; font-weight: bold; color: #5E1914; letter-spacing:1px; padding-left: 5px;"><?php echo $department_name; ?></div>
            </div>
        </div>

        <!-- line -->
        <div class = "row px-2">
            <div class = "col" style="height:5px; background-color:  #960019;"></div>
        </div>

        <!-- table -->
        <div class="row m-1 mt-3">
            <div class="card shadow mb-1">
            <div class = "row p-1 pt-3">
            <div class = "col">
                <h4 id="catname-holder" class="d-block" style="color: #a62a2a; font-family: 'Times New Roman'; letter-spacing: 1px">
                    <?=$categ_name?> <?=$categ_id?>/<?=$categ_count?>
                </h4>
            </div>
        </div>
                <div class="table-responsive my-2" style="font-size:15px;">
                    <form id="question-form" method="post">
                        <div id="form-contents">
                            <table id="questionsTable" class="table table-striped" width="100%" cellspacing="0">
                                <?php
                                    // Query the questions table
                                    try {
                                        $stmt1 = $pdo->prepare('SELECT * FROM questions');
                                        $stmt1->execute();
                                        $questions = $stmt1->fetchAll();
                                    } catch (PDOException $e) {
                                        echo 'Query failed: ' . $e->getMessage();
                                        exit;
                                    }
                                        echo '<thead>';
                                            echo '<tr style="text-align: center">';
                                                echo '<th class="border" style="width: 60%; background-color: brown; color: white;">Questions</th>';
                                                echo '<th class="border" colspan="5" style="width: 40%; background-color: brown; color: white;">Ratings</th>';
                                            echo '</tr>';
                                            echo '<tr class="text-center" style="text-align: center; font-family: Times New Roman;">';
                                                echo '<th class="border" style="width: 60%;"> &nbsp; </th>';
                                                echo '<th class="border" style="width: 8%; font-weight: bold;"> 5 <br> Excellent </th>';
                                                echo '<th class="border" style="width: 8%; font-weight: bold;"> 4 <br> Very Satisfactory </th>';
                                                echo '<th class="border" style="width: 8%; font-weight: bold;"> 3 <br> Satisfactory</th>';
                                                echo '<th class="border" style="width: 8%; font-weight: bold;"> 2 <br> Fair</th>';
                                                echo '<th class="border" style="width: 8%; font-weight: bold;"> 1 <br> Needs Improvement</th>';
                                            echo '</tr>';

                                        echo '</thead>';
    
                                        echo '<tbody class="border">';
                                           
                                    foreach ($questions as $question) {
                                        // Query the choices for this question
                                        try {
                                            $stmt2 = $pdo->prepare('SELECT * FROM choice ORDER BY choices desc');
                                            $stmt2->execute();
                                            $choices = $stmt2->fetchAll();
                                        } catch (PDOException $e) {
                                            echo 'Query failed: ' . $e->getMessage();
                                            exit;
                                        }
                                    
                                        echo "<tr data-catID='{$question['catID']}'>";
                                            echo '<td class="border" style="font-family: Times New Roman; font-size: 17px; letter-spacing:1px;">' . $question['ques'] . '</td>';
                                                foreach ($choices as $choice) {
                                ?>
                                                    <td class="text-center border" style="font-family: Times New Roman;">
                                                        <input class="data-input" type="radio" name=<?="questions{$question['quesID']}";?> value=<?= $choice['choicesID']; ?>>
                                                        
                                                    </td>
                                <?php
                                                }
                                        echo '</tr>';
                                    }
                                    
                                    echo '</tbody>';
                                ?>
                            </table>
                            <textarea class="d-none form-control mb-3" name="txtComment" id="txtComment" cols="30" rows="10" placeholder="Do you have any more feedbacks?"></textarea>
                        </div>
                        <div class="d-flex justify-content-between w-100">
                            <div id="btn-page-holder" class="d-flex justify-content-between w-100">
                                <?php
                                    $sql = "SELECT * FROM category";
                                    $stmt = $pdo->query($sql);
                                    $categ_arr = [];
                                    while($data = $stmt->fetch(PDO::FETCH_ASSOC)){
                                        array_push($categ_arr, $data);
                                    }

                                    for($i=0; $i < count($categ_arr); $i++){
                                        if($categ_arr[$i]['catID'] == $categ_id) {
                                            $prev = $i-1;
                                            $current = $i;
                                            $next = $i+1;

                                            if(!empty($categ_arr[$prev])) {
                                                echo "<button type='button' data-cat-page='{$categ_arr[$prev]['catID']}' class='btn-pager prev btn btn-primary'>Previous</button>";
                                            }
                
                                            if(!empty($categ_arr[$next]))
                                            {
                                                echo "<div></div>";
                                                echo "<button type='button' data-cat-page='{$categ_arr[$next]['catID']}' class='btn-pager next btn btn-primary'>Next</button>";
                                            }
                                        }
                                    }
                                ?>
                            </div>
                            <button id="btnSubmit" class='btn btn-primary' type="submit" style='display:none'>Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Invisible -->
        <div class='d-none' data-return-type='student' data-return-id='<?=$student_number?>'></div>
    
    
        <!-- footer -->

<!-- / END TAGS / -->
    </div>

    <!-- PLUGINS -->
    <script src="bootstrap-5.3.0-alpha1-dist/js/bootstrap.bundle.min.js"></script>
    <script
        src="https://code.jquery.com/jquery-3.6.4.min.js"
        integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8="
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- CUSTOM JS FILES -->
    <script>
        const baseURL = "<?=BASE_URL?>";
    </script>
    <script src="./js/functions.js"></script>
    <script src="./js/questionsTable.js"></script>
</body>
</html>