<?php

session_start();
require_once "./connection.php";

if($_SERVER['REQUEST_METHOD'] === 'POST')
{

    if($_POST['process'] === 'get-category-btn')
    {

        $response = [];

        $cat_id = $_POST['categID'];
        $sql = "SELECT * FROM category";
        $stmt = $pdo->query($sql);
        $categ_arr = [];
        
        while($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            array_push($categ_arr, $data);
        }
            
        for($i=0; $i < count($categ_arr); $i++){ 
            if($categ_arr[$i]['catID'] == $cat_id) {
                
                $prev = $i-1;
                $current = $i;
                $next = $i+1;
        
                $has_prev = false;
                $has_next = false;

                if(!empty($categ_arr[$prev]))
                {
                    $response['prev'] = $categ_arr[$prev]['catID'];
                    //  "<button data-cat-page='{$categ_arr[$prev]['catID']}' class='btn-pager btn btn-primary'>Previous</button>";
                }
                if(!empty($categ_arr[$next]))
                {
                    $response['next'] = $categ_arr[$next]['catID'];
                }
            }
        }

        exit(json_encode($response));
    }

    if($_POST['process'] === 'get-category-name')
    {
        $categ_id = htmlspecialchars($_POST['categID']);
        $sql = "SELECT * FROM category WHERE catID=?";
        $pst = $pdo->prepare($sql);
        $pst->execute(array($categ_id));
        $data = $pst->fetch();

        //get count of category
        $sql_2 = "SELECT COUNT(*) AS categ_count FROM category";
        $pst_2 = $pdo->prepare($sql_2);
        $pst_2->execute();
        $data_2 = $pst_2->fetch();

        $response = [
            'categ_num' => $categ_id,
            'categ_name' => $data['catname'],
            'categ_count' => $data_2['categ_count']
        ];

        exit(json_encode($response));
    }

    if($_POST['process'] === 'submit-evaluation')
    {
        // exit(var_dump($_POST));
        $current_date = date('Y-m-d H:i:s');

        $comment = htmlspecialchars($_POST['comment']);

        try{
            //begin transaction so there are no errors in the middle of the loop
            $pdo->beginTransaction();

            //two tables to insert!
            //1st table for comment 
            //2nd table for the answers (inside foreach loop)

            //insert the one comment here
            $sql = "INSERT INTO comments (studNum, fmID, comms, commdate) VALUES(?,?,?,?)";
            $pst = $pdo->prepare($sql);
            $pst->execute(array($_SESSION['student_number'], $_SESSION['fmID'], $comment, $current_date));
            $commID = $pdo->lastInsertId(); // get the comment id to pass in eva table

            $sql2 = "SELECT syID FROM settings";
            $stmt2 = $pdo->prepare($sql2);
            $stmt2->execute();
            $sy = $stmt2->fetch();

            foreach ($_POST['answers'] as $key => $value) {
                //remove the word questions to get the raw IDs
                $key = str_replace('questions', '', $key);
                $sql = "INSERT INTO eva (studNum, fmID, quesID, choicesID, commID, evadate, syID) VALUES(?,?,?,?,?,?,?)";
                $pst = $pdo->prepare($sql);
                $pst->execute(array($_SESSION['student_number'], $_SESSION['fmID'], $key, $value, $commID, $current_date, $sy['syID']));
            }

            //commit when no errors occurred
            $pdo->commit();

            //evaluation should be submitted, so ask a question below to student if they want to evaluate one more time.
            $response = [
                'ícon' => 'success',
                'title' => 'Evaluation submitted successfuly!',
                'text' => 'Do you want to evaluate for another faculty member?'
            ];

            // hold
            if(isset($_SESSION['remove_fac'][$_SESSION['student_number']])) {
                array_push($_SESSION['remove_fac'][$_SESSION['student_number']], $_SESSION['fmID']);
            } else {
                $_SESSION['remove_fac'][$_SESSION['student_number']] = [];
                array_push($_SESSION['remove_fac'][$_SESSION['student_number']], $_SESSION['fmID']);
            }
            var_dump($_SESSION['remove_fac']);
            //let javascript handle redirecting
            exit(json_encode($response));
        } catch( PDOException $ex) {
            //error occurred here so use rollBack() to revert insert statements
            $pdo->rollBack();
            $ex->getMessage();
        }
    }
}
