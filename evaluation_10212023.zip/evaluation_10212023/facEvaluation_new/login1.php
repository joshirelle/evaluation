<?php
    require_once './config/path.php';
    require_once './connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.3.0-alpha1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css"href="css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fasthand&family=Noto+Sans+KR:wght@500&family=Noto+Serif:wght@700&family=Old+Standard+TT:wght@700&display=swap" rel="stylesheet">
    <title> LOGIN </title>
</head>
<body>
    <div class="bg-image" style="background-image: url('img/CSTA2.jpg'); height: 100vh;background-position: center; background-repeat: no-repeat; background-size:cover;">
        <div class="container py-3 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                    <div class="container p-5" style="background-color: white; border-radius: 1rem;">
                        <div class="box text-center" style="border-radius: 1rem;">
                            <div class="row">
                                <div class="col-3 py-3" style="padding-left:40px;">
                                    <img src="img/CSTALOGO.jpg" style="width:50px; height:45px; border-radius:50%" alt="CSTA"> 
                                </div>
                                <div class="col-9">
                                    <div class="my-2 mt-4" id="cstaname" style="padding-left: 0px; text-align: left ; font-size: 18px; font-family: 'Times New Roman'; font-weight: bold;"> Colegio de Sta. Teresa de Avila</div>
                                </div>
                            </div>
                            <div class = "row px-2">
                                <div class = "col mb-4" style="height:2px; background-color: #960019;"></div>
                            </div>

                            <div class="col">
                                <form id="login-form" action="index1.php" method="POST">
                                    <div class="form-outline form-white mb-3">
                                        <input type="text" id="studentnum" class="form-control form-control-lg" placeholder="e.g 12-12345" required/>
                                        <label class="form-label text-dark mt-2" for="studentnum" style="letter-spacing: 2px;">Student Number</label>
                                    </div>
                    
                                    <div class="form-outline form-white mb-3">
                                        <select class="form-select" id="department" name="department" required disabled>
                                            <option value="0">-- SELECT DEPARTMENT --</option>
                                            <?php
                                                $sql = "SELECT * FROM department WHERE is_deleted=0";
                                                $pst = $pdo->prepare($sql);
                                                $pst->execute();
                                                while ($data = $pst->fetch()) {
                                                    echo "<option value='{$data['deptID']}'>". $data['deptname']  . "</option>";
                                                }
                                            ?>
                                        </select>
                                        <label class="form-label text-dark mt-2" for="department" style="letter-spacing: 2px">Department</label>
                                    </div>

                                    <div class="form-outline form-white mb-3">
                                        <select class="form-select" id="faculty" name="faculty" required disabled>
                                            <option value="0">-- SELECT FACULTY --</option>
                                        </select>
                                        <label class="form-label text-dark mt-2" for="faculty" style="letter-spacing: 2px">Faculty</label>
                                    </div>

                                    <button class="btn btn-lg my-3" name="btnSubmit" type="submit" style="background-color: #960019; color: white; letter-spacing: 2px;"> Start Evaluation </button>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- PLUGINS -->
    <script src="bootstrap-5.3.0-alpha1-dist/js/bootstrap.bundle.min.js"></script>
    <script
        src="https://code.jquery.com/jquery-3.6.4.min.js"
        integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8="
        crossorigin="anonymous"></script>

    <!-- Custom JavaScript Files -->
    <script>
        const baseURL = "<?=BASE_URL?>";
    </script>
    <script src="./js/functions.js"></script>
    <script src="./js/login.js"></script>
</body>
</html>