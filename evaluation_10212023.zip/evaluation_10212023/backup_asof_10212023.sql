/*
SQLyog Ultimate v8.55 
MySQL - 5.5.5-10.4.27-MariaDB : Database - evaluation
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`evaluation` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `evaluation`;

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `catID` int(11) NOT NULL AUTO_INCREMENT,
  `catname` varchar(255) NOT NULL,
  `catdescE` varchar(255) NOT NULL,
  PRIMARY KEY (`catID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `category` */

insert  into `category`(`catID`,`catname`,`catdescE`) values (1,'Mastery of the Subject Matter','Is an evidence of personal and professional growth of the teachers.'),(2,'Teaching Skills and Class Management','Describe the expertise and personal qualities that a teacher needs to possess to thrive while educating students.'),(3,'Personal Traits and Professional Qualities','');

/*Table structure for table `choice` */

DROP TABLE IF EXISTS `choice`;

CREATE TABLE `choice` (
  `choicesID` int(11) NOT NULL AUTO_INCREMENT,
  `choices` tinyint(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`choicesID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `choice` */

insert  into `choice`(`choicesID`,`choices`,`description`) values (1,1,'Need Improvement'),(2,2,'Fair'),(3,3,'Satisfactory'),(4,4,'Very Satisfactory'),(5,5,'Excellent');

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `commID` int(11) NOT NULL AUTO_INCREMENT,
  `studNum` varchar(255) NOT NULL,
  `fmID` int(255) NOT NULL,
  `comms` varchar(255) DEFAULT NULL,
  `pos` int(11) NOT NULL DEFAULT 0,
  `neg` int(11) NOT NULL DEFAULT 0,
  `commdate` datetime DEFAULT NULL,
  PRIMARY KEY (`commID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `comments` */

insert  into `comments`(`commID`,`studNum`,`fmID`,`comms`,`pos`,`neg`,`commdate`) values (1,'19-13777',23,'1',0,0,'2023-10-18 10:56:20'),(2,'19-13777',23,'HAHAHA',0,0,'2023-10-18 11:09:21'),(3,'18-12838',23,'aaaaaa',0,0,'2023-10-18 16:33:55');

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `deptID` int(11) NOT NULL AUTO_INCREMENT,
  `deptcode` varchar(255) NOT NULL,
  `deptname` varchar(255) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`deptID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `department` */

insert  into `department`(`deptID`,`deptcode`,`deptname`,`is_deleted`) values (1,'BSIT','Bachelor of Science in Information Technology',0),(2,'BSHM','Bachelor of Science in Hotel Management',0),(3,'BSTM','Bachelor of Science in Tourism Management',0),(4,'BEED','Bachelor of Elementary Education',0),(5,'BSED','Bachelor of Secondary Education',0),(6,'BSBA','Bachelor of Science in Business Administration',1),(7,'BS Criminology','Bachelor of Science in Criminology',1),(8,'BSES','Bachelor of Science in Environmental Science',1),(9,'BSFi','Bachelor of Science in Fisheries',1),(10,'BSCS','Bachelor of Science in Computer Science',1),(11,'ICT','Information Technology',1),(12,'BCom','Bachelor of Commerce',1),(13,'BPEd','Bachelor of Physical Education',1),(14,'AB Broadcasting','Bachelor of Arts in Broadcasting',1),(15,'BPA','Bachelor of Public Administration',1);

/*Table structure for table `eva` */

DROP TABLE IF EXISTS `eva`;

CREATE TABLE `eva` (
  `evaID` int(11) NOT NULL AUTO_INCREMENT,
  `studNum` varchar(255) NOT NULL,
  `fmID` varchar(255) NOT NULL,
  `quesID` int(255) NOT NULL,
  `choicesID` int(255) NOT NULL,
  `commID` int(11) NOT NULL,
  `evadate` datetime DEFAULT NULL,
  `syID` int(11) NOT NULL,
  PRIMARY KEY (`evaID`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `eva` */

insert  into `eva`(`evaID`,`studNum`,`fmID`,`quesID`,`choicesID`,`commID`,`evadate`,`syID`) values (1,'19-13777','23-00001',1,5,1,'2023-10-18 10:56:20',1),(2,'19-13777','23-00001',2,4,1,'2023-10-18 10:56:20',1),(3,'19-13777','23-00001',3,3,1,'2023-10-18 10:56:20',1),(4,'19-13777','23-00001',4,2,1,'2023-10-18 10:56:20',1),(5,'19-13777','23-00001',5,1,1,'2023-10-18 10:56:20',1),(6,'19-13777','23-00001',6,2,1,'2023-10-18 10:56:20',1),(7,'19-13777','23-00001',7,3,1,'2023-10-18 10:56:20',1),(8,'19-13777','23-00001',8,4,1,'2023-10-18 10:56:20',1),(9,'19-13777','23-00001',9,4,1,'2023-10-18 10:56:20',1),(10,'19-13777','23-00001',10,3,1,'2023-10-18 10:56:20',1),(11,'19-13777','23-00001',11,2,1,'2023-10-18 10:56:20',1),(12,'19-13777','23-00001',12,1,1,'2023-10-18 10:56:20',1),(13,'19-13777','23-00001',13,2,1,'2023-10-18 10:56:20',1),(14,'19-13777','23-00001',14,3,1,'2023-10-18 10:56:20',1),(15,'19-13777','23-00001',15,4,1,'2023-10-18 10:56:20',1),(16,'19-13777','23-00001',16,5,1,'2023-10-18 10:56:20',1),(17,'19-13777','23-00001',17,4,1,'2023-10-18 10:56:20',1),(18,'19-13777','23-00001',18,3,1,'2023-10-18 10:56:20',1),(19,'19-13777','23-00001',19,3,1,'2023-10-18 10:56:20',1),(20,'19-13777','23-00001',20,2,1,'2023-10-18 10:56:20',1),(21,'19-13777','23-00001',21,1,1,'2023-10-18 10:56:20',1),(22,'19-13777','23-00001',22,2,1,'2023-10-18 10:56:20',1),(23,'19-13777','23-00001',23,3,1,'2023-10-18 10:56:20',1),(24,'19-13777','23-00001',24,4,1,'2023-10-18 10:56:20',1),(25,'19-13777','23-00001',25,5,1,'2023-10-18 10:56:20',1),(26,'19-13777','23-00001',26,4,1,'2023-10-18 10:56:20',1),(27,'19-13777','23-00001',27,3,1,'2023-10-18 10:56:20',1),(28,'19-13777','23-00001',28,2,1,'2023-10-18 10:56:20',1),(29,'19-13777','23-00001',29,1,1,'2023-10-18 10:56:20',1),(30,'19-13777','23-00019',1,5,2,'2023-10-18 11:09:21',1),(31,'19-13777','23-00019',2,5,2,'2023-10-18 11:09:21',1),(32,'19-13777','23-00019',3,5,2,'2023-10-18 11:09:21',1),(33,'19-13777','23-00019',4,5,2,'2023-10-18 11:09:21',1),(34,'19-13777','23-00019',5,5,2,'2023-10-18 11:09:21',1),(35,'19-13777','23-00019',6,5,2,'2023-10-18 11:09:21',1),(36,'19-13777','23-00019',7,5,2,'2023-10-18 11:09:21',1),(37,'19-13777','23-00019',8,5,2,'2023-10-18 11:09:21',1),(38,'19-13777','23-00019',9,5,2,'2023-10-18 11:09:21',1),(39,'19-13777','23-00019',10,5,2,'2023-10-18 11:09:21',1),(40,'19-13777','23-00019',11,5,2,'2023-10-18 11:09:21',1),(41,'19-13777','23-00019',12,5,2,'2023-10-18 11:09:21',1),(42,'19-13777','23-00019',13,5,2,'2023-10-18 11:09:21',1),(43,'19-13777','23-00019',14,5,2,'2023-10-18 11:09:21',1),(44,'19-13777','23-00019',15,5,2,'2023-10-18 11:09:21',1),(45,'19-13777','23-00019',16,5,2,'2023-10-18 11:09:21',1),(46,'19-13777','23-00019',17,5,2,'2023-10-18 11:09:21',1),(47,'19-13777','23-00019',18,5,2,'2023-10-18 11:09:21',1),(48,'19-13777','23-00019',19,5,2,'2023-10-18 11:09:21',1),(49,'19-13777','23-00019',20,5,2,'2023-10-18 11:09:21',1),(50,'19-13777','23-00019',21,5,2,'2023-10-18 11:09:21',1),(51,'19-13777','23-00019',22,5,2,'2023-10-18 11:09:21',1),(52,'19-13777','23-00019',23,5,2,'2023-10-18 11:09:21',1),(53,'19-13777','23-00019',24,5,2,'2023-10-18 11:09:21',1),(54,'19-13777','23-00019',25,5,2,'2023-10-18 11:09:21',1),(55,'19-13777','23-00019',26,5,2,'2023-10-18 11:09:21',1),(56,'19-13777','23-00019',27,5,2,'2023-10-18 11:09:21',1),(57,'19-13777','23-00019',28,5,2,'2023-10-18 11:09:21',1),(58,'19-13777','23-00019',29,5,2,'2023-10-18 11:09:21',1),(59,'18-12838','23-00002',1,5,3,'2023-10-18 16:33:55',1),(60,'18-12838','23-00002',2,4,3,'2023-10-18 16:33:55',1),(61,'18-12838','23-00002',3,4,3,'2023-10-18 16:33:55',1),(62,'18-12838','23-00002',4,5,3,'2023-10-18 16:33:55',1),(63,'18-12838','23-00002',5,4,3,'2023-10-18 16:33:55',1),(64,'18-12838','23-00002',6,4,3,'2023-10-18 16:33:55',1),(65,'18-12838','23-00002',7,4,3,'2023-10-18 16:33:55',1),(66,'18-12838','23-00002',8,4,3,'2023-10-18 16:33:55',1),(67,'18-12838','23-00002',9,5,3,'2023-10-18 16:33:55',1),(68,'18-12838','23-00002',10,5,3,'2023-10-18 16:33:55',1),(69,'18-12838','23-00002',11,5,3,'2023-10-18 16:33:55',1),(70,'18-12838','23-00002',12,5,3,'2023-10-18 16:33:55',1),(71,'18-12838','23-00002',13,5,3,'2023-10-18 16:33:55',1),(72,'18-12838','23-00002',14,5,3,'2023-10-18 16:33:55',1),(73,'18-12838','23-00002',15,5,3,'2023-10-18 16:33:55',1),(74,'18-12838','23-00002',16,5,3,'2023-10-18 16:33:55',1),(75,'18-12838','23-00002',17,5,3,'2023-10-18 16:33:55',1),(76,'18-12838','23-00002',18,5,3,'2023-10-18 16:33:55',1),(77,'18-12838','23-00002',19,5,3,'2023-10-18 16:33:55',1),(78,'18-12838','23-00002',20,5,3,'2023-10-18 16:33:55',1),(79,'18-12838','23-00002',21,5,3,'2023-10-18 16:33:55',1),(80,'18-12838','23-00002',22,5,3,'2023-10-18 16:33:55',1),(81,'18-12838','23-00002',23,5,3,'2023-10-18 16:33:55',1),(82,'18-12838','23-00002',24,5,3,'2023-10-18 16:33:55',1),(83,'18-12838','23-00002',25,5,3,'2023-10-18 16:33:55',1),(84,'18-12838','23-00002',26,5,3,'2023-10-18 16:33:55',1),(85,'18-12838','23-00002',27,5,3,'2023-10-18 16:33:55',1),(86,'18-12838','23-00002',28,5,3,'2023-10-18 16:33:55',1),(87,'18-12838','23-00002',29,5,3,'2023-10-18 16:33:55',1);

/*Table structure for table `faculty` */

DROP TABLE IF EXISTS `faculty`;

CREATE TABLE `faculty` (
  `facID` int(11) NOT NULL AUTO_INCREMENT,
  `facNum` varchar(255) DEFAULT NULL,
  `lname` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mi` varchar(255) DEFAULT NULL,
  `deptID` int(10) unsigned NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`facID`),
  UNIQUE KEY `facNum` (`facNum`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `faculty` */

insert  into `faculty`(`facID`,`facNum`,`lname`,`fname`,`mi`,`deptID`,`is_deleted`) values (115,'23-00001','Arsenal','Roy Rouie','',1,0),(116,'23-00002','Asuncion','Valeree',NULL,2,0),(117,'23-00003','Lucero','Machael',NULL,3,0),(118,'23-00004','Lucero','Harold',NULL,2,0),(119,'23-00005','Gagolinan','Noel',NULL,4,0),(120,'23-00006','Gaya','Nandy',NULL,5,0),(121,'23-00007','Carullo','William',NULL,3,0),(122,'23-00008','Roa','Alex',NULL,3,0),(123,'23-00009','Linawan','James',NULL,4,0),(124,'23-00010','Pineda','Rollie',NULL,2,0),(125,'23-00011','Tuazon','Louie',NULL,4,0),(126,'23-00012','Darilag','Benedict',NULL,3,0),(127,'23-00013','Nomabilis','Christine',NULL,3,0),(128,'23-00014','Taguinod','Jovelyn',NULL,4,0),(129,'23-00015','Quezon','Ocfemia',NULL,3,0),(130,'23-00016','Isidoro','Richard',NULL,5,0),(131,'23-00017','Villaseñor','Randy',NULL,4,0),(132,'23-00018','Confessor','May',NULL,4,0),(133,'23-00019','Lumada','Ronalynne',NULL,1,0),(134,'23-00020','Culltivo','Rosell',NULL,4,0),(135,'23-00021','Lim','Patrick',NULL,3,0),(136,'23-00022','Encarnado','Eillen',NULL,2,0),(137,'23-00023','Pena','Lance',NULL,3,0),(138,'23-00024','Candaza','Eliseo',NULL,3,0),(139,'23-00025','Macaraeg','Christine',NULL,2,0),(140,'23-00026','Soriano','Hilda',NULL,4,0),(141,'23-00027','Durana','Jim',NULL,2,0),(142,'23-00028','Velasco','Egardo',NULL,1,0),(143,'23-00029','Roa','Alex',NULL,1,0),(144,'23-00030','Abenir','James',NULL,1,0),(145,'23-00031','Dancel','Edith',NULL,4,0),(146,'23-00032','Laude','Anthony',NULL,1,0),(147,'23-00033','Sanchez','Protacio',NULL,4,0),(148,'23-00034','Matias','Rosechelle',NULL,5,0),(149,'23-00035','Cativo','Jerome',NULL,1,0),(150,'23-00036','De Guzman','Adrian Rey',NULL,1,0),(151,'23-00037','Viray','Ferdinand',NULL,3,0),(152,'23-00038','Bunag','Roy ',NULL,1,0),(153,'23-00039','Maasin','Christian',NULL,1,0),(154,'23-00040','Carolino','Ruselle',NULL,1,0);

/*Table structure for table `faculty_member` */

DROP TABLE IF EXISTS `faculty_member`;

CREATE TABLE `faculty_member` (
  `fmID` int(11) NOT NULL AUTO_INCREMENT,
  `facID` int(255) NOT NULL,
  `deptID` int(255) DEFAULT NULL,
  PRIMARY KEY (`fmID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `faculty_member` */

insert  into `faculty_member`(`fmID`,`facID`,`deptID`) values (1,1,2),(2,2,3),(3,3,3),(4,4,1),(5,5,1),(6,6,3),(7,7,3),(8,8,1),(9,9,1),(10,10,3),(11,11,2),(12,12,1),(13,3,1),(14,14,1),(15,10,4),(16,16,5),(17,17,2),(18,18,1),(19,19,2),(20,20,3),(21,21,5),(22,22,3),(23,27,5),(24,28,4),(25,29,1),(26,30,5),(27,31,1),(28,32,4),(29,15,5),(30,15,3),(31,33,5),(32,34,5);

/*Table structure for table `position` */

DROP TABLE IF EXISTS `position`;

CREATE TABLE `position` (
  `positionnum` int(11) NOT NULL AUTO_INCREMENT,
  `positionname` varchar(255) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`positionnum`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `position` */

insert  into `position`(`positionnum`,`positionname`,`is_deleted`) values (1,'Admin',0),(2,'Dean',0),(3,'Student',0);

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `quesID` int(11) NOT NULL AUTO_INCREMENT,
  `catID` int(10) NOT NULL,
  `ques` varchar(255) NOT NULL,
  `quesTagalog` varchar(255) NOT NULL,
  PRIMARY KEY (`quesID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `questions` */

insert  into `questions`(`quesID`,`catID`,`ques`,`quesTagalog`) values (1,1,'Shows mastery of the theories and principles of the subject matter','Nagpapakita ng karunungan sa mga teorya at prinsipyo ng paksa'),(2,1,'Provides a variety of appropriate examples related to the subject matter and real-life situations','Nagbibigay ng iba\'t ibang angkop na halimbawa na may kaugnay sa paksa at mga sitwasyon sa totoong buhay'),(3,1,'Shows proficient in the language required to use as medium of instruction','Naipapakita ang bihasa sa wikang kinakailangang gamitin bilang midyum sa pagtuturo'),(4,1,'Answer students\' question with clarity and confidence','Sagutin nang malinaw at may kumpiyansa ang mga tanong ng mga mag-aaral'),(5,1,'Explains the lesson thoroughly and emphasizes important points','Naipapaliwanag nang lubusan ang aralin at binibigyang-diin ang mahahalagang punto'),(6,1,'Enriches the lesson through the use of reference materials other than the textbooks','Napapayaman ang aralin sa pamamagitan ng paggamit ng mga sangguniang materyales maliban sa mga aklat-aralin'),(7,1,'Cites up-to-date information on the subject matter','Binabanggit ang napapanahong impormasyon sa paksa'),(8,1,'Comes to class well-prepared','Pumapasok sa klase na handa'),(9,2,'Provide course syllabus/outline and explain learning objectives','Nagbibigay ng silabus/outline ng kurso at ipaliwanag ang mga layunin sa pagkatuto'),(10,2,'Properly orient the students on the Grading system and other requirements of the course','Tamang i-orient ang mga mag-aaral sa Grading system at iba pang pangangailangan ng kurso'),(11,2,'Incorporate a variety of teaching methods and instructional strategies','Isama ang iba\'t ibang paraan ng pagtuturo at istratehiya sa pagtuturo'),(12,2,'Maintain classroom discipline and creates an environment conducive learning','Panatilihin ang disiplina sa silid-aralan at lumilikha at kapaligirang kaaya-aya sa pag-aaral'),(13,2,'Checks and return graded reports and papers within reasonable time','Nagsusuri at nagbabalik ng namarkahang ulat at mga papel sa loob ng makatwirang panahon'),(14,2,'Summarizes key points at the end of every lessons','Nagbubuod ng mahahalagang punto sa katapusan ng bawat aralin'),(15,2,'Prepare tests related to the lesson discussed','Maghanda ng mga pagsusulit na may kaugnayan sa tinalakay na aralin'),(16,2,'Encourage students to react, to discuss, and to ask questions','Himukin ang mga mag-aaral nga mag-react, magtalakay, at magtanong'),(17,2,'Shows confidence, enthusiasm, and vitality in teaching the subject matter','Magpakita ng tiwala, sigasig, at sigla sa pagtuturo ng paksa'),(18,2,'Deliver lessons in accordance with the time frame as prescribed in the syllabus','Maghatid ng mga aralin alinsunod sa takdang panahon na itinakda sa silabus'),(19,3,'Explains in the class vision, mission, and objective/goals of the institution','Nagpapaliwanag sa class vision, mission at objectives/goals ng institusyon'),(20,3,'Integrates Teresian values into teaching','Isinasama ang mga pagpapahalagang Teresian sa pagtuturo'),(21,3,'Makes herself/himself available for consultations','Ginagawang magagamit ang kanyang sarili para sa mga konsultasyon'),(22,3,'Comes to class regularly','Regular na pumasok sa klase'),(23,3,'Starts and dismissess the class on time','Magsimula at mag-dismiss sa klase sa takdang oras'),(24,3,'Summarizes key points at the end of every lessons','Nagbubuod ng mahahalagang punto sa pagtatapos ng bawat aralin'),(25,3,'Provides timely feedback to the students on their performance','Nakapagbibigay ng napapanahong puna sa mga mag-aaral sa kanilang pagganap'),(26,3,'Observes proper dress code and grooming','Nasusunod ang wastong pananamit at pag-aayos'),(27,3,'Exhibits proper conduct worthy of respect by the students','Nagpapakita ng wastong pag-uugali na karapat-dapat igalang ang mga maga-aaral'),(28,3,'Shows respect for students','Nagpapakita ng paggalang sa mga mag-aaral'),(29,3,'Observes fairness in giving grades','Nagmamasid sa pagiging patas sa pagbibigay ng grado');

/*Table structure for table `save` */

DROP TABLE IF EXISTS `save`;

CREATE TABLE `save` (
  `answerID` int(255) NOT NULL AUTO_INCREMENT,
  `quesID` int(255) NOT NULL,
  `catID` int(10) NOT NULL,
  `answer` int(10) NOT NULL,
  PRIMARY KEY (`answerID`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `save` */

insert  into `save`(`answerID`,`quesID`,`catID`,`answer`) values (1,1,0,5),(2,2,0,4),(3,3,0,4),(4,4,0,4),(5,5,0,5),(6,6,0,5),(7,7,0,5),(8,8,0,4),(9,9,0,3),(10,10,0,3),(11,11,0,3),(12,12,0,3),(13,13,0,4),(14,14,0,4),(15,15,0,3),(16,16,0,2),(17,17,0,5),(18,18,0,5),(19,19,0,4),(20,20,0,3),(21,21,0,2),(22,22,0,1),(23,23,0,2),(24,24,0,3),(25,25,0,4),(26,26,0,5),(27,27,0,4),(28,28,0,3),(29,29,0,3),(30,30,0,3),(31,1,0,5),(32,2,0,5),(33,3,0,4),(34,4,0,4),(35,5,0,3),(36,6,0,3),(37,7,0,2),(38,8,0,2),(39,9,0,1),(40,10,0,1),(41,11,0,2),(42,12,0,4),(43,13,0,5),(44,14,0,5),(45,15,0,4),(46,16,0,3),(47,17,0,2),(48,18,0,1),(49,19,0,2),(50,20,0,3),(51,21,0,4),(52,22,0,5),(53,23,0,4),(54,24,0,3),(55,25,0,2),(56,26,0,1),(57,27,0,1),(58,28,0,1),(59,29,0,1),(60,30,0,1),(61,1,0,5),(62,2,0,5),(63,3,0,4),(64,4,0,5),(65,5,0,4),(66,6,0,5),(67,7,0,4),(68,8,0,5),(69,9,0,4),(70,10,0,5),(71,11,0,4),(72,12,0,5),(73,13,0,5),(74,14,0,5),(75,15,0,5),(76,16,0,5),(77,17,0,5),(78,18,0,5),(79,19,0,4),(80,20,0,5),(81,21,0,4),(82,22,0,5),(83,23,0,5),(84,24,0,5),(85,25,0,4),(86,26,0,5),(87,27,0,5),(88,28,0,5),(89,29,0,5),(90,30,0,5);

/*Table structure for table `school_year` */

DROP TABLE IF EXISTS `school_year`;

CREATE TABLE `school_year` (
  `syID` int(11) NOT NULL AUTO_INCREMENT,
  `sy` varchar(9) NOT NULL,
  `termID` tinyint(4) DEFAULT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `is_deleted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`syID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `school_year` */

insert  into `school_year`(`syID`,`sy`,`termID`,`is_active`,`is_deleted`) values (1,'2022-2023',1,0,0),(2,'2023-2024',1,0,0),(3,'2024-2025',2,0,0),(4,'2025-2026',2,0,0),(6,'2026-2027',1,0,0),(8,'2027-2028',2,0,0),(9,'2028-2029',1,0,0),(11,'2029-2031',2,0,0),(12,'2029-2030',1,0,0),(13,'2030-2031',2,1,0),(15,'2031-2032',1,0,0),(16,'2032-2033',1,0,0);

/*Table structure for table `sentiment` */

DROP TABLE IF EXISTS `sentiment`;

CREATE TABLE `sentiment` (
  `sentimentID` int(2) NOT NULL AUTO_INCREMENT,
  `sentiments` varchar(20) NOT NULL,
  PRIMARY KEY (`sentimentID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `sentiment` */

insert  into `sentiment`(`sentimentID`,`sentiments`) values (1,'positive'),(2,'negative');

/*Table structure for table `settings` */

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `syID` int(11) NOT NULL,
  `termID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `settings` */

insert  into `settings`(`syID`,`termID`) values (1,2);

/*Table structure for table `students` */

DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `studID` int(11) NOT NULL AUTO_INCREMENT,
  `studnum` varchar(255) DEFAULT NULL,
  `lname` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mi` varchar(255) DEFAULT NULL,
  `deptID` int(11) NOT NULL,
  `is_deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`studID`)
) ENGINE=InnoDB AUTO_INCREMENT=648 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `students` */

insert  into `students`(`studID`,`studnum`,`lname`,`fname`,`mi`,`deptID`,`is_deleted`) values (486,'20-14767','Abobon','Dannabelle Jane',NULL,1,0),(487,'18-12838','Alde','John Jay',NULL,2,0),(488,'19-14171','Arcibal','Patricia Maria',NULL,1,0),(489,'20-14918','Bernal','Joshua',NULL,4,0),(490,'18-13007','Berondo','Jaspher Jay',NULL,3,0),(491,'20-14968','Cabittada','Jerald',NULL,2,0),(492,'18-12873','Camba','Kyle',NULL,4,0),(493,'18-13168','Cayaban','Jose Carlo',NULL,5,0),(494,'19-13864','Dadis','Zyra Natalie',NULL,1,0),(495,'19-14181','Daga','Mary Jane',NULL,5,0),(496,'20-14954','Doblon','Mark Angelo ',NULL,1,0),(497,'20-14853','Duhaylungsod','Samuel',NULL,5,0),(498,'21-14994','Edoria','John Daniel',NULL,1,0),(499,'19-13983','Galon ','Ivan Harvey',NULL,5,0),(500,'18-13105','Geminiano','Sam',NULL,4,0),(501,'19-13839','Gilbaliga','Herdine',NULL,3,0),(502,'19-14152','Gunting','Jeane Rose',NULL,2,0),(503,'14-7385','Herbulario','Oscar',NULL,2,0),(504,'20-14772','Jaramillo','John Christian ',NULL,4,0),(505,'18-12858','Balondo','Raymond',NULL,1,0),(506,'16-11202','Jusay','Jessica',NULL,4,0),(507,'20-14810','Licardo','Ma. Nina Moanna',NULL,1,0),(508,'18-13124','Lizaba','Rina Clarisse',NULL,4,0),(509,'19-13777','Mameloto','Nicole','',1,0),(510,'20-14904','Manahan ','John Mark Lester',NULL,5,0),(511,'18-12905','Ortile','John Christopher',NULL,1,0),(512,'20-14870','Papango','Noel',NULL,4,0),(513,'18-12809','Puzon','Harold Francis',NULL,4,0),(514,'20-14829','Rafanan','Michael Angelo',NULL,2,0),(515,'18-12879','Raymundo','Nichols',NULL,5,0),(516,'17-12397','Reyes','Mart Adrian',NULL,4,0),(517,NULL,'Rodriguez','Sheryl',NULL,4,1),(518,'18-13201','Samar','Spencer',NULL,1,0),(519,'19-14001','Ulatan','Arjehwie',NULL,5,0),(520,'20-14777','Villanueva','Jeverlyn',NULL,3,0),(521,'19-14252','Acha','Jhon Arthur',NULL,4,0),(522,'20-14925','Adviento','Emmanuel Gabriel',NULL,5,0),(523,'20-14958','Baron','Marc Paul',NULL,5,0),(524,'20-14825','Bongapat','John Ric',NULL,3,0),(525,'21-00343','Cabusora','Jeffrey',NULL,1,0),(526,'21-00394','Capoquian','Jomer',NULL,2,0),(527,'19-14378','Caramoan','Raniel John',NULL,2,0),(528,'20-14786','Carpo','Joeshua Carl',NULL,5,0),(529,'20-14778','Colina','Joshua ',NULL,3,0),(530,'18-12890','Diaz','Timothy Justin',NULL,1,0),(531,'20-14977','Filomeno','John Francis',NULL,3,0),(532,'16-11568','Garcia','Auwen Hartt',NULL,2,0),(533,'18-13135','Groesbeck','Christian',NULL,5,0),(534,'20-14971','Huertas','Charles',NULL,3,0),(535,'18-12973','Inocencio','Angelie',NULL,4,0),(536,'18-12995','Jacobo','Janzelle',NULL,2,0),(537,'20-14951','Javier','Christian',NULL,1,0),(538,'20-14942','Labrador','Jeem Roi',NULL,1,0),(539,'20-14956','Maiquez','Image Marie',NULL,5,0),(540,'18-13640','Moralba','Jean Claude',NULL,3,0),(541,'20-14882','Muyco','Ysrael',NULL,2,0),(542,'19-14113','Navalta','Daniel Paul',NULL,5,0),(543,'19-13912','Noda','Jeperson',NULL,1,0),(544,'18-13493','Palamara','Bryan',NULL,2,0),(545,'20-14897','Piertemos','Jemaima',NULL,5,0),(546,'19-14401','Quibol','John Ray',NULL,2,0),(547,'20-14782','Rivas','Karkleo',NULL,3,0),(548,'20-14906','Rosario','Junmar',NULL,2,0),(549,'20-14834','Ruado','Brent Andrei',NULL,2,0),(550,'18-13677','Ruedas','John Ferry',NULL,1,0),(551,'20-14889','Saballa','Yves Cyruz',NULL,2,0),(552,'20-14849','Taboada','Marc Michael',NULL,3,0),(553,'18-13070','Villa',' Michael',NULL,2,0),(554,'18-13136','Vitug','Adrian Jade',NULL,4,0),(555,'20-14946','Yee','Cedrick',NULL,5,0),(556,'21-00245','Mabutin','Pia',NULL,5,0),(557,'21-00298','Almaden','John Patrick ',NULL,5,0),(558,'21-00431','Angara ','Dionel',NULL,3,0),(559,'22-00207','Borja','Jeffrey',NULL,5,0),(560,'21-00584','Bugayong','Frederick',NULL,3,0),(561,'21-00402','Carolino','Reggie',NULL,2,0),(562,'21-00092','Catubig','Paul Anthony',NULL,4,0),(563,'15-10677','Clemente','Tito Armando',NULL,1,0),(564,'21-00209','Del Monte','Jhon Erolle',NULL,3,0),(565,'22-00249','Del Rosario','Christian Lloyd',NULL,4,0),(566,'21-00264','Dela Cruz','Derick Dionice',NULL,2,0),(567,'21-14987','Domingo','John Benedict',NULL,1,0),(568,'21-00420','Fortuna','Gloria',NULL,5,0),(569,'21-00217','Gilbaliga','Jayson',NULL,1,0),(570,'22-00206','Jimenez','Leian Joseph',NULL,4,0),(571,'21-00196','Lagua','Carlo',NULL,3,0),(572,'21-00306','Lebuna','Jayric',NULL,2,0),(573,'21-00149','Logmao','Darren Andrei',NULL,5,0),(574,'21-00265','Loto','Micah Ella',NULL,3,0),(575,'21-00364','Lucas','Allen Mark',NULL,5,0),(576,'13-6388','Mancanes','Mareal Ann','',4,0),(577,'','Navaroza','Claudine Febrey','',0,0),(578,'21-00226','Ordoño','Maricris',NULL,2,0),(579,'21-00421','Peñaranda','Jonathan',NULL,3,0),(580,'21-00312','Plasabas','Daryl',NULL,5,0),(581,'21-00307','Reyes','Anthony Justin',NULL,2,0),(582,'21-00059','Rosario','Jeffrey',NULL,2,0),(583,'22-00205','Sereño','Justine',NULL,3,0),(584,'21-00168','Sila','John Ricoh',NULL,5,0),(585,'21-00141','Sunguad','Mark Danrill',NULL,4,0),(586,'21-00038','Villanueva','Ernesto Emil',NULL,1,0),(587,'21-00017','Achondo','Joshua Trazen',NULL,2,0),(588,'21-00446','Arellano','Reigner Dranreb',NULL,4,0),(589,'21-00419','Barreda','Lordlene',NULL,3,0),(590,'21-00399','Barron','Babylyn',NULL,2,0),(591,'21-00193','Belen','Justice',NULL,1,0),(592,'21-00095','Bufi','John Joshua',NULL,4,0),(593,'21-00155','Bunag','Rob Maynard',NULL,5,0),(594,'19-14118','Cabrera','Matthew',NULL,2,0),(595,'21-00424','Calano','Aljhon',NULL,3,0),(596,'21-00036','Coronel','Niña Sophia',NULL,5,0),(597,'21-00101','Dautil','John Michael',NULL,3,0),(598,'21-00075','Espinosa','Mark Jason',NULL,2,0),(599,'21-00471','Francisco','Elna',NULL,4,0),(600,'21-00429','Gregorio','Arabela',NULL,2,0),(601,'19-14419','Llaneta','Ma. Cristel',NULL,2,0),(602,'21-00313','Lopez','Johnsen',NULL,1,0),(603,'21-00090','Maglinao','Joshua',NULL,3,0),(604,'21-00439','Manaog','Shyrille',NULL,5,0),(605,'21-00139','Mangompit','Karylle',NULL,1,0),(606,'21-00072','Navarro','Alliah Mei',NULL,1,0),(607,'21-00614','Odog','Froilan',NULL,3,0),(608,'21-00321','Olila','Dyno',NULL,5,0),(609,'23-00292','Pineda ','Emmanuel ',NULL,2,0),(610,'21-00544','Quibol','Den Mark',NULL,1,0),(611,'21-00132','Quimora','Khervin John',NULL,4,0),(612,'21-00027','Rodriguez','Mariel',NULL,1,0),(613,'21-00077','Sabas','Gabrielle Ann',NULL,1,0),(614,'21-00465','Suanson','Rochelle',NULL,5,0),(615,'21-00089','Troyo','Stanly Angelo',NULL,4,0),(616,'21-00048','Tumalom','Ferdinand',NULL,3,0),(617,'19-14657','Vargas','Rhenzel',NULL,3,0),(618,'21-00713','Alaba','Renz',NULL,1,0),(619,'21-00320','Arboleda','Arrone',NULL,4,0),(620,'21-00349','Asumbrado','Ahrren',NULL,3,0),(621,'21-00315','Ayoon','Ricks',NULL,2,0),(622,'21-00324','Cadayona','Frederick Ruis',NULL,5,0),(623,'21-00309','Casta','Mark Edison',NULL,3,0),(624,'21-00650','Castillo','Christian Bernard',NULL,2,0),(625,'21-00158','Catequista','Marc Daniele',NULL,2,0),(626,'14-7164','Contreras','Lyra Pearl',NULL,1,0),(627,'21-00400','Dairo','Adrian',NULL,4,0),(628,'21-00230','David','Jhon Kieslr',NULL,1,0),(629,'21-00367','Dela Cruz','Jordan',NULL,3,0),(630,'21-00486','Dela Torre','Orlando',NULL,3,0),(631,'21-00381','Gupo','Junrie',NULL,2,0),(632,'19-14044','Hofileña','John Rin Mart',NULL,1,0),(633,'21-00303','Lim','Jhon Paolo',NULL,4,0),(634,'21-00280','Morte','Renzy Carlo',NULL,1,0),(635,'21-00723','Muncal','Eizal Kate',NULL,5,0),(636,'19-13995','Obo','Francis',NULL,4,0),(637,'22-00148','Obseñares','Paul Vincent',NULL,3,0),(638,'21-00531','Parallag','Hannah Sarah',NULL,1,0),(639,'19-13768','Rabanes','Jose Fernan',NULL,3,0),(640,'21-00603','Rabino','Mañolito',NULL,5,0),(641,'19-14101','Rebuelta','Elijan Ken',NULL,4,0),(642,'21-00259','Salas','Robert',NULL,2,0),(643,'21-00247','Santos','John Deo',NULL,1,0),(644,'22-00271','Sedilla','Mark Roldan',NULL,4,0),(645,'21-00301','Somoza','Franklin',NULL,5,0),(646,'20-14922','Tanjutco','Rhode Jefferson',NULL,3,0),(647,'a','','','',0,0);

/*Table structure for table `students2` */

DROP TABLE IF EXISTS `students2`;

CREATE TABLE `students2` (
  `studID` int(11) NOT NULL AUTO_INCREMENT,
  `studnum` varchar(255) DEFAULT NULL,
  `lname` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mi` varchar(255) DEFAULT NULL,
  `deptID` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`studID`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `students2` */

insert  into `students2`(`studID`,`studnum`,`lname`,`fname`,`mi`,`deptID`,`is_deleted`) values (38,'20-14767','Abobon','Dannabelle Jane',NULL,1,0),(39,'18-12838','Alde','John Jay',NULL,2,0),(40,'19-14171','Arcibal','Patricia Maria',NULL,1,0),(41,'20-14918','Bernal','Joshua',NULL,4,0),(42,'18-13007','Berondo','Jaspher Jay',NULL,3,0),(43,'20-14968','Cabittada','Jerald',NULL,2,0),(44,'18-12873','Camba','Kyle',NULL,4,0),(45,'18-13168','Cayaban','Jose Carlo',NULL,5,0),(46,'19-13864','Dadis','Zyra Natalie',NULL,1,0),(47,'19-14181','Daga','Mary Jane',NULL,5,0),(48,'20-14954','Doblon','Mark Angelo ',NULL,1,0),(49,'20-14853','Duhaylungsod','Samuel',NULL,5,0),(50,'21-14994','Edoria','John Daniel',NULL,1,0),(51,'19-13983','Galon ','Ivan Harvey',NULL,5,0),(52,'18-13105','Geminiano','Sam',NULL,4,0),(53,'19-13839','Gilbaliga','Herdine',NULL,3,0),(54,'19-14152','Gunting','Jeane Rose',NULL,2,0),(55,'14-7385','Herbulario','Oscar',NULL,2,0),(56,'20-14772','Jaramillo','John Christian ',NULL,4,0),(57,'18-12858','Jandugan','Jester',NULL,1,0),(58,'16-11202','Jusay','Jessica',NULL,4,0),(59,'20-14810','Licardo','Ma. Nina Moanna',NULL,1,0),(60,'18-13124','Lizaba','Rina Clarisse',NULL,4,0),(61,'19-13777','Mameloto','Nicole',NULL,1,0),(62,'20-14904','Manahan ','John Mark Lester',NULL,5,0),(63,'18-12905','Ortile','John Christopher',NULL,1,0),(64,'20-14870','Papango','Noel',NULL,4,0),(65,'18-12809','Puzon','Harold Francis',NULL,4,0),(66,'20-14829','Rafanan','Michael Angelo',NULL,2,0),(67,'18-12879','Raymundo','Nichols',NULL,5,0),(68,'17-12397','Reyes','Mart Adrian',NULL,4,0),(69,NULL,'Rodriguez','Sheryl',NULL,4,0),(70,'18-13201','Samar','Spencer',NULL,1,0),(71,'19-14001','Ulatan','Arjehwie',NULL,5,0),(72,'20-14777','Villanueva','Jeverlyn',NULL,3,0),(73,'19-14252','Acha','Jhon Arthur',NULL,4,0),(74,'20-14925','Adviento','Emmanuel Gabriel',NULL,5,0),(75,'20-14958','Baron','Marc Paul',NULL,5,0),(76,'20-14825','Bongapat','John Ric',NULL,3,0),(77,'21-00343','Cabusora','Jeffrey',NULL,1,0),(78,'21-00394','Capoquian','Jomer',NULL,2,0),(79,'19-14378','Caramoan','Raniel John',NULL,2,0),(80,'20-14786','Carpo','Joeshua Carl',NULL,5,0),(81,'20-14778','Colina','Joshua ',NULL,3,0),(82,'18-12890','Diaz','Timothy Justin',NULL,1,0),(83,'20-14977','Filomeno','John Francis',NULL,3,0),(84,'16-11568','Garcia','Auwen Hartt',NULL,2,0),(85,'18-13135','Groesbeck','Christian',NULL,5,0),(86,'20-14971','Huertas','Charles',NULL,3,0),(87,'18-12973','Inocencio','Angelie',NULL,4,0),(88,'18-12995','Jacobo','Janzelle',NULL,2,0),(89,'20-14951','Javier','Christian',NULL,1,0),(90,'20-14942','Labrador','Jeem Roi',NULL,1,0),(91,'20-14956','Maiquez','Image Marie',NULL,5,0),(92,'18-13640','Moralba','Jean Claude',NULL,3,0),(93,'20-14882','Muyco','Ysrael',NULL,2,0),(94,'19-14113','Navalta','Daniel Paul',NULL,5,0),(95,'19-13912','Noda','Jeperson',NULL,1,0),(96,'18-13493','Palamara','Bryan',NULL,2,0),(97,'20-14897','Piertemos','Jemaima',NULL,5,0),(98,'19-14401','Quibol','John Ray',NULL,2,0),(99,'20-14782','Rivas','Karkleo',NULL,3,0),(100,'20-14906','Rosario','Junmar',NULL,2,0),(101,'20-14834','Ruado','Brent Andrei',NULL,2,0),(102,'18-13677','Ruedas','John Ferry',NULL,1,0),(103,'20-14889','Saballa','Yves Cyruz',NULL,2,0),(104,'20-14849','Taboada','Marc Michael',NULL,3,0),(105,'18-13070','Villa',' Michael',NULL,2,0),(106,'18-13136','Vitug','Adrian Jade',NULL,4,0),(107,'20-14946','Yee','Cedrick',NULL,5,0),(108,'21-00245','Abitona','Kent Andrei',NULL,1,0),(109,'21-00298','Almaden','John Patrick ',NULL,5,0),(110,'21-00431','Angara ','Dionel',NULL,3,0),(111,'22-00207','Borja','Jeffrey',NULL,5,0),(112,'21-00584','Bugayong','Frederick',NULL,3,0),(113,'21-00402','Carolino','Reggie',NULL,2,0),(114,'21-00092','Catubig','Paul Anthony',NULL,4,0),(115,'15-10677','Clemente','Tito Armando',NULL,1,0),(116,'21-00209','Del Monte','Jhon Erolle',NULL,3,0),(117,'22-00249','Del Rosario','Christian Lloyd',NULL,4,0),(118,'21-00264','Dela Cruz','Derick Dionice',NULL,2,0),(119,'21-14987','Domingo','John Benedict',NULL,1,0),(120,'21-00420','Fortuna','Gloria',NULL,5,0),(121,'21-00217','Gilbaliga','Jayson',NULL,1,0),(122,'22-00206','Jimenez','Leian Joseph',NULL,4,0),(123,'21-00196','Lagua','Carlo',NULL,3,0),(124,'21-00306','Lebuna','Jayric',NULL,2,0),(125,'21-00149','Logmao','Darren Andrei',NULL,5,0),(126,'21-00265','Loto','Micah Ella',NULL,3,0),(127,'21-00364','Lucas','Allen Mark',NULL,5,0),(128,'13-6388','Mancanes','Mareal Ann',NULL,4,0),(129,'13-5639','Navaroza','Claudine Febrey',NULL,1,0),(130,'21-00226','Ordoño','Maricris',NULL,2,0),(131,'21-00421','Peñaranda','Jonathan',NULL,3,0),(132,'21-00312','Plasabas','Daryl',NULL,5,0),(133,'21-00307','Reyes','Anthony Justin',NULL,2,0),(134,'21-00059','Rosario','Jeffrey',NULL,2,0),(135,'22-00205','Sereño','Justine',NULL,3,0),(136,'21-00168','Sila','John Ricoh',NULL,5,0),(137,'21-00141','Sunguad','Mark Danrill',NULL,4,0),(138,'21-00038','Villanueva','Ernesto Emil',NULL,1,0),(139,'21-00017','Achondo','Joshua Trazen',NULL,2,0),(140,'21-00446','Arellano','Reigner Dranreb',NULL,4,0),(141,'21-00419','Barreda','Lordlene',NULL,3,0),(142,'21-00399','Barron','Babylyn',NULL,2,0),(143,'21-00193','Belen','Justice',NULL,1,0),(144,'21-00095','Bufi','John Joshua',NULL,4,0),(145,'21-00155','Bunag','Rob Maynard',NULL,5,0),(146,'19-14118','Cabrera','Matthew',NULL,2,0),(147,'21-00424','Calano','Aljhon',NULL,3,0),(148,'21-00036','Coronel','Niña Sophia',NULL,5,0),(149,'21-00101','Dautil','John Michael',NULL,3,0),(150,'21-00075','Espinosa','Mark Jason',NULL,2,0),(151,'21-00471','Francisco','Elna',NULL,4,0),(152,'21-00429','Gregorio','Arabela',NULL,2,0),(153,'19-14419','Llaneta','Ma. Cristel',NULL,2,0),(154,'21-00313','Lopez','Johnsen',NULL,1,0),(155,'21-00090','Maglinao','Joshua',NULL,3,0),(156,'21-00439','Manaog','Shyrille',NULL,5,0),(157,'21-00139','Mangompit','Karylle',NULL,1,0),(158,'21-00072','Navarro','Alliah Mei',NULL,1,0),(159,'21-00614','Odog','Froilan',NULL,3,0),(160,'21-00321','Olila','Dyno',NULL,5,0),(161,'23-00292','Pineda ','Emmanuel ',NULL,2,0),(162,'21-00544','Quibol','Den Mark',NULL,1,0),(163,'21-00132','Quimora','Khervin John',NULL,4,0),(164,'21-00027','Rodriguez','Mariel',NULL,1,0),(165,'21-00077','Sabas','Gabrielle Ann',NULL,1,0),(166,'21-00465','Suanson','Rochelle',NULL,5,0),(167,'21-00089','Troyo','Stanly Angelo',NULL,4,0),(168,'21-00048','Tumalom','Ferdinand',NULL,3,0),(169,'19-14657','Vargas','Rhenzel',NULL,3,0),(170,'21-00713','Alaba','Renz',NULL,1,0),(171,'21-00320','Arboleda','Arrone',NULL,4,0),(172,'21-00349','Asumbrado','Ahrren',NULL,3,0),(173,'21-00315','Ayoon','Ricks',NULL,2,0),(174,'21-00324','Cadayona','Frederick Ruis',NULL,5,0),(175,'21-00309','Casta','Mark Edison',NULL,3,0),(176,'21-00650','Castillo','Christian Bernard',NULL,2,0),(177,'21-00158','Catequista','Marc Daniele',NULL,2,0),(178,'14-7164','Contreras','Lyra Pearl',NULL,1,0),(179,'21-00400','Dairo','Adrian',NULL,4,0),(180,'21-00230','David','Jhon Kieslr',NULL,1,0),(181,'21-00367','Dela Cruz','Jordan',NULL,3,0),(182,'21-00486','Dela Torre','Orlando',NULL,3,0),(183,'21-00381','Gupo','Junrie',NULL,2,0),(184,'19-14044','Hofileña','John Rin Mart',NULL,1,0),(185,'21-00303','Lim','Jhon Paolo',NULL,4,0),(186,'21-00280','Morte','Renzy Carlo',NULL,1,0),(187,'21-00723','Muncal','Eizal Kate',NULL,5,0),(188,'19-13995','Obo','Francis',NULL,4,0),(189,'22-00148','Obseñares','Paul Vincent',NULL,3,0),(190,'21-00531','Parallag','Hannah Sarah',NULL,1,0),(191,'19-13768','Rabanes','Jose Fernan',NULL,3,0),(192,'21-00603','Rabino','Mañolito',NULL,5,0),(193,'19-14101','Rebuelta','Elijan Ken',NULL,4,0),(194,'21-00259','Salas','Robert',NULL,2,0),(195,'21-00247','Santos','John Deo',NULL,1,0),(196,'22-00271','Sedilla','Mark Roldan',NULL,4,0),(197,'21-00301','Somoza','Franklin',NULL,5,0),(198,'20-14922','Tanjutco','Rhode Jefferson',NULL,3,0);

/*Table structure for table `terms` */

DROP TABLE IF EXISTS `terms`;

CREATE TABLE `terms` (
  `termID` int(11) NOT NULL AUTO_INCREMENT,
  `term` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`termID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `terms` */

insert  into `terms`(`termID`,`term`) values (1,'1st Semester'),(2,'2nd Semester');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `mname` varchar(255) DEFAULT NULL,
  `positionnum` int(255) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`userid`,`lname`,`fname`,`mname`,`positionnum`,`is_deleted`,`username`,`password`) values (1,'Linawan','James','Lustre',1,0,'james','james'),(2,'Lucero','Harold','Ramirez',2,0,'harold','harold'),(3,'Arsenal','Roy Rouie','Mangubat',3,1,'roy','roy'),(4,'Gagolinan','Noel','Atilla',1,0,'gags','gags'),(5,'Buenavista','JunJun','Labo',1,1,'junjun','junjun'),(6,'Dadis','Alexandra Marie','Ventura',3,0,'marie','marie');

/*Table structure for table `vweva` */

DROP TABLE IF EXISTS `vweva`;

/*!50001 DROP VIEW IF EXISTS `vweva` */;
/*!50001 DROP TABLE IF EXISTS `vweva` */;

/*!50001 CREATE TABLE  `vweva`(
 `studnum` varchar(255) ,
 `facNum` varchar(255) ,
 `fmID` varchar(255) ,
 `facID` int(11) ,
 `fname` varchar(255) ,
 `mi` varchar(255) ,
 `lname` varchar(255) ,
 `is_deleted` tinyint(1) ,
 `fullname` text ,
 `deptID` int(10) unsigned ,
 `deptcode` varchar(255) ,
 `deptname` varchar(255) ,
 `quesID` int(11) ,
 `ques` varchar(255) ,
 `catID` int(11) ,
 `catname` varchar(255) ,
 `choicesID` int(255) ,
 `choices` tinyint(10) ,
 `description` varchar(255) ,
 `commID` int(11) ,
 `comms` varchar(255) ,
 `commdate` datetime ,
 `pos` int(11) ,
 `neg` int(11) ,
 `syID` int(11) ,
 `sy` varchar(9) ,
 `term` varchar(50) ,
 `evadate` datetime 
)*/;

/*Table structure for table `vwfacultymembers` */

DROP TABLE IF EXISTS `vwfacultymembers`;

/*!50001 DROP VIEW IF EXISTS `vwfacultymembers` */;
/*!50001 DROP TABLE IF EXISTS `vwfacultymembers` */;

/*!50001 CREATE TABLE  `vwfacultymembers`(
 `fmID` int(11) ,
 `facID` int(11) ,
 `lname` varchar(255) ,
 `fname` varchar(255) ,
 `mi` varchar(255) ,
 `fullname` varchar(512) ,
 `faculty_is_deleted` tinyint(1) ,
 `deptID` int(11) ,
 `deptcode` varchar(255) ,
 `deptname` varchar(255) ,
 `dept_is_deleted` tinyint(1) 
)*/;

/*Table structure for table `vwquestions` */

DROP TABLE IF EXISTS `vwquestions`;

/*!50001 DROP VIEW IF EXISTS `vwquestions` */;
/*!50001 DROP TABLE IF EXISTS `vwquestions` */;

/*!50001 CREATE TABLE  `vwquestions`(
 `quesID` int(11) ,
 `question` varchar(255) ,
 `questionTagalog` varchar(255) ,
 `catID` int(11) ,
 `catname` varchar(255) 
)*/;

/*Table structure for table `vwstud` */

DROP TABLE IF EXISTS `vwstud`;

/*!50001 DROP VIEW IF EXISTS `vwstud` */;
/*!50001 DROP TABLE IF EXISTS `vwstud` */;

/*!50001 CREATE TABLE  `vwstud`(
 `studID` int(11) ,
 `studnum` varchar(255) ,
 `lname` varchar(255) ,
 `fname` varchar(255) ,
 `mi` varchar(255) ,
 `fullname` text ,
 `stud_is_deleted` tinyint(1) ,
 `deptID` int(11) ,
 `deptcode` varchar(255) ,
 `deptname` varchar(255) ,
 `dept_is_deleted` tinyint(1) 
)*/;

/*Table structure for table `vw_faculties` */

DROP TABLE IF EXISTS `vw_faculties`;

/*!50001 DROP VIEW IF EXISTS `vw_faculties` */;
/*!50001 DROP TABLE IF EXISTS `vw_faculties` */;

/*!50001 CREATE TABLE  `vw_faculties`(
 `facID` int(11) ,
 `facNum` varchar(255) ,
 `lname` varchar(255) ,
 `fname` varchar(255) ,
 `mi` varchar(255) ,
 `deptID` int(11) ,
 `deptcode` varchar(255) ,
 `deptname` varchar(255) ,
 `is_deleted` tinyint(1) 
)*/;

/*View structure for view vweva */

/*!50001 DROP TABLE IF EXISTS `vweva` */;
/*!50001 DROP VIEW IF EXISTS `vweva` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vweva` AS (select `a`.`studNum` AS `studnum`,`b`.`facNum` AS `facNum`,`a`.`fmID` AS `fmID`,`b`.`facID` AS `facID`,`b`.`fname` AS `fname`,`b`.`mi` AS `mi`,`b`.`lname` AS `lname`,`b`.`is_deleted` AS `is_deleted`,concat(`b`.`fname`,' ',`b`.`lname`,' ',ifnull(`b`.`mi`,'')) AS `fullname`,`b`.`deptID` AS `deptID`,`c`.`deptcode` AS `deptcode`,`c`.`deptname` AS `deptname`,`d`.`quesID` AS `quesID`,`d`.`ques` AS `ques`,`e`.`catID` AS `catID`,`e`.`catname` AS `catname`,`a`.`choicesID` AS `choicesID`,`f`.`choices` AS `choices`,`f`.`description` AS `description`,`a`.`commID` AS `commID`,`g`.`comms` AS `comms`,`g`.`commdate` AS `commdate`,`g`.`pos` AS `pos`,`g`.`neg` AS `neg`,`a`.`syID` AS `syID`,`h`.`sy` AS `sy`,`j`.`term` AS `term`,`a`.`evadate` AS `evadate` from (((((((((`eva` `a` join `faculty` `b` on(`b`.`facNum` = `a`.`fmID`)) join `department` `c` on(`c`.`deptID` = `b`.`deptID`)) join `questions` `d` on(`d`.`quesID` = `a`.`quesID`)) join `category` `e` on(`e`.`catID` = `d`.`catID`)) join `choice` `f` on(`f`.`choicesID` = `a`.`choicesID`)) join `comments` `g` on(`g`.`commID` = `a`.`commID`)) join `school_year` `h` on(`h`.`syID` = `a`.`syID`)) join `settings` `i` on(`i`.`syID` = `a`.`syID`)) join `terms` `j` on(`j`.`termID` = `i`.`termID`))) */;

/*View structure for view vwfacultymembers */

/*!50001 DROP TABLE IF EXISTS `vwfacultymembers` */;
/*!50001 DROP VIEW IF EXISTS `vwfacultymembers` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwfacultymembers` AS select `fm`.`fmID` AS `fmID`,`f`.`facID` AS `facID`,`f`.`lname` AS `lname`,`f`.`fname` AS `fname`,`f`.`mi` AS `mi`,concat(ucase(`f`.`lname`),', ',`f`.`fname`) AS `fullname`,`f`.`is_deleted` AS `faculty_is_deleted`,`d`.`deptID` AS `deptID`,`d`.`deptcode` AS `deptcode`,`d`.`deptname` AS `deptname`,`d`.`is_deleted` AS `dept_is_deleted` from ((`faculty_member` `fm` join `faculty` `f` on(`fm`.`facID` = `f`.`facID`)) join `department` `d` on(`fm`.`deptID` = `d`.`deptID`)) */;

/*View structure for view vwquestions */

/*!50001 DROP TABLE IF EXISTS `vwquestions` */;
/*!50001 DROP VIEW IF EXISTS `vwquestions` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwquestions` AS select `q`.`quesID` AS `quesID`,`q`.`ques` AS `question`,`q`.`quesTagalog` AS `questionTagalog`,`c`.`catID` AS `catID`,`c`.`catname` AS `catname` from (`questions` `q` join `category` `c` on(`c`.`catID` = `q`.`catID`)) */;

/*View structure for view vwstud */

/*!50001 DROP TABLE IF EXISTS `vwstud` */;
/*!50001 DROP VIEW IF EXISTS `vwstud` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwstud` AS select `s`.`studID` AS `studID`,`s`.`studnum` AS `studnum`,`s`.`lname` AS `lname`,`s`.`fname` AS `fname`,`s`.`mi` AS `mi`,concat(`s`.`lname`,', ',`s`.`fname`,' ',ifnull(`s`.`mi`,' ')) AS `fullname`,`s`.`is_deleted` AS `stud_is_deleted`,`d`.`deptID` AS `deptID`,`d`.`deptcode` AS `deptcode`,`d`.`deptname` AS `deptname`,`d`.`is_deleted` AS `dept_is_deleted` from (`students` `s` join `department` `d` on(`s`.`deptID` = `d`.`deptID`)) */;

/*View structure for view vw_faculties */

/*!50001 DROP TABLE IF EXISTS `vw_faculties` */;
/*!50001 DROP VIEW IF EXISTS `vw_faculties` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_faculties` AS select `a`.`facID` AS `facID`,`a`.`facNum` AS `facNum`,`a`.`lname` AS `lname`,`a`.`fname` AS `fname`,`a`.`mi` AS `mi`,`b`.`deptID` AS `deptID`,`b`.`deptcode` AS `deptcode`,`b`.`deptname` AS `deptname`,`a`.`is_deleted` AS `is_deleted` from (`faculty` `a` join `department` `b` on(`a`.`deptID` = `b`.`deptID`)) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
