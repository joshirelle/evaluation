<?php
// Include config file
require_once "php/core.php";

// Define variables and initialize with empty values
$ques = $quesTagalog = "";
$ques2 = $quesTagalog2 = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate name
  $input_ques = trim($_POST["ques"]);
  $ques = htmlspecialchars($input_ques);
  
  // Validate name
  $input_quesTagalog2 = trim($_POST["quesTagalog"]);
  $quesTagalog = htmlspecialchars($input_quesTagalog2);

  // Check input errors before inserting in database
  if (empty($name_err) && empty($address_err) && empty($salary_err)) {
    // Prepare an insert statement
    $sql_ques = "INSERT INTO questions (ques, quesTagalog) VALUES (:ques, :quesTagalog)";

    // Begin transaction
    $pdo->beginTransaction();

    try {
      $stmt_ques = $pdo->prepare($sql_ques);
      $stmt_ques->bindParam(":ques", $ques);
      $stmt_ques->bindParam(":quesTagalog", $quesTagalog);
      $stmt_ques->execute();

      //save when no error
      $pdo->commit();

      //redirect after save
      header("location: questions.php");

    } catch (PDOException $ex) {
      // prevent insert in database when error occurs
      $pdo->rollBack();
      exit($ex->getMessage());
    }

    // Close statement
    unset($stmt);
  }

  // Close connection
  unset($pdo);
}
?>