<?php
    require_once "php/core.php";

    $selected_termID = "";
    if(isset($_GET["termID"])) {
        $selected_termID = htmlspecialchars($_GET["termID"]);
    }
	// Set the select SQL data
	$sql = "SELECT termID, term FROM terms";

    $stmt = $pdo->query($sql);
    while($fetch = $stmt->fetch()) {
        $termID = $fetch['termID'];
        $term = $fetch['term'];

        if($selected_termID == $termID) {
            $is_selected = "selected";
        }

        echo "<option value='{$termID}' {$is_selected}>{$term}</option>";
    }
    unset($result);
    unset($pdo);
?>