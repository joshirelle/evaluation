<?php
    require_once "php/core.php";
 
	$studentId = htmlspecialchars($_GET['student_id']);//define the student ID

	// Set the INSERT SQL data
	$sql = "SELECT
    students.studID,
    students.studnum,
    students.lname,
    students.fname,
    students.mi,
    department.deptID,
    department.deptcode
    FROM students
    JOIN department ON students.deptID=department.deptID 
    WHERE students.studID=? AND students.is_deleted = 0";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array($studentId));

    $result = [];
    if ($fetch = $stmt->fetch()) {
        $result = [
            "studID" => $fetch["studID"],
            "studnum" => $fetch["studnum"],
            "lname" => $fetch["lname"],
            "fname" => $fetch["fname"],
            "mi" => $fetch["mi"],
            "deptID" => $fetch["deptID"],
            "deptcode" => $fetch["deptcode"]
        ];
    }
    echo json_encode($result);

    // if ($result = $pdo->query($sql)) {
    // if ($result->rowCount() > 0) {
    //     while ($row = $result->fetch()) {
    //         echo json_encode($row);
    //         }
    //     }
    // }
    unset($result);
    unset($pdo);
?>