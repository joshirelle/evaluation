<?php 
require_once "php/core.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="img/csta-logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Active Students | Faculty Evaluation</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
 
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include_once "includes/sidebar.php" ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include_once "includes/header.php" ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                
                  <!-- Page Heading -->
              <div class="d-flex justify-content-between mb-2 align-items-center" >
                    <h1 class="h3 mb-2 text-gray-800">Student Details</h1>
                <div class="mb-2">
                    <a href="#addStudentsModal" onclick="addModal()" class="btn btn-primary" data-toggle="modal"><i class="fas fa-user-plus"></i> <span>Add Student</span></a> 
                    <!--Import Link -->
                    <button type = "button" class= "btn btn-success" data-toggle="modal" data-target="#staticBackdrop"><i class="fas fa-file-import"></i></button>               
                </div>
              </div>   
                   
                
                    
                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Import Students</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div id="importFrm">
                                    <form class="row g-3" action="importData.php" method="post" enctype="multipart/form-data">

                                        <div class="col-md-12 input-group mb-3">
                                          <div class="custom-file">
                                            <input type="file" class="custom-file-input" name="file" id="fileInput" required>
                                            <label class="custom-file-label" for="fileInput">Choose file</label>
                                          </div>
                                          <div class="input-group-append">
                                            <!-- <span class="input-group-text" id="">Upload</span> -->
                                            <input type="submit" class="btn btn-primary mb-3" name="importSubmit" value="Import">
                                          </div>
                                        </div>
                                    </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                    <!-- Add Modal HTML -->
                <div id="addStudentsModal" class="modal fade">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form action="addstudents.php" method="POST">
                        <div class="modal-header">
                          <h4 class="modal-title">Add Students</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Student Number:</label>
                                <input id="studnum" type="text" name="studnum" placeholder="Enter Student Number" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Last Name:</label>
                                <input type="text" name="lname" placeholder="Enter Last Name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>First Name:</label>
                                <input type="text" name="fname" class="form-control" placeholder="Enter First Name" required>
                            </div>
                            <div class="form-group">
                                <label>Middle Initial:</label>
                                <input type="text" name="mname" placeholder="Enter Middle Initial" class="form-control">
                            </div>
                            <div class="form-element my-4">
                                <label>Department</label><br>
                                <select id="add_deptcode" name="deptcode" class="form-control">
                                   
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                          <input type="submit" class="btn btn-success" name="create" value="Add">
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <!-- Edit Modal HTML -->
                <div id="updateStudentModal" class="modal">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form action="" method="POST" id="edit-form">
                        
                        <div class="modal-header">
                          <h4 class="modal-title">Update Student</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group" hidden>
                            <label>Student ID:</label>
                            <input type="text" id="student_id" name="student_id" class="form-control" disabled>
                          </div>
                          <div class="form-group" hidden>
                            <label>Old Student Number:</label>
                            <input id="oldStudNum" type="text" name="oldStudNum" class="form-control" disabled>
                          </div>
                           <div class="form-group">
                            <label>Student Number:</label>
                            <input id="studnum" type="text" name="studnum" placeholder="Enter Student Number" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label>Last Name:</label>
                            <input id="lname" type="text" name="lname" placeholder="Enter Last Name" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label>First Name:</label>
                            <input id="fname" type="text" name="fname" class="form-control" placeholder="Enter First Name" required>
                          </div>
                          <div class="form-group">
                            <label>Middle Initial:</label>
                            <input id="mname" type="text" name="mname" placeholder="Enter Middle Initial" class="form-control">
                          </div>
                          <div class="form-element my-4">
                            <label>Department</label><br>
                            <select id="update_deptcode" name="deptcode" class="form-control">
                              
                            </select>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                          <input type="submit" class="btn btn-success" id="update-student-btn" name="create" value="Save">
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <!-- Delete Modal HTML -->
                <div id="deleteStudentsModal" class="modal">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <form id="frmStudentDelete" action="deletestudents.php" method="POST">
                        <input type="hidden" id="inputStudentID" name="id">
                        <div class="modal-header">						
                          <h4 class="modal-title">Deactivate Student </h4>
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">					
                          <p>Are you sure you want to deactive this Record?</p>
                        </div>
                        <div class="modal-footer">
                          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                          <input type="submit" class="btn btn-danger" value="Deactivate">
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="activestudent-table" width="100%" cellspacing="0">
                                  <?php
                                    // Attempt select query execution
                                    $sql = "SELECT students.studID, students.studnum, students.lname, students.fname, students.mi, department.deptcode
                                            FROM students
                                            JOIN department ON students.deptID=department.deptID 
                                            WHERE students.is_deleted=0";

                                    try {
                                        $stmt = $pdo->query($sql);

                                        if ($stmt->rowCount() > 0) {
                                            echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                            echo "<tr>";
                                            echo "<th>Student Number</th>";
                                            echo "<th>Last Name</th>";
                                            echo "<th>First Name</th>";
                                            echo "<th>Middle Initial</th>";
                                            echo "<th>Department</th>";
                                            echo "<th>Action</th>";
                                            echo "</tr>";
                                            echo "</thead>";
                                            echo "<tbody>";

                                            while ($row = $stmt->fetch()) {
                                                echo "<tr>";
                                                echo "<td class='col-md-3 text-center'>" . $row['studnum'] . "</td>";
                                                echo "<td class='col-md-3 text-center'>" . $row['lname'] . "</td>";
                                                echo "<td class='col-md-3 text-center'>" . $row['fname'] . "</td>";
                                                echo "<td class='col-md-2 text-center'>" . $row['mi'] . "</td>";
                                                echo "<td class='col-md-2 text-center'>" . $row['deptcode'] . "</td>";
                                                echo "<td style='min-width: 250px;'class='col-md-2 text-center'> " ;
                                                echo '<a href="#updateStudentModal" data-toggle="modal" class="btn btn-success mr-1" title="Update Record"  data-toggle="tooltip" data-id=' . $row['studID'] . '><i class="fas fa-edit"></i> Update</a>';
                                                echo '<a href="#deleteStudentsModal" onclick="passIdToForm('.$row['studID'].')" data-toggle="modal" class="btn btn-danger mr-1" title="Deactivate Record"  data-toggle="tooltip" data-id=' . $row['studID'] . '><i class="fa fa-thumbs-down"></i> Deactivate</a>';
                                                echo "</td>";
                                                echo "</tr>";
                                            }

                                            echo "</tbody>";
                                        } else {
                                            echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                                        }
                                    } catch (PDOException $e) {
                                        echo '<div class="alert alert-danger"><em>Error: ' . $e->getMessage() . '</em></div>';
                                    }
                                  ?>
                                    
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                      <span>Copyright &copy; FACULTY PERFORMANCE EVALUATION SYSTEM 2023</span>                    
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"></span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

   


  <!-- ajax -->


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <!-- <script src="js/demo/datatables-demo.js"></script> -->
    <script src="js/function.js"></script>
    <!-- Show/hide Excel file upload form -->

     <!-- ajax -->
  <script>
    $(document).ready(function() {
      $(document).delegate("[href='#updateStudentModal']", "click", function() {

        var studentID = $(this).attr('data-id');

        $.ajax({
          type: "GET",
          url: "getstudents.php",
          data: {
            student_id: studentID
          }
        }).done(response => {
          response = JSON.parse(response);
          $("#edit-form [name=\"student_id\"]").val(response.studID);
          $("#edit-form [name=\"oldStudNum\"]").val(response.studnum);
          $("#edit-form [name=\"studnum\"]").val(response.studnum);
          $("#edit-form [name=\"lname\"]").val(response.lname);
          $("#edit-form [name=\"fname\"]").val(response.fname);
          $("#edit-form [name=\"mname\"]").val(response.mi);

          $.ajax({
              type: "GET",
              url: 'getdepartment.php',
              data: {
                deptID: response.deptID
              },
            }).done(function(response) {
              //clear deptcode combobox
              $('#update_deptcode').html('');

              //add all to combobox
              let data = "<option>Select Department</option>";
              let info = data+response;
              $('#update_deptcode').html(info);
          });
        })
      });
    });

    $("#update-student-btn").on("click", function(e) {
        e.preventDefault();

        var studID = $("#edit-form [name=\"student_id\"]").val();
        var oldStudNum = $("#edit-form [name=\"oldStudNum\"]").val();
        var studNum = $("#edit-form [name=\"studnum\"]").val();
        var lname = $("#edit-form [name=\"lname\"]").val();
        var fname = $("#edit-form [name=\"fname\"]").val();
        var mi = $("#edit-form [name=\"mname\"]").val();
        var deptID = $("#edit-form [name=\"deptcode\"]").val();

        $.ajax({
          type: "POST",
          url: 'updatestudent.php',
          data: {
            student_id: studID,
            oldStudNum: oldStudNum,
            studNum: studNum,
            lname: lname,
            fname: fname,
            mi: mi,
            deptID: deptID,
          },
        }).done(function(response) {
          //console.log(response);
          location.reload();
        });
      });
  </script>

  
  <script>
    //pass id to frmDelete when delete button clicked
    
    function passIdToForm(id) {
      $("#frmStudentDelete").find('#inputStudentID').val(id);
    }

    function addModal() {
      $.ajax({
        type: "GET",
        url: 'getdepartment.php',
        data: {},
      }).done(function(response) {
        //clear deptcode combobox
        $('#add_deptcode').html('');

        //add all to combobox
        let data = "<option value='0'>Select Department</option>";
        let info = data+response;
        $('#add_deptcode').html(info);
      });
    }
  </script>


    <script type="application/javascript">
    $('input[type="file"]').change(function(e){
        var fileName = e.target.files[0].name;
        $('.custom-file-label').html(fileName);
    });
    </script>
</body>

</html>