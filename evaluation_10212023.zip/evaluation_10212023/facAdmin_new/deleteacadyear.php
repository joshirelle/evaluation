<?php
require_once "php/core.php";
$syID = $_GET['syID'];

$sql = "SELECT is_active FROM school_year WHERE syID=:syID";
$sql2 = "UPDATE school_year SET is_deleted = 1 WHERE syID=:syID";

$stmt = $pdo->prepare($sql);
$stmt->bindParam(":syID", $syID);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if($result['is_active'] != 1) {
    $stmt = $pdo->prepare($sql2);
    $stmt->bindParam(":syID", $syID);
    $stmt->execute();
}

header("location: listofacadyears.php");
unset($stmt);
unset($pdo);