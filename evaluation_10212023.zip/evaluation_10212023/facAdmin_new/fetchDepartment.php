<?php
    require_once "php/core.php";

    $request = $_REQUEST; //a PHP Super Global variable which used to collect data after submitting it from the form
	$departmentId = $request['department_id'];//define the employee ID


	// Set the INSERT SQL data
	$sql = "SELECT
     deptID, 
     deptcode, 
     deptname
    FROM department WHERE deptID='".$departmentId."'";

    if ($result = $pdo->query($sql)) {

    if ($result->rowCount() > 0) {
        while ($row = $result->fetch()) {
            echo json_encode($row);
            }
        }
    }
    unset($result);
    unset($pdo);
?>