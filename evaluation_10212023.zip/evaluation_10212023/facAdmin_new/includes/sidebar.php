<head>
<ul class="navbar-nav bg-gradient-dark-brown sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" style="color:white;"    href="dashboard.php">
        <div class="sidebar-brand-icon mt-1">
            <img src="img/csta-logo.ico" style="height: 55px; width: 55px;" alt="">
        </div>
        <div class="sidebar-brand-text mx-3 ">CSTA</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php if (basename($_SERVER['PHP_SELF']) == 'dashboard.php') echo 'active'; ?>">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <li class="nav-item <?php if (basename($_SERVER['PHP_SELF']) == 'activefaculty.php') echo 'active'; ?>">
        <a class="nav-link" href="./activefaculty.php">
            <i class="fas fa-light fa-users nav-icon"></i>
            <span>Faculty</span></a>
    </li>
    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item <?php if (in_array(basename($_SERVER['PHP_SELF']), ['activedepartment.php', 'questions.php', 'user.php', 'inactives.php'])) echo 'active'; ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-table"></i>
            <span>Maintenance</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php if (basename($_SERVER['PHP_SELF']) == 'activedepartment.php') echo 'active'; ?>" href="./activedepartment.php">Department</a>
                <a class="collapse-item <?php if (basename($_SERVER['PHP_SELF']) == 'questions.php') echo 'active'; ?>" href="./questions.php">Questionnaire</a>
                <a class="collapse-item <?php if (basename($_SERVER['PHP_SELF']) == 'user.php') echo 'active'; ?>" href="./user.php">Users</a>
                <a class="collapse-item <?php if (basename($_SERVER['PHP_SELF']) == 'inactives.php') echo 'active'; ?>" href="./inactives.php">Deactivated Items</a>
                
            </div>
        </div>
    </li>

    <li class="nav-item <?php if (basename($_SERVER['PHP_SELF']) == 'result.php') echo 'active'; ?>">
        <a class="nav-link" href="./result.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Results</span></a>
    </li>

    <li class="nav-item <?php if (in_array(basename($_SERVER['PHP_SELF']), ['term.php'])) echo 'active'; ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSettings"
            aria-expanded="true" aria-controls="collapseSettings">
            <i class="fas fa-fw fa-cog"></i>
            <span>Settings</span>
        </a>
        <div id="collapseSettings" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item <?php if (basename($_SERVER['PHP_SELF']) == 'term.php') echo 'active'; ?>" href="./term.php">Term</a>
                <a class="collapse-item <?php if (basename($_SERVER['PHP_SELF']) == 'listofacadyears.php') echo 'active'; ?>" href="./listofacadyears.php">Academic Year</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Tables -->
    <li class="nav-item <?php if (basename($_SERVER['PHP_SELF']) == 'activestudents.php') echo 'active'; ?>">
        <a class="nav-link" href="./activestudents.php">
        <i class="fas fa-light fa-users nav-icon"></i>
            <span>Students</span></a>
    </li>
    <!-- Nav Item - Charts -->       
</ul>