<?php
// Include config file
require_once "php/core.php";

// Define variables and initialize with empty values
$lname = $fname = $mname = $positionname = "";
$lname2 = $fname2 = $mname2 = $positionname2 = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    // Validate name
  $input_lname = trim($_POST["lname"]);
  $lname = $input_lname;
  
  // Validate name
  $input_fname = trim($_POST["fname"]);
  $fname = $input_fname;
  
  // Validate name
  $input_mname = trim($_POST["mname"]);
  $mname = $input_mname;

  $input_positionname = trim($_POST["positionname"]);
  $positionname = $input_positionname;

  // Check input errors before inserting in database
  if (empty($name_err) && empty($address_err) && empty($salary_err)) {
    // Prepare an insert statement
    $sql = "INSERT INTO user (lname, fname, mname, positionnum) VALUES (:lname, :fname, :mname, :positionnum)";

    if ($stmt = $pdo->prepare($sql)) {
      // Bind variables to the prepared statement as parameters    
      $stmt->bindParam(":lname", $param_lname);
      $stmt->bindParam(":fname", $param_fname);
      $stmt->bindParam(":mname", $param_mname);
      $stmt->bindParam(":positionnum", $param_positionname);
      // Set parameters
      
      $param_lname = $lname;
      $param_fname = $fname;
      $param_mname = $mname;
      $param_positionname = $positionname;

      // Attempt to execute the prepared statement
      if ($stmt->execute()) {
        // Records created successfully. Redirect to landing page
        header("location: user.php");
        exit();
      } else {
        echo "Oops! Something went wrong. Please try again later.";
      }
    }

    // Close statement 
    unset($stmt);
  }

  // Close connection
  unset($pdo);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="img/csta-logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Faculty Evaluation</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include_once "includes/sidebar.php" ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include_once "includes/header.php" ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                <div class="d-flex justify-content-between mb-2 align-items-center" >
                    <h1 class="h3 mb-2 text-gray-800">User Details</h1>
                    <a href="#addUserModal" class="btn btn-primary" data-toggle="modal"><i class="fas fa-user-plus"></i> <span>Add User</span></a>                
                </div>
                    
                <!-- Add Modal HTML -->
                <div id="addUserModal" class="modal fade">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <div class="modal-header">
                          <h4 class="modal-title">Add User</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label>Last Name:</label>
                            <input type="text" name="lname" placeholder="Enter Last Name" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label>First Name:</label>
                            <input type="text" name="fname" class="form-control" placeholder="Enter First Name" required>
                          </div>
                          <div class="form-group">
                            <label>Middle Name:</label>
                            <input type="text" name="mname" placeholder="Enter Middle Name" class="form-control" required>
                          </div>
                          <div class="form-element my-4">
                            <label>Position</label><br>
                            <select id ="positionname" name="positionname" class="form-control">
                              <option value="">--Select Position--</option>
                              <option value="1">Admin</option>
                              <option value="2">Dean</option>
                              <option value="3">Student</option>
                              
                            </select>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                          <input type="submit" class="btn btn-success" name="create" value="Add">
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

                <!-- Edit Modal HTML -->
                <div id="updateUserModal" class="modal">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <form action="updateuser.php" method="POST" id="edit-form">
                        <input type="hidden" name="user_id">
                        <div class="modal-header">
                          <h4 class="modal-title">Update Record</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label>Last Name:</label>
                            <input id="lname" type="text" name="lname" placeholder="Enter Last Name" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label>First Name:</label>
                            <input id="fname" type="text" name="fname" class="form-control" placeholder="Enter First Name" required>
                          </div>
                          <div class="form-group">
                            <label>Middle Name:</label>
                            <input id="mname" type="text" name="mname" placeholder="Enter Middle Name" class="form-control" required>
                          </div>
                          <div class="form-element my-4">
                            <label>Position</label><br>
                            <select id="positionname" name="positionname" class="form-control">
                              <option value="">--Select Position--</option>
                              <option value="1">Admin</option>
                              <option value="2">Dean</option>
                              <option value="3">Student</option>
                              
                            </select>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                          <input type="submit" class="btn btn-success" name="create" value="Save">
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

                <!-- Delete Modal HTML -->
                <div id="deleteUserModal" class="modal">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <form id="frmUserDelete" action="deleteuser.php" method="POST">
                        <input type="hidden" id="inputStudentID" name="id">
                        <div class="modal-header">						
                          <h4 class="modal-title">Deactivate Student </h4>
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">					
                          <p>Are you sure you want to deactive this Record?</p>
                        </div>
                        <div class="modal-footer">
                          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                          <input type="submit" class="btn btn-danger" value="Deactivate">
                        </div>
                      </form>
                    </div>
                  </div>
                </div>

                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                  <div class="card-body">
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="activeuser-table" width="100%" cellspacing="0">
                          <?php
                            // Attempt select query execution
                            $sql = "SELECT user.userid, user.lname, user.fname, user.mname, position.positionname
                                    FROM user
                                    JOIN position ON user.positionnum = position.positionnum
                                    WHERE user.is_deleted = 0";

                            try {
                              $stmt = $pdo->query($sql);

                              if ($stmt->rowCount() > 0) {
                                echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                echo "<tr>";
                                echo "<th>#</th>";
                                echo "<th>Last Name</th>";
                                echo "<th>First Name</th>";
                                echo "<th>Middle Name</th>";
                                echo "<th>Position</th>";
                                echo "<th>Action</th>";
                                echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";

                                while ($row = $stmt->fetch()) {
                                  echo "<tr>";
                                  echo "<td class='text-center'>{$row['userid']}</td>";
                                  echo "<td class='text-center'>{$row['lname']}</td>";
                                  echo "<td class='text-center'>{$row['fname']}</td>";
                                  echo "<td class='text-center'>{$row['mname']}</td>";
                                  echo "<td class='text-center'>{$row['positionname']}</td>";
                                  echo "<td style='min-width: 250px;'class='col-md-2 text-center'> " ;
                                  echo "<a href='#updateUserModal' data-toggle='modal' class='btn btn-success mr-1' title='Update Record' data-toggle='tooltip' data-id='{$row['userid']}'><i class='fas fa-edit'></i> Update</a>";
                                  echo "<a href='#deleteUserModal' onclick='passIdToForm({$row['userid']})' data-toggle='modal' class='btn btn-danger mr-1' title='Deactivate Record' data-toggle='tooltip' data-id='{$row['userid']}'><i class='fa fa-thumbs-down'></i> Deactivate</a>";
                                  echo "</td>";
                                  echo "</tr>";
                                }

                                echo "</tbody>";
                                // Free result set
                                unset($stmt);
                              } else {
                                echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                              }
                            } catch (PDOException $e) {
                              echo "Error: " . $e->getMessage();
                            }
                          ?>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                      <span>Copyright &copy; FACULTY PERFORMANCE EVALUATION SYSTEM 2023</span>                   
                     </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



    <!-- ajax -->
  <script>
    $(document).ready(function() {
      $(document).delegate("[href='#updateUserModal']", "click", function() {

        var userID = $(this).attr('data-id');

        // Ajax config
        $.ajax({
          type: "GET", //we are using GET method to get data from server side
          url: 'getuser.php', // get the route value
          data: {
            user_id: userID
          }, //set data
          beforeSend: function() { //We add this before send to disable the button once we submit it so that we prevent the multiple click

          },
          success: function(response) { //once the request successfully process to the server side it will return result here
            response = JSON.parse(response);
            $("#edit-form [name=\"user_id\"]").val(response.userid);
            $("#edit-form [name=\"lname\"]").val(response.lname);
            $("#edit-form [name=\"fname\"]").val(response.fname);
            $("#edit-form [name=\"mname\"]").val(response.mname);
            switch (response.positionname) {
              case "Admin":
                $('#positionname option[value=1]').attr('selected', 'selected');
                break;
              case "Student":
                $('#positionname option[value=3]').attr('selected', 'selected');

                break;
              case "Dean":
                $('#positionname option[value=2]').attr('selected', 'selected');

                break;
              


              default:
                break;
            }
          }
        });
      });
    })
  </script>
  <script>
    //pass id to frmDelete when delete button clicked
    
    function passIdToForm(id) {
      $("#frmUserDelete").find('#inputStudentID').val(id);
    }

    function addModal() {
      $.ajax({
        type: "GET",
        url: 'getdepartment.php',
        data: {},
      }).done(function(response) {
        //clear deptcode combobox
        $('#add_deptcode').html('');

        //add all to combobox
        let data = "<option value='0'>Select Department</option>";
        let info = data+response;
        $('#add_deptcode').html(info);
      });
    }
  </script>


  <!-- ajax -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- ChartJS -->
  <script src="plugins/chart.js/Chart.min.js"></script>
  <!-- Sparkline -->
  <script src="plugins/sparklines/sparkline.js"></script>
  <!-- JQVMap -->
  <script src="plugins/jqvmap/jquery.vmap.min.js"></script>
  <script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
  <!-- jQuery Knob Chart -->
  <script src="plugins/jquery-knob/jquery.knob.min.js"></script>
  <!-- daterangepicker -->
  <script src="plugins/moment/moment.min.js"></script>
  <script src="plugins/daterangepicker/daterangepicker.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.js"></script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <!-- <script src="js/demo/datatables-demo.js"></script> -->
    <script src="js/function.js"></script>
</body>

</html>