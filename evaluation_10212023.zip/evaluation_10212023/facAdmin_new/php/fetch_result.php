<?php
    require_once "connection.php";
    // Set content type header to specify JSON response
    header('Content-Type: application/json');

    // Attempt select query execution
    $sql = "SELECT fmID, fullname, deptID, deptcode
            FROM vwfacultymembers
            WHERE faculty_is_deleted = 0 
            AND EXISTS (SELECT * FROM vweva WHERE vweva.fm_fmID = vwfacultymembers.fmID)
            ORDER BY fullname;";

    try {
        $stmt = $pdo->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($data);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Error fetching data: ' . $e->getMessage()]);
    }
?>