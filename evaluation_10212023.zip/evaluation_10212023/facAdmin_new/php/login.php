<?php
session_start();
require_once "connection.php";

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    $errors = validateForm($_POST);
    if ($errors) {
        $_SESSION['errors'] = $errors;
        $_SESSION['fields']['username'] = $_POST['username'];
        header('Location: ../login.php');
        exit();
    }

    // If validation passed, check if user exists
    $sql = "SELECT * FROM user WHERE username = ? AND password = ? AND is_deleted <> 1;";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$username, $password]);
    if ($stmt->rowCount() === 0) {
        $_SESSION['login_error'] = 'Invalid username or password!';
        $_SESSION['fields']['username'] = $_POST['username'];
        header('Location: ../login.php');
        exit();
    }

    $user = $stmt->fetch();
    $_SESSION['user_id'] = $user['userid'];
    header('Location: ../dashboard.php');
}

if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: ../login.php');
}

function validateForm($request)
{
    $errors = [];

    if (empty($request['username'])) {
        $errors['username'] = 'This field is required.';
    }

    if (empty($request['password'])) {
        $errors['password'] = 'This field is required.';
    }

    return $errors;
}
