<?php
require_once "php/core.php"; 


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="img/csta-logo.ico" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Deactivated Items | Faculty Evaluation</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include_once "includes/sidebar.php" ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include_once "includes/header.php" ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="d-flex justify-content-between mb-2 ml-3 align-items-center" >
                        <h1 class="h3 mb-2 text-gray-800"> Deactivated Items</h1>   
                    </div>
                    <?php if (isset($_SESSION['success'])) : ?>
                        <div class='alert alert-success text-center' role='alert' id='api_response'>
                            <b>
                                <?php
                                    echo $_SESSION['success'];
                                    unset($_SESSION['success']);
                                ?>
                            </b>
                        </div>
                    <?php endif; ?>

                    <ul class="nav nav-tabs">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-faculty-tab" data-bs-toggle="pill" data-bs-target="#pills-faculty" type="button" role="tab" aria-controls="pills-faculty" aria-selected="true"> Faculty </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-students-tab" data-bs-toggle="pill" data-bs-target="#pills-students" type="button" role="tab" aria-controls="pills-students" aria-selected="false"> Students </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-department-tab" data-bs-toggle="pill" data-bs-target="#pills-department" type="button" role="tab" aria-controls="pills-department" aria-selected="false"> Department </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-user-tab" data-bs-toggle="pill" data-bs-target="#pills-user" type="button" role="tab" aria-controls="pills-user" aria-selected="false"> User </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-question-tab" data-bs-toggle="pill" data-bs-target="#pills-question" type="button" role="tab" aria-controls="pills-question" aria-selected="false"> Questions </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-category-tab" data-bs-toggle="pill" data-bs-target="#pills-category" type="button" role="tab" aria-controls="pills-category" aria-selected="false"> Category </button>
                        </li>
                    </ul>
                    <div class="card shadow mb-4">
                        <div class="card-body">

                            <div class="tab-content" id="pills-tabContent">
                                <!--tab1-->
                                <div class="tab-pane fade show active" id="pills-faculty" role="tabpanel" aria-labelledby="pills-faculty-tab">
                                    <div class="d-flex justify-content-between my-3 pl-3 align-items-center" >
                                        <h1 class="h3 mb-2 text-gray-800">Inactive Faculty</h1>
                                    </div>
                                    <!-- Restore Modal HTML -->
	                                <div id="RestoreFacultyModal" class="modal">
		                                <div class="modal-dialog modal-dialog-centered">
			                                <div class="modal-content">
				                                <form id="frmFacultyRestore" action="restorefaculty.php" method="POST">
                                                    <input type="hidden" id="inputFacultyID" name="id">
					                                    <div class="modal-header">						
						                                    <h4 class="modal-title">Restore Faculty</h4>
						                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					                                    </div>
					                                    <div class="modal-body">					
						                                    <p>Are you sure you want to restore record <b>#<span name="selId"></span></b>?</p>
					                                    </div>
					                                    <div class="modal-footer">
						                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						                                    <input type="submit" class="btn btn-primary" value="Restore">
					                                    </div>
				                                </form>
			                                </div>
		                                </div>
	                                </div>
                                    <!-- DataTales Example -->
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="faculty-table" width="100%" cellspacing="0">
                                                    <?php
                                                        // Attempt select query execution
                                                        $sql = "SELECT facID, lname, fname, mi, deptcode 
                                                                FROM vwfacultymembers 
                                                                WHERE faculty_is_deleted = 1";

                                                        try {
                                                            $stmt = $pdo->query($sql);

                                                            if ($stmt->rowCount() > 0) {
                                                                echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                                                echo "<tr>";
                                                                echo "<th>#</th>";
                                                                echo "<th>Last Name</th>";
                                                                echo "<th>First Name</th>";
                                                                echo "<th>Middle Initial</th>";
                                                                echo "<th>Department</th>";
                                                                echo "<th>Action</th>";
                                                                echo "</tr>";
                                                                echo "</thead>";
                                                                echo "<tbody>";

                                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                                    echo "<tr>";
                                                                    echo "<td class='text-center'>{$row['facID']}</td>";
                                                                    echo "<td class='text-center'>{$row['lname']}</td>";
                                                                    echo "<td class='text-center'>{$row['fname']}</td>";
                                                                    echo "<td class='text-center'>{$row['mi']}</td>";
                                                                    echo "<td class='text-center'>{$row['deptcode']}</td>";
                                                                    echo "<td class='col-md-1 text-center'>";
                                                                    echo "<a href='#RestoreFacultyModal' onclick='passIdToForm({$row['facID']}, \"RestoreFacultyModal\")' data-toggle='modal' class='btn btn-success mr-1' title='Restore Record' data-toggle='tooltip' data-id='{$row['facID']}'>Restore</a>";
                                                                    echo "</td>";
                                                                    echo "</tr>";
                                                                }

                                                                echo "</tbody>";
                                                            } else {
                                                                echo "<tbody><tr><td colspan='6'><em>No records were found.</em></td></tr></tbody>";
                                                            }
                                                        } catch (PDOException $e) {
                                                            echo "Error: " . $e->getMessage();
                                                        }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end of tab1-->

                                <!--tab2-->
                                <div class="tab-pane fade" id="pills-students" role="tabpanel" aria-labelledby="pills-students-tab">
                                    <div class="d-flex justify-content-between my-3 pl-3 align-items-center" >
                                        <h1 class="h3 mb-2 text-gray-800">Inactive Students</h1>
                                    </div>
                                    <!-- Restore Modal HTML -->
	                                <div id="RestoreStudentsModal" class="modal">
		                                <div class="modal-dialog modal-dialog-centered">
			                                <div class="modal-content">
				                                <form id="frmStudentRestore" action="restorestudents.php" method="POST">
                                                    <input type="hidden" id="inputStudentID" name="id">
					                                    <div class="modal-header">						
						                                    <h4 class="modal-title">Restore Student </h4>
						                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					                                    </div>
					                                    <div class="modal-body">					
                                                            <p>Are you sure you want to restore record <b>#<span name="selId"></span></b>?</p>
					                                    </div>
					                                    <div class="modal-footer">
						                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						                                    <input type="submit" class="btn btn-primary" value="Restore">
					                                    </div>
				                                </form>
			                                </div>
		                                </div>
	                                </div>
                                    <!-- DataTales Example -->
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="students-table" width="100%" cellspacing="0">
                                                    <?php
                                                        $sql = "SELECT students.studID, students.studnum, students.lname, students.fname, students.mi, department.deptcode
                                                                FROM students
                                                                JOIN department ON students.deptID = department.deptID
                                                                WHERE students.is_deleted = 1";
                                                        try {
                                                            $result = $pdo->query($sql);

                                                            if ($result->rowCount() > 0) {
                                                                echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                                                echo "<tr>";
                                                                echo "<th>#</th>";
                                                                echo "<th>Student Number</th>";
                                                                echo "<th>Last Name</th>";
                                                                echo "<th>First Name</th>";
                                                                echo "<th>Middle Initial</th>";
                                                                echo "<th>Department</th>";
                                                                echo "<th>Action</th>";
                                                                echo "</tr>";
                                                                echo "</thead>";
                                                                echo "<tbody>";

                                                                while ($row = $result->fetch()) {
                                                                    echo "<tr>";
                                                                    echo "<td class='text-center'>{$row['studID']}</td>";
                                                                    echo "<td class='text-center'>{$row['studnum']}</td>";
                                                                    echo "<td class='text-center'>{$row['lname']}</td>";
                                                                    echo "<td class='text-center'>{$row['fname']}</td>";
                                                                    echo "<td class='text-center'>{$row['mi']}</td>";
                                                                    echo "<td class='text-center'>{$row['deptcode']}</td>";
                                                                    echo "<td class='col-md-1 text-center'>";
                                                                    echo '<a href="#RestoreStudentsModal" onclick="passIdToForm(' . $row['studID'] . ', \'RestoreStudentsModal\')" 
                                                                        data-toggle="modal" class="btn btn-success mr-1" title="Restore Record" data-toggle="tooltip" 
                                                                        data-id=' . $row['studID'] . '>Restore</a>';
                                                                    echo "</td>";
                                                                    echo "</tr>";
                                                                }

                                                                echo "</tbody>";
                                                                // Free result set
                                                                unset($result);
                                                            } else {
                                                                echo "<tbody><tr><td colspan='6'><em>No records were found.</em></td></tr></tbody>";
                                                            }
                                                        } catch (Exception $e) {
                                                            echo "Error: " . $e->getMessage();
                                                        }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end of tab2-->

                                <!--tab3-->
                                <div class="tab-pane fade" id="pills-department" role="tabpanel" aria-labelledby="pills-department-tab">
                                    <div class="d-flex justify-content-between my-3 pl-3 align-items-center" >
                                        <h1 class="h3 mb-2 text-gray-800">Inactive Department</h1>
                                    </div>
                                    <!-- Restore Modal HTML -->
	                                <div id="RestoreDepartmentModal" class="modal">
		                                <div class="modal-dialog modal-dialog-centered">
			                                <div class="modal-content">
				                                <form id="frmDepartmentRestore" action="restoredepartment.php" method="POST">
                                                    <input type="hidden" id="inputDepartmentID" name="id">
					                                <div class="modal-header">						
						                                <h4 class="modal-title">Restore Department </h4>
						                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					                                </div>
					                                <div class="modal-body">					
                                                        <p>Are you sure you want to restore record <b>#<span name="selId"></span></b>?</p>
					                                </div>
					                                <div class="modal-footer">
						                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						                                <input type="submit" class="btn btn-primary" value="Restore">
					                                </div>
				                                </form>
			                                </div>
		                                </div>
	                                </div>

                                    <!-- DataTales Example -->
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="department-table" width="100%" cellspacing="0">
                                                    <?php
                                                        // Attempt select query execution
                                                        $sql = "SELECT deptID, deptcode, deptname FROM department WHERE is_deleted = 1";

                                                        try {
                                                            $stmt = $pdo->query($sql);

                                                            if ($stmt->rowCount() > 0) {
                                                                echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                                                echo "<tr>";
                                                                echo "<th>#</th>";
                                                                echo "<th>Department Code</th>";
                                                                echo "<th>Department Name</th>";
                                                                echo "<th>Action</th>";
                                                                echo "</tr>";
                                                                echo "</thead>";
                                                                echo "<tbody>";

                                                                while ($row = $stmt->fetch()) {
                                                                    echo "<tr>";
                                                                    echo "<td class='col-md-1 text-center'>{$row['deptID']}</td>";
                                                                    echo "<td class='text-center'>{$row['deptcode']}</td>";
                                                                    echo "<td class='text-center'>{$row['deptname']}</td>";
                                                                    echo "<td class='col-md-1 text-center'>";
                                                                    echo "<a href='#RestoreDepartmentModal' onclick='passIdToForm({$row['deptID']}, \"RestoreDepartmentModal\")' 
                                                                        data-toggle='modal' class='btn btn-success mr-1' title='Restore Record' data-toggle='tooltip' 
                                                                        data-id='{$row['deptID']}'>Restore</a>";
                                                                    echo "</td>";
                                                                    echo "</tr>";
                                                                }

                                                                echo "</tbody>";
                                                                // Free result set
                                                                unset($stmt);
                                                            } else {
                                                                echo "<tbody><tr><td colspan='6'><em>No records were found.</em></td></tr></tbody>";
                                                            }
                                                        } catch (PDOException $e) {
                                                            echo "Error: " . $e->getMessage();
                                                        }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--end of tab3-->

                                <!--tab4-->
                                <div class="tab-pane fade" id="pills-user" role="tabpanel" aria-labelledby="pills-user-tab">
                                    <div class="d-flex justify-content-between my-3 pl-3 align-items-center" >
                                        <h1 class="h3 mb-2 text-gray-800">Inactive User</h1>
                                    </div>
                                    <!-- Restore Modal HTML -->
	                                <div id="RestoreUserModal" class="modal">
		                                <div class="modal-dialog modal-dialog-centered">
			                                <div class="modal-content">
				                                <form id="frmUserRestore" action="restoreuser.php" method="POST">
                                                    <input type="hidden" id="inputUserID" name="id">
					                                <div class="modal-header">						
						                                <h4 class="modal-title">Restore User</h4>
						                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					                                </div>
					                                <div class="modal-body">					
                                                        <p>Are you sure you want to restore record <b>#<span name="selId"></span></b>?</p>
					                                </div>
					                                <div class="modal-footer">
						                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						                                <input type="submit" class="btn btn-primary" value="Restore">
					                                </div>
				                                </form>
			                                </div>
		                                </div>
	                                </div>
                                    <!-- DataTales Example -->
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="inactiveuser-table" width="100%" cellspacing="0">
                                                    <?php
                                                        // Attempt select query execution
                                                        $sql = "SELECT user.userid, user.lname, user.fname, user.mname, position.positionname
                                                                FROM user
                                                                JOIN position ON user.positionnum = position.positionnum
                                                                WHERE user.is_deleted = 1";

                                                        try {
                                                            $stmt = $pdo->query($sql);

                                                            if ($stmt->rowCount() > 0) {
                                                                echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                                                echo "<tr>";
                                                                echo "<th>#</th>";
                                                                echo "<th>Last Name</th>";
                                                                echo "<th>First Name</th>";
                                                                echo "<th>Middle Name</th>";
                                                                echo "<th>Position</th>";
                                                                echo "<th>Action</th>";
                                                                echo "</tr>";
                                                                echo "</thead>";
                                                                echo "<tbody>";

                                                                while ($row = $stmt->fetch()) {
                                                                    echo "<tr>";
                                                                    echo "<td class='col-md-1 text-center'>{$row['userid']}</td>";
                                                                    echo "<td class='text-center'>{$row['lname']}</td>";
                                                                    echo "<td class='text-center'>{$row['fname']}</td>";
                                                                    echo "<td class='text-center'>{$row['mname']}</td>";
                                                                    echo "<td class='text-center'>{$row['positionname']}</td>";
                                                                    echo "<td class='col-md-1 text-center'>";
                                                                    echo '<a href="#RestoreUserModal" onclick="passIdToForm(' . $row['userid'] . ', \'RestoreUserModal\')" 
                                                                        data-toggle="modal" class="btn btn-success mr-1" title="Delete Record" data-toggle="tooltip" 
                                                                        data-id=' . $row['userid'] . '>Restore</a>';
                                                                    echo "</td>";
                                                                    echo "</tr>";
                                                                }

                                                                echo "</tbody>";
                                                                // Free result set
                                                                unset($stmt);
                                                            } else {
                                                                echo "<tbody><tr><td colspan='6'><em>No records were found.</em></td></tr></tbody>";
                                                            }
                                                        } catch (PDOException $e) {
                                                            echo "Error: " . $e->getMessage();
                                                        }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- end of tab4 -->

                                <!--tab5-->
                                <div class="tab-pane fade" id="pills-question" role="tabpanel" aria-labelledby="pills-question-tab">
                                    <div class="d-flex justify-content-between my-3 pl-3 align-items-center" >
                                        <h1 class="h3 mb-2 text-gray-800">Disabled Question</h1>
                                    </div>
                                    <!-- Restore Modal HTML -->
                                    <div id="RestoreQuestionModal" class="modal">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <form id="frmQuestionRestore" action="restorequestion.php" method="POST">
                                                    <input type="hidden" id="inputQuestionID" name="id">
                                                    <div class="modal-header">						
                                                        <h4 class="modal-title">Restore Question</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    </div>
                                                    <div class="modal-body">					
                                                        <p>Are you sure you want to restore record <b>#<span name="selId"></span></b>?</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                        <input type="submit" class="btn btn-primary" value="Restore">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- DataTales Example -->
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="question-table" width="100%" cellspacing="0">
                                                    <?php
                                                        // Attempt select query execution
                                                        $sql = "SELECT *
                                                                FROM vwquestions
                                                                WHERE questionDeactivated = 1";

                                                        try {
                                                            $stmt = $pdo->query($sql);

                                                            if ($stmt->rowCount() > 0) {
                                                                echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                                                echo "<tr>";
                                                                echo "<th>#</th>";
                                                                echo "<th>Question (English)</th>";
                                                                echo "<th>Question (Tagalog)</th>";
                                                                echo "<th>Category</th>";
                                                                echo "<th>Action</th>";
                                                                echo "</tr>";
                                                                echo "</thead>";
                                                                echo "<tbody>";

                                                                while ($row = $stmt->fetch()) {
                                                                    echo "<tr>";
                                                                    echo "<td class='col-md-1 text-center'>{$row['quesID']}</td>";
                                                                    echo "<td>{$row['question']}</td>";
                                                                    echo "<td>{$row['questionTagalog']}</td>";
                                                                    echo "<td>{$row['catname']}</td>";
                                                                    echo "<td class='col-md-1 text-center'>";
                                                                    echo '<a href="#RestoreQuestionModal" onclick="passIdToForm(' . $row['quesID'] . ', \'RestoreQuestionModal\')" 
                                                                        data-toggle="modal" class="btn btn-success mr-1" title="Delete Record" data-toggle="tooltip" 
                                                                        data-id=' . $row['quesID'] . '>Restore</a>';
                                                                    echo "</td>";
                                                                    echo "</tr>";
                                                                }

                                                                echo "</tbody>";
                                                                // Free result set
                                                                unset($stmt);
                                                            } else {
                                                                echo "<tbody><tr><td colspan='6'><em>No records were found.</em></td></tr></tbody>";
                                                            }
                                                        } catch (PDOException $e) {
                                                            echo "Error: " . $e->getMessage();
                                                        }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- end of tab5 -->
                                
                                <!--tab6-->
                                <div class="tab-pane fade" id="pills-category" role="tabpanel" aria-labelledby="pills-category-tab">
                                    <div class="d-flex justify-content-between my-3 pl-3 align-items-center" >
                                        <h1 class="h3 mb-2 text-gray-800">Disabled Category</h1>
                                    </div>
                                    <!-- Restore Modal HTML -->
	                                <div id="RestoreCategoryModal" class="modal">
		                                <div class="modal-dialog modal-dialog-centered">
			                                <div class="modal-content">
				                                <form id="frmCategoryRestore" action="restorecategory.php" method="POST">
                                                    <input type="hidden" id="inputCategoryId" name="id">
					                                <div class="modal-header">						
						                                <h4 class="modal-title">Restore Category</h4>
						                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					                                </div>
					                                <div class="modal-body">					
                                                        <p>Are you sure you want to restore record <b>#<span name="selId"></span></b>?</p>
					                                </div>
					                                <div class="modal-footer">
						                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						                                <input type="submit" class="btn btn-primary" value="Restore">
					                                </div>
				                                </form>
			                                </div>
		                                </div>
	                                </div>
                                    <!-- DataTales Example -->
                                    <div class="card shadow mb-4">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped font-weight-bold text-gray-800" id="category-table" width="100%" cellspacing="0">
                                                    <?php
                                                        // Attempt select query execution
                                                        $sql = "SELECT *
                                                                FROM category
                                                                WHERE isdeleted = 1";

                                                        try {
                                                            $stmt = $pdo->query($sql);

                                                            if ($stmt->rowCount() > 0) {
                                                                echo "<thead style='background:#C37C4D; text-align:center; color:white'>";
                                                                echo "<tr>";
                                                                echo "<th>#</th>";
                                                                echo "<th>Name</th>";
                                                                echo "<th>Description</th>";
                                                                echo "<th>Action</th>";
                                                                echo "</tr>";
                                                                echo "</thead>";
                                                                echo "<tbody>";

                                                                while ($row = $stmt->fetch()) {
                                                                    echo "<tr>";
                                                                    echo "<td class='col-md-1 text-center'>{$row['catID']}</td>";
                                                                    echo "<td class='text-center'>{$row['catname']}</td>";
                                                                    echo "<td class='text-center'>{$row['catdescE']}</td>";
                                                                    echo "<td class='col-md-1 text-center'>";
                                                                    echo '<a href="#RestoreCategoryModal" onclick="passIdToForm(' . $row['catID'] . ', \'RestoreCategoryModal\')" 
                                                                        data-toggle="modal" class="btn btn-success mr-1" title="Delete Record" data-toggle="tooltip" 
                                                                        data-id=' . $row['catID'] . '>Restore</a>';
                                                                    echo "</td>";
                                                                    echo "</tr>";
                                                                }

                                                                echo "</tbody>";
                                                                // Free result set
                                                                unset($stmt);
                                                            } else {
                                                                echo "<tbody><tr><td colspan='6'><em>No records were found.</em></td></tr></tbody>";
                                                            }
                                                        } catch (PDOException $e) {
                                                            echo "Error: " . $e->getMessage();
                                                        }
                                                    ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- end of tab6 -->

                            </div> <!-- end of tab content -->
                        </div>
                    </div>
                </div><!-- End of Page Content -->
            </div><!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; FACULTY PERFORMANCE EVALUATION SYSTEM 2023</span>                    
                    </div>
                </div>
            </footer><!-- End of Footer -->
        </div><!-- End of Content Wrapper -->
    </div><!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


<!-- script for fetching id of selected tab to use on modal -->
<script>
    function passIdToForm(id, formName) {
        $(`#${formName}`).find('[name="id"]').val(id);
        $(`#${formName}`).find('[name="selId"]').text(id);
    }
</script>

<!-- ajax ng faculty-->
<script>
    $(document).ready(function() {
      $(document).delegate("[href='#updateEmployeeModal']", "click", function() {

        var facultyID = $(this).attr('data-id');

        // Ajax config
        $.ajax({
          type: "GET", //we are using GET method to get data from server side
          url: 'getfaculty.php', // get the route value
          data: {
            faculty_id: facultyID
          }, //set data
          beforeSend: function() { //We add this before send to disable the button once we submit it so that we prevent the multiple click

          },
          success: function(response) { //once the request successfully process to the server side it will return result here
            response = JSON.parse(response);
            $("#edit-form [name=\"faculty_id\"]").val(response.facID);
            $("#edit-form [name=\"lname\"]").val(response.lname);
            $("#edit-form [name=\"fname\"]").val(response.fname);
            $("#edit-form [name=\"mname\"]").val(response.mi);
            switch (response.deptcode) {
              case "BSIT":
                $('#deptcode option[value=1]').attr('selected', 'selected');
                break;
              case "BSTM":
                $('#deptcode option[value=3]').attr('selected', 'selected');

                break;
              case "BSHM":
                $('#deptcode option[value=2]').attr('selected', 'selected');

                break;
              case "BEED":
                $('#deptcode option[value=4]').attr('selected', 'selected');
                break;
              case "BSED":
                $('#deptcode option[value=5]').attr('selected', 'selected');

                break;


              default:
                break;
            }
          }
        });
      });
    })
</script>

<!-- ajax ng students-->
<script>
    $(document).ready(function() {
      $(document).delegate("[href='#updateStudentModal']", "click", function() {

        var studentID = $(this).attr('data-id');

        // Ajax config
        $.ajax({
          type: "GET", //we are using GET method to get data from server side
          url: 'getstudents.php', // get the route value
          data: {
            student_id: studentID
          }, //set data
          beforeSend: function() { //We add this before send to disable the button once we submit it so that we prevent the multiple click

          },
          success: function(response) { //once the request successfully process to the server side it will return result here
            response = JSON.parse(response);
            $("#edit-form [name=\"student_id\"]").val(response.studID);
            $("#edit-form [name=\"studnum\"]").val(response.studnum);
            $("#edit-form [name=\"lname\"]").val(response.lname);
            $("#edit-form [name=\"fname\"]").val(response.fname);
            $("#edit-form [name=\"mname\"]").val(response.mi);
            switch (response.deptcode) {
              case "BSIT":
                $('#deptcode option[value=1]').attr('selected', 'selected');
                break;
              case "BSTM":
                $('#deptcode option[value=3]').attr('selected', 'selected');

                break;
              case "BSHM":
                $('#deptcode option[value=2]').attr('selected', 'selected');

                break;
              case "BEED":
                $('#deptcode option[value=4]').attr('selected', 'selected');
                break;
              case "BSED":
                $('#deptcode option[value=5]').attr('selected', 'selected');

                break;


              default:
                break;
            }
          }
        });
      });
    })
</script>

<!-- ajax ng department-->
<script>
    $(document).ready(function() {
      $(document).delegate("[href='#updateDepartmentModal']", "click", function() {

        var departmentID = $(this).attr('data-id');

        // Ajax config
        $.ajax({
          type: "GET", //we are using GET method to get data from server side
          url: 'fetchDepartment.php', // get the route value
          data: {
            department_id: departmentID
          }, //set data
          beforeSend: function() { //We add this before send to disable the button once we submit it so that we prevent the multiple click

          },
          success: function(response) { //once the request successfully process to the server side it will return result here
            response = JSON.parse(response);
            $("#edit-form [name=\"department_id\"]").val(response.deptID);
            $("#edit-form [name=\"deptcode\"]").val(response.deptcode);
            $("#edit-form [name=\"deptname\"]").val(response.deptname);
          }
        });
      });
    })
</script>

<!--script ng user -->
<script>
    $(document).ready(function() {
      $(document).delegate("[href='#updateUserModal']", "click", function() {

        var userID = $(this).attr('data-id');

        // Ajax config
        $.ajax({
          type: "GET", //we are using GET method to get data from server side
          url: 'getuser.php', // get the route value
          data: {
            user_id: userID
          }, //set data
          beforeSend: function() { //We add this before send to disable the button once we submit it so that we prevent the multiple click

          },
          success: function(response) { //once the request successfully process to the server side it will return result here
            response = JSON.parse(response);
            $("#edit-form [name=\"user_id\"]").val(response.userid);
            $("#edit-form [name=\"lname\"]").val(response.lname);
            $("#edit-form [name=\"fname\"]").val(response.fname);
            $("#edit-form [name=\"mname\"]").val(response.mname);
            switch (response.positionname) {
              case "Admin":
                $('#positionname option[value=1]').attr('selected', 'selected');
                break;
              case "Student":
                $('#positionname option[value=3]').attr('selected', 'selected');

                break;
              case "Dean":
                $('#positionname option[value=2]').attr('selected', 'selected');

                break;
              
              default:
                break;
            }
          }
        });
      });
    })
</script>

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script> $.widget.bridge('uibutton', $.ui.button) </script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- ChartJS -->
  <script src="plugins/chart.js/Chart.min.js"></script>
  <!-- Sparkline -->
  <script src="plugins/sparklines/sparkline.js"></script>
  <!-- JQVMap -->
  <script src="plugins/jqvmap/jquery.vmap.min.js"></script>
  <script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
  <!-- jQuery Knob Chart -->
  <script src="plugins/jquery-knob/jquery.knob.min.js"></script>
  <!-- daterangepicker -->
  <script src="plugins/moment/moment.min.js"></script>
  <script src="plugins/daterangepicker/daterangepicker.js"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
  <!-- Summernote -->
  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.js"></script>
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/function.js"></script>
</body>
</html>