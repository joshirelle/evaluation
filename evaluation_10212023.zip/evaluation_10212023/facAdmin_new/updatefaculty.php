<?php
// Include config file
require_once "php/core.php";
 
// Define variables and initialize with empty values
$lname = $fname = $mname = $deptcode = "";
$lname2 = $fname2 = $mname2 = $deptcode2 = "";

// Processing form data when form is submitted
if(isset($_POST["faculty_id"]) && !empty($_POST["faculty_id"])) {
    // Get hidden input value
    $id = htmlspecialchars($_POST["faculty_id"]);

    $input_old_facNum = trim($_POST["oldFacNum"]);
    $oldFacNum = htmlspecialchars($input_old_facNum);

    $input_facNum = trim($_POST["facNum"]);
    $facNum = htmlspecialchars($input_facNum);

    $input_lname = trim($_POST["lname"]);
    $lname = htmlspecialchars($input_lname);
    
    // // Validate address address
    $input_fname = trim($_POST["fname"]);
    $fname = htmlspecialchars($input_fname);
    
    $input_mi = trim($_POST["mi"]);
    $mi = htmlspecialchars($input_mi);
    
    $input_deptID= trim($_POST["deptID"]);
    $deptID = htmlspecialchars($input_deptID);

    // Prepare an update statement
    $sql_fac = "UPDATE faculty SET facNum=:facNum, lname=:lname, fname=:fname, mi=:mi, deptID=:deptID WHERE facID=:facID";
    $sql_fac2 = "UPDATE eva SET fmID=:newFmID WHERE fmID=:oldFmID";

    //Begin SQL transaction
    $pdo->beginTransaction();
    try {
        //faculty table
        $stmt_fac = $pdo->prepare($sql_fac);
        $stmt_fac->bindParam(":facNum", $facNum);
        $stmt_fac->bindParam(":lname", $lname);
        $stmt_fac->bindParam(":fname", $fname);
        $stmt_fac->bindParam(":mi", $mi);
        $stmt_fac->bindParam(":deptID", $deptID);
        $stmt_fac->bindParam(":facID", $id);
        $stmt_fac->execute();
        
        $stmt_fm = $pdo->prepare($sql_fac2);
        $stmt_fm->bindParam(":newFmID", $facNum);
        $stmt_fm->bindParam(":oldFmID", $oldFacNum);
        $stmt_fm->execute();

        //Save when no error
        $pdo->commit();

        echo "success";
        //redirect after save
        //header("location: activefaculty.php");

    } catch(PDOException $ex) {
        //revert changes when error occurs
        $pdo->rollBack();
        exit($ex->getMessage());//print error message [for debugging]
    }

    // if($stmt = $pdo->prepare($sql)){
    //     // Bind variables to the prepared statement as parameters
    //     $stmt->bindParam(":lname", $param_lname);
    //     $stmt->bindParam(":fname", $param_fname);
    //     $stmt->bindParam(":mi", $param_mname);
    //     $stmt->bindParam(":deptID", $param_deptID);
    //     $stmt->bindParam(":id", $param_id);

    //     // Set parameters
    //     $param_lname = $lname;
    //     $param_fname = $fname;
    //     $param_mname = $mname;
    //     $param_deptcode = $deptcode;
    //     $param_id = $id;
        
    //     // Attempt to execute the prepared statement
    //     if($stmt->execute()){
    //         // Records updated successfully. Redirect to landing page
    //         header("location: activefaculty.php");
    //         exit();
    //     } else{
    //         echo "Oops! Something went wrong. Please try again later.";
    //     }
    // }
     
    // Close statement
    unset($stmt);
    
    // Close connection
    unset($pdo);
}
?>
