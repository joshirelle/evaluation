<?php
// Include config file
require_once "php/core.php";


    // Define variables and initialize with empty values
    $studnum = $lname = $fname = $mname = $deptcode = "";
    $studnum2 = $lname2 = $fname2 = $mname2 = $deptcode2 = "";


    // Processing form data when form is submitted
    if (isset($_POST["student_id"]) && !empty($_POST["student_id"])) {
        // Get hidden input value
        $id = $_POST["student_id"];

        $input_old_studnum = trim($_POST["oldStudNum"]);
        $oldStudNum = htmlspecialchars($input_old_studnum);

        // Validate studentnum
        $input_studnum = trim($_POST["studNum"]);
        $studnum = htmlspecialchars($input_studnum);
        
        // Validate lname
        $input_lname = trim($_POST["lname"]);
        $lname = htmlspecialchars($input_lname);
        

        // // Validate fname
        $input_fname = trim($_POST["fname"]);
        $fname = htmlspecialchars($input_fname);
        

        // // Validate mi
        $input_mname = trim($_POST["mi"]);
        $mname = htmlspecialchars($input_mname);
    
        $input_deptID= trim($_POST["deptID"]);
        $deptID = htmlspecialchars($input_deptID);

        // Check input errors before inserting in database
        if (empty($name_err) && empty($address_err) && empty($salary_err)) {
            // Prepare an update statement
            $sql = "UPDATE students SET studnum=:studnum, lname=:lname, fname=:fname, mi=:mi, deptID=:deptID WHERE studID=:id";
            $sql_fac2 = "UPDATE eva SET studnum=:newstudNum WHERE studnum=:oldstudNum";

            if ($stmt = $pdo->prepare($sql)) {
                // Bind variables to the prepared statement as parameters
                $stmt->bindParam(":studnum", $studnum);
                $stmt->bindParam(":lname", $lname);
                $stmt->bindParam(":fname", $fname);
                $stmt->bindParam(":mi", $mname);
                $stmt->bindParam(":deptID", $deptID);
                $stmt->bindParam(":id", $id);
                $stmt->execute();

                $stmt_fm = $pdo->prepare($sql_fac2);
                $stmt_fm->bindParam(":newstudNum", $studnum);
                $stmt_fm->bindParam(":oldstudNum", $oldStudNum);
                $stmt_fm->execute();

                echo "success";
            }
        }
         // Close statement
         unset($stmt);
         
        // Close connection
        unset($pdo);
    }
?>
